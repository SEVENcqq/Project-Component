<template>
	<view @click="show = true">
		<u-datetime-picker ref="datetimePicker" @confirm="determine" @close="close" :show="show" v-model="value1" mode="datetime"
			:formatter="formatter"></u-datetime-picker>
			<u--text :text="showTime"></u--text>
	</view>
</template>

<script>
	export default {
		name: "datetimePickerAllTime",
		props: ["data", "cmodel"],
		data() {
			return {
				show: false,
				value1: Number(new Date()),
				showTime:'请选择时间',
			};
		},
		mounted() {
			this.value = this.data;
			const timeFormat = uni.$u.timeFormat;
			this.showTime = timeFormat(this.value, 'yyyy-mm-dd');
		},
		methods: {
			formatter(type, value) {
				if (type === 'year') {
					return `${value}年`
				}
				if (type === 'month') {
					return `${value}月`
				}
				if (type === 'day') {
					return `${value}日`
				}
				return value
			},
			
			determine(e) {
				const timeFormat = uni.$u.timeFormat;
				this.showTime = timeFormat(e.value, 'yyyy-mm-dd');
				this.show = false;
				let back = {
					cmodel: this.cmodel,
					newValue: e.value
				}
				this.$emit("changeValue", back);
			},
			close() {
				this.show = false;
			}
		},
		watch: {
			data: {
				handler(newValue,oldValue){
					this.value1 = newValue;
					const timeFormat = uni.$u.timeFormat;
					this.showTime = timeFormat(this.value1, 'yyyy-mm-dd');
					console.log('监听到数据变化'+ newValue);
				}
			},
			deep: true  // 需要监测数据变化的时候需要深度监听
		}
	}
</script>

<style>

</style>
