<template>
	<view class="content">
		<u--input :disabled="disable" placeholder="请输入内容" border="surround" v-model="value" @change="change"></u--input>
	</view>
</template>

<script>
	export default {
		name: "MaosInputBox",
		props: ["data","cmodel","disable"],
		data() {
			return {
				value: '',

			};
		},
		mounted() {
			this.value = this.data;
		},
		methods: {
			change(e) {
				let back = {
					cmodel: this.cmodel,
					newValue: this.value
				}
				this.$emit("changeValue", back);
			}
		},
		watch: {
			data: {
				handler(newValue,oldValue){
					this.value = newValue;
				}
			},
			deep: true  // 需要监测数据变化的时候需要深度监听
		}
	}
</script>

<style lang="scss">
.content {
}
</style>
