<template>
	<u--textarea :disabled="disable" v-model="value" placeholder="请输入内容" count @input="change"></u--textarea>
</template>

<script>
	export default {
		name: "myTextarea",
		props: ["data", "cmodel","disable"],
		data() {
			return {
				value: '',
			};
		},
		mounted() {
			this.value = this.data;
		
		},
		methods: {
			change() {
				console.log('change', this.cmodel);
				let back = {
					cmodel: this.cmodel,
					newValue: this.value
				}
				this.$emit("changeValue", back);
			}
		},
		watch: {
			data: {
				handler(newValue,oldValue){
					this.value = newValue;
					console.log('监听到数据变化'+ newValue);
				}
			},
			deep: true  // 需要监测数据变化的时候需要深度监听
		}
	}
</script>

<style>

</style>
