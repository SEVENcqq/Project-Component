<template>
	<u-upload :fileList="fileList" @afterRead="afterRead" @delete="deletePic" name="3" multiple :maxCount="10"
		:previewFullImage="true"></u-upload>
</template>

<script>
	export default {
		name: "myUpload",
		data() {
			return {
				fileList: [{
					url: 'https://cdn.uviewui.com/uview/swiper/1.jpg',
				}],
			};
		}
	}
</script>

<style lang="scss">

</style>
