export default {
	getBaseUrl: function() {
		return 'http://localhost:8081';
	},
}
