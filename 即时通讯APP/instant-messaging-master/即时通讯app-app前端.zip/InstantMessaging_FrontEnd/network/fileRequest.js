import axios from 'axios'
import BaseUrl from './baseUrl.js'

export default {
	toFileReq: function(datas) {
		let baseUrl = BaseUrl.getBaseUrl()
		return axios({
			method: 'POST',
			url: baseUrl + '/photos/upload',
			data: datas,
		})
	}
}
