<template>
	<view class="content">
		<view class="title">
			<view class="titleText">
				{{articalInfo.title}}
			</view>
			<view class="user">
				<image class="headImg" :src="articalInfo.userImgurl" mode=""></image>
				{{articalInfo.userName}}
				<view class="time">
					{{articalInfo.releaseTime}}
				</view>
			</view>
		</view>
		<view class="artical">
			<u-parse :content="articalInfo.content" :selectable="true" :tagStyle="style"></u-parse>
		</view>
		<u-divider text="到底啦"></u-divider>
	</view>
</template>

<script>
	import request from '../../network/request.js';
	import myFun from '../../commons/js/myFun.js'
	export default {
		data() {
			return {
				articalInfo: {},
				style: {
					// 字符串的形式
					p: 'font-size:32rpx',
					span: 'font-size: 30rpx',
					img: 'width:80%;height:200px;margin: 30rpx 10%;border-radius:10rpx'
				}
			};
		},
		mounted() {
			this.getArtical();
		},
		methods: {
			getArtical() {
				let data = {
					articalId: myFun.getUrlKey('aid')
				}
				request.toRequest('/announcement/getArticle', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						this.articalInfo = res[1].data.backValue;
						this.articalInfo.imgurl = this.apiUrl + this.articalInfo.imgurl;
						this.articalInfo.userImgurl = this.apiUrl + this.articalInfo.userImgurl;
						this.articalInfo.releaseTime = myFun.timestampToAllTime(this.articalInfo.releaseTime);
						console.log(this.articalInfo);
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.content {
		margin: 20rpx;
		padding-bottom: 80rpx;

		.title {

			padding-top: 20rpx;

			.titleText {
				font-size: 40rpx;
				font-weight: 600;
				margin-bottom: 20rpx;
			}

			.headImg {
				width: 80rpx;
				height: 80rpx;
				border-radius: 50%;
				vertical-align: middle;
				margin-right: 20rpx;
			}

			.time {
				display: inline-block;
				margin-left: 20rpx;
				font-size: 26rpx;
				color: #8c8c8c;
			}

		}

		.artical {
			margin-top: 40rpx;
		}
	}
</style>
