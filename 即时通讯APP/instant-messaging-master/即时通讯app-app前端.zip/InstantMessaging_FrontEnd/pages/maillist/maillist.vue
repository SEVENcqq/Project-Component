<template>
	<view class="content">
		<view class="top-bar">
			<view class="top-bar-left">
				<image :src="imgurl" mode=""></image>
			</view>
			<view class="top-bar-center">
				通讯录
			</view>
		</view>
		<view class="search" @tap="search">
			搜索
		</view>
		<view class="news" @tap="messageNotification">
			<view class="text">
				消息通知
			</view>
			<image src="../../static/images/grouphome/more.png" mode=""></image>
		</view>
		<view class="maillist">
			<view class="title">
				通讯录
			</view>
			<view class="employee maillistItem" v-for="item in list.employeesInfo" :key="list.employeesInfo.uid"
				@tap="intoUserhome(item.uid)">
				<view class="headImgContent">
					<image class="headImg" :src="item.imgurl" mode=""></image>
				</view>
				<view class="name">
					{{item.name}}
				</view>
			</view>
			<view class="department maillistItem" v-for="item in list.department" :key="list.employeesInfo.departmentId"
				@tap="intoOrganizational(item.departmentId, item.departmentName)">
				<view class="headImgContent">
					<image class="headImg" src="../../static/images/imag/department.png" mode=""></image>
				</view>
				<view class="name">
					{{item.departmentName}}
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	import request from '../../network/request.js';
	import myFun from '../../commons/js/myFun.js'
	export default {
		data() {
			return {
				uid: '',
				token: '',
				imgurl: '',
				eid: '',
				role: '',
				enterpriseId: '',
				list: {},
			};
		},
		onShow() {
			this.getStorages();
			this.getDepartmentLevelAndmployees();
		},
		methods: {
			//获取缓存
			getStorages: function() {
				const storageValue = uni.getStorageSync('user');
				if (storageValue) {
					this.uid = storageValue.id;
					this.eid = storageValue.enterpriseId;
					this.imgurl = this.apiUrl + storageValue.imgurl;
					this.token = storageValue.token;
					this.role = storageValue.role;
					this.enterpriseId = storageValue.enterpriseId;
				} else {
					uni.navigateTo({
						url: '../sign/signin'
					})
				}
			},
			//返回
			onBackPress(e) {

				//正常返回页面
				uni.navigateBack({
					delta: 1
				});
				// 此处一定姚要return为true，否则页面不会返回到指定路径
				return true;
			},
			//获取一级部门信息和员工信息
			getDepartmentLevelAndmployees() {
				let data = {
					"eid": this.eid
				}
				request.toRequest('/mailList/departmentLevelStructureEmployees', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						this.list = res[1].data.backValue;
						this.list.employeesInfo.forEach(item => {
							item.imgurl = this.apiUrl + item.imgurl;
						})
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			intoOrganizational(departmentId, departmentName) {
				uni.navigateTo({
					url: '../organizationalstructure/organizationalstructure?departmentId=' + departmentId +
						'&departmentName=' + departmentName
				});
			},
			//进入消息通知
			messageNotification() {
				uni.navigateTo({
					url: '../messagenotification/messagenotification'
				});
			},
			//进入用户home
			intoUserhome(uid) {
				uni.navigateTo({
					url: '../userhome/userhome?uid=' + uid
				});
			},
			search() {
				uni.navigateTo({
					url: '../search/search'
				});
			}
		}
	}
</script>

<style lang="scss">
	.content {
		background-color: rgba(245, 247, 246, 0.1);

		//头部样式
		.top-bar {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 88rpx;
			z-index: 1001;
			padding-top: var(--status-bar-height);
			box-sizing: border-box;
			background: rgba(255, 255, 255, 0.96);
			border-bottom: 1px solid $uni-bg-color;
			/**
		 * 此处有bug
		 box-shadow: 1px 1px 0px 0px rgba(0, 0, 0, 0.1);
		*/
			padding-left: $uni-spacing-col-base;

			.top-bar-left {
				float: left;
				padding-top: 15rpx;
				z-index: 1;
				margin-top: 5rpx;

				image {
					width: 68rpx;
					height: 68rpx;
					border-radius: 50%;

				}
			}

			.top-bar-center {
				position: absolute;
				left: 0;
				right: 0;
				// bottom: 0;
				margin: auto;
				text-align: center;
				padding-top: 20rpx;
				z-index: -1;
				font-size: 50rpx;
				font-weight: 200;
			}

			.top-bar-right {
				float: right;
				padding-top: 10rpx;

				.search {
					display: inline-block;
					width: 88rpx;
					height: 88rpx;

				}

				.add {
					display: inline-block;
					width: 88rpx;
					height: 88rpx;
				}

				image {
					width: 52rpx;
					height: 52rpx;
					padding: 18rpx 0 0 18rpx;
				}
			}
		}

		.search {
			background-color: rgba(245, 246, 250, 1);
			width: 96%;
			height: 60rpx;
			margin: 120rpx $uni-spacing-col-sm 0;
			border-radius: 10rpx;
			color: rgb(150, 151, 153);
			text-align: center;
			line-height: 60rpx;
		}

		.news {
			background: #FFFFFF;
			margin: 40rpx $uni-spacing-col-sm 20rpx $uni-spacing-col-sm;

			.text {
				display: inline;
				vertical-align: middle;
			}

			image {
				float: right;
				width: 40rpx;
				height: 40rpx;
				margin-top: 5rpx;
			}
		}

		.maillist {
			.title {
				margin: $uni-spacing-col-sm;
				font-size: 10px;
				color: #606060;
			}

			.maillistItem {
				margin: 20rpx;
				display: flex;
				flex-direction: row;

				.headImgContent {
					.headImg {
						width: 80rpx;
						height: 80rpx;
						border-radius: 10rpx;
						vertical-align: middle;
					}
				}

				.name {
					width: 90%;
					font-size: 36rpx;
					border-bottom: 1px solid #ebebeb;
					line-height: 80rpx;
					display: inline-block;
					margin-left: 30rpx;
					padding-bottom: 15rpx;
				}
			}
		}
	}
</style>
