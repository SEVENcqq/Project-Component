<template>
	<view class="memorandum">
		<view class="title">
			未完成
		</view>
		<view class="memorandumList">
			<u-swipe-action>
				<u-swipe-action-item :options="item.options" v-for="(item, index) in incomplete" :disabled="item.disabled"
					:key="index" :name="index" @click="completeChooce">
					<view class="swipe-action u-border-top" :class="[index === options4.length - 1 && 'u-border-bottom']">
						<view class="swipe-action__content">
							<text class="swipe-action__content__text">{{ item.memorandumName }}</text>
						</view>
					</view>
				</u-swipe-action-item>
			</u-swipe-action>
		</view>

		
		<view class="title">
			已完成
		</view>
		
		<view class="memorandumList">
			<u-swipe-action>
				<u-swipe-action-item :options="item.options" v-for="(item, index) in complete" :disabled="item.disabled"
					:key="index" :name="index" @click="incompleteChooce">
					<view class="swipe-action u-border-top" :class="[index === options4.length - 1 && 'u-border-bottom']">
						<view class="swipe-action__content" >
							<text class="swipe-action__content__text">{{ item.memorandumName }}</text>
						</view>
					</view>
				</u-swipe-action-item>
			</u-swipe-action>
		</view>


		<u-action-sheet :title="title" :show="show" :round="15" :closeOnClickOverlay="true" :closeOnClickAction="true"
			@close="closeUActionSheet">
			<u--input style="width: 80%;margin: 50rpx auto 50rpx auto;" placeholder="请输入内容" border="surround" v-model="value" v-show="state"></u--input>
			<u--input style="width: 80%;margin: 50rpx auto 50rpx auto;" placeholder="请输入内容" border="surround" v-model="updateValue" v-show="!state"></u--input>
			<u-button style="width: 80%;margin: 10rpx auto 50rpx auto;" type="primary" text="确定" @tap="determine" v-show="state"></u-button>
			<u-button style="width: 80%;margin: 10rpx auto 50rpx auto;" type="primary" text="更新" @tap="update" v-show="!state"></u-button>
		</u-action-sheet>
		<view class="addSchedule" @click="show = true;state = true">
			<image src="../../static/images/schedule/add.png" mode=""></image>
		</view>
	</view>
</template>

<script>
	import request from '../../network/request.js';
	export default {
		data() {
			return {
				uid: '',
				eid: '',
				token: '',
				role: '',
				options2: [{
						text: '完成',
						style: {
							backgroundColor: '#f56c6c'
						}
					},
					{
						text: '修改',
						style: {
							backgroundColor: '#55aaff'
						}
					}
				],
				options3: [{
						text: '取消完成',
						style: {
							backgroundColor: '#f56c6c'
						}
					},
					{
						text: '修改',
						style: {
							backgroundColor: '#55aaff'
						}
					}
				],
				options4: [],
				incomplete: [],
				complete: [],
				//弹出框
				title: '新增备忘录',
				show: false,
				//新增待办
				value: '',
				state: true, //true为添加，false为更新
				updateValue: 'ss',
				selectedMemorandumId: '',
				selectType: '',
			};
		},
		mounted() {
			this.getStorages();
			this.getMemorandum();
		},
		methods: {
			//获取缓存
			getStorages: function() {
				const storageValue = uni.getStorageSync('user');
				if (storageValue) {
					this.uid = storageValue.id;
					this.eid = storageValue.enterpriseId;
					this.token = storageValue.token;
					this.role = storageValue.role;
				} else {
					uni.navigateTo({
						url: '../sign/signin'
					})
				}
			},
			//完成操作
			completeChooce(item) {
				if (item.index == 0) {
					let data = {
						"memorandumId": this.incomplete[item.name]._id,
						"value": "complete",
						"type": "completeState",
					}
					request.toRequest('/memorandum/updateMemorandumState', data, 'POST').then(res => {
						let status = res[1].data.status;
						if (status == 200) {
							this.incomplete[item.name].options[0].text = '未完成'
							this.complete.push(this.incomplete[item.name])
							this.incomplete.splice(item.name, 1);
						} else if (status == 500) {
							uni.showToast({
								title: '服务器出错啦！',
								icon: 'none',
								duration: 2000
							})
						} else if (status == 300) {
							uni.navigateTo({
								url: '../signin/signin'
							})
						}
					})
				} else if (item.index == 1) {
					this.state = false;
					this.show = true;
					this.updateValue = this.incomplete[item.name].memorandumName;
					this.selectedMemorandumId = this.incomplete[item.name]._id;
					this.selectType = 'incomplete';
				}
				else {
					let data = {
						mid: this.incomplete[item.name]._id
					}
					request.toRequest('/memorandum/delMemorandum', data, 'POST').then(res => {
						let status = res[1].data.status;
						if (status == 200) {
							this.incomplete.splice(item.name, 1)
							uni.showToast({
								title: '删除成功！',
								icon: 'none',
								duration: 2000
							})
						} else if (status == 500) {
							uni.showToast({
								title: '服务器出错啦！',
								icon: 'none',
								duration: 2000
							})
						} else if (status == 300) {
							uni.navigateTo({
								url: '../signin/signin'
							})
						}
					})
				}
			},
			//未完成操作
			incompleteChooce(item) {
				if (item.index == 0) {
					let data = {
						"memorandumId": this.complete[item.name]._id,
						"value": "incomplete",
						"type": "completeState",
					}
					request.toRequest('/memorandum/updateMemorandumState', data, 'POST').then(res => {
						let status = res[1].data.status;
						if (status == 200) {
							this.complete[item.name].options[0].text = '完成'
							this.incomplete.push(this.complete[item.name])
							this.complete.splice(item.name, 1);
						} else if (status == 500) {
							uni.showToast({
								title: '服务器出错啦！',
								icon: 'none',
								duration: 2000
							})
						} else if (status == 300) {
							uni.navigateTo({
								url: '../signin/signin'
							})
						}
					})
				} else if (item.index == 1) {
					this.state = false;
					this.show = true;
					this.updateValue = this.complete[item.name].memorandumName;
					this.selectedMemorandumId = this.complete[item.name]._id
					this.selectType = 'complete';
				}
				else {

					let data = {
						mid: this.complete[item.name]._id
					}
					request.toRequest('/memorandum/delMemorandum', data, 'POST').then(res => {
						let status = res[1].data.status;
						if (status == 200) {
							this.complete.splice(item.name, 1)
							uni.showToast({
								title: '删除成功！',
								icon: 'none',
								duration: 2000
							})
						} else if (status == 500) {
							uni.showToast({
								title: '服务器出错啦！',
								icon: 'none',
								duration: 2000
							})
						} else if (status == 300) {
							uni.navigateTo({
								url: '../signin/signin'
							})
						}
					})
				}
			},
			//弹出框
			closeUActionSheet() {
				this.show = false;
			},
			//确定新增待办
			determine() {
				if (this.value) {
					let data = {
						"uid": this.uid,
						"name": this.value
					}
					request.toRequest('/schedule/NewMemorandum', data, 'POST').then(res => {
						let status = res[1].data.status;
						if (status == 200) {
							res[1].data.resualt.options = [{
									text: '完成',
									style: {
										backgroundColor: '#3c9cff',
									}
								},
								{
									text: '修改',
									style: {
										backgroundColor: '#f9ae3d',
									}
								},

							];
							this.incomplete.push(res[1].data.resualt);
							this.value = '';
							this.show = false;
						} else if (status == 500) {
							uni.showToast({
								title: '服务器出错啦！',
								icon: 'none',
								duration: 2000
							})
						} else if (status == 300) {
							uni.navigateTo({
								url: '../signin/signin'
							})
						}
					})
				}
				this.show = false;
			},
			//获取备忘录内容
			getMemorandum() {
				let data = {
					"uid": this.uid,
					"from": "memorandum"
				}
				request.toRequest('/memorandum/getMemorandum', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {

						res[1].data.resualt.forEach(item => {
							item.disabled = false;
							item.options = [{
									text: '',
									style: {
										backgroundColor: '#3c9cff',
									}
								},
								{
									text: '修改',
									style: {
										backgroundColor: '#f9ae3d',
									}
								},
								{
										text: '删除',
										style: {
											backgroundColor: '#f56c6c'
										}
									}

							];
							if (item.completeState == "complete") {
								item.options[0].text = '未完成'
								this.complete.push(item);
							} else {
								item.options[0].text = '完成'
								this.incomplete.push(item);
							}
						})
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			update() {
				let _this = this;
				let data = {
					"memorandumId": this.selectedMemorandumId,
					"value": this.updateValue,
					"type": "memorandumName",
				}
				request.toRequest('/memorandum/updateMemorandumState', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						// this.value = this.updateValue;
						_this.show = false;
						if (_this.selectType == 'complete') {
							for (let i = 0; i < _this.complete.length; i++) {
								if (_this.complete[i]._id == _this.selectedMemorandumId) {
									_this.complete[i].memorandumName = _this.updateValue;
									break;
								}
							}
						} else {
							for (let i = 0; i < _this.incomplete.length; i++) {
								if (_this.incomplete[i]._id == _this.selectedMemorandumId) {
									_this.incomplete[i].memorandumName = _this.updateValue;
									break;
								}
							}
						}
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			}
		},
	}
</script>

<style lang="scss">
	.u-page {
		padding: 0;
	}
	.u-demo-block__title {
		padding: 10px 0 2px 15px;
	}

	.swipe-action {
		&__content {
			padding: 25rpx 0;

			&__text {
				font-size: 15px;
				color: $u-main-color;
				padding-left: 30rpx;
			}
		}
	}
.memorandum {
	.title {
		margin: 20rpx;
		font-size: 50rpx;
		font-weight: 200;
	}
	.memorandumList {
		margin: 20rpx;
	}
}
	.addSchedule {
		width: 112rpx;
		height: 112rpx;
		background: rgb(10, 89, 244);
		border-radius: 50%;
		position: fixed;
		right: 40rpx;
		bottom: 70rpx;
		box-shadow: 0px 16px 24px 0px rgba(10, 89, 244, 0.26),
			0px 2px 6px 0px rgba(10, 89, 244, 0.24),
			0px 0px 1px 0px rgba(10, 89, 244, 0.24);

		image {
			width: 80rpx;
			height: 80rpx;
			position: absolute;
			left: 0;
			right: 0;
			bottom: 0;
			top: 0;
			margin: auto;
		}
	}
</style>
