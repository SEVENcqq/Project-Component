<template>
	<view class="content">
		<view class="artical" v-if="!showEmpty">
			<view class="articalItem" v-for="item in articalInfo" :key="item.articalId"
				@tap="intoArtical(item.articalId)">
				<view class="top">
					<view class="left">
						<image class="headImg" :src="item.headImgurl" mode=""></image>
						{{item.userName}}
					</view>
					<view class="right">
						{{item.releaseTime}}
					</view>
				</view>
				<view class="center">
					<image class="bgImg" :src="item.imgurl" mode="aspectFill"></image>
				</view>
				<view class="bottom">
					<view class="title">
						{{item.title}}
					</view>
				</view>
			</view>
		</view>
		<view class="empty" v-if="showEmpty">
			<u-empty mode="data" icon="http://cdn.uviewui.com/uview/empty/data.png">
			</u-empty>
		</view>

	</view>
</template>

<script>
	import request from '../../network/request.js';
	import myFun from '../../commons/js/myFun.js'
	export default {
		data() {
			return {
				articalInfo: [],
				showEmpty: false

			}
		},
		mounted() {
			this.getArticleInformation();
		},
		methods: {
			getArticleInformation() {
				let data = {
					"eid": myFun.getUrlKey('eid')
				}
				request.toRequest('/announcement/getArticleInformation', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						console.log();
						if (res[1].data.backValue.length) {
							this.articalInfo = res[1].data.backValue;
							this.articalInfo.forEach(item => {
								item.headImgurl = this.apiUrl + item.headImgurl
								item.imgurl = this.apiUrl + item.imgurl
								item.releaseTime = myFun.timestampToTime(item.releaseTime)
							})
							this.showEmpty = false;
						} else {
							this.showEmpty = true;
						}

					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			intoArtical(articalId) {
				uni.navigateTo({
					url: '../articalDetail/articalDetail?aid=' + articalId
				})
			}
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #fff;
		// background-color: #F6F7F9;
	}

	.content {
		.artical {
			width: 100%;
			box-sizing: border-box;
			padding-top: 20rpx;

			.articalItem {
				width: 90%;
				// height: 420rpx;
				margin: auto;
				background-color: #fff;
				border-radius: 20rpx;
				box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.06),
					0px 2px 6px 0px rgba(0, 0, 0, 0.08),
					0px 0px 1px 0px rgba(0, 0, 0, 0.04);
				margin-bottom: 20rpx;

				.top {
					width: 100%;
					height: 100rpx;

					.left {
						float: left;
						padding: 20rpx;

						.headImg {
							width: 80rpx;
							height: 80rpx;
							border-radius: 50%;
							vertical-align: middle;
							margin-right: 10rpx;
						}
					}

					.right {
						float: right;
						padding: 36rpx 20rpx 20rpx 20rpx;
						margin-right: 20rpx;
						font-size: 28rpx;
						color: #b5b5b5;
						vertical-align: middle;
					}
				}

				.center {
					width: 100%;
					height: 200rpx;

					.bgImg {
						width: 100%;
						height: 200rpx;
					}
				}

				.bottom {
					height: 120rpx;
					width: 90%;

					padding: 40rpx 40rpx 0rpx 40rpx;

					.title {
						text-overflow: -o-ellipsis-lastline;
						overflow: hidden; //溢出内容隐藏
						text-overflow: ellipsis; //文本溢出部分用省略号表示
						display: -webkit-box; //特别显示模式
						-webkit-line-clamp: 2; //行数
						line-clamp: 2;
						-webkit-box-orient: vertical; //盒子中内容竖直排列
					}
				}
			}
		}

	}
</style>
