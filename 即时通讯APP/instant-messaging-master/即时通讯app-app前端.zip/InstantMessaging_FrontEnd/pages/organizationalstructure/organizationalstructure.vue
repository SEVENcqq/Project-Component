<template>
	<view class="maillist">

		<top-bar>
			<template v-slot:center>
				{{title}}
			</template>
		</top-bar>

		<view class="maillistContent" v-if="!showEmpty">
			<view class="employee maillistItem" v-for="item in list.employeesInfo" :key="list.employeesInfo.uid"
				@tap="intoUserhome(item.uid)">
				<view class="headImgContent">
					<image class="headImg" :src="item.imgurl" mode=""></image>
				</view>
				<view class="name">
					{{item.name}}
				</view>
			</view>
			<view class="department maillistItem" v-for="item in list.department" :key="list.employeesInfo.departmentId"
				@tap="intoOrganizational(item.departmentId, item.departmentName)">
				<view class="headImgContent">
					<image class="headImg" src="../../static/images/imag/department.png" mode=""></image>
				</view>
				<view class="name">
					{{item.departmentName}}
				</view>
			</view>
		</view>
		<view class="empty" v-if="showEmpty">
			<u-empty mode="data" icon="http://cdn.uviewui.com/uview/empty/data.png">
			</u-empty>
		</view>

	</view>
</template>

<script>
	import topBar from '../../components/topBars/topBar.vue'
	import request from '../../network/request.js';
	import myFun from '../../commons/js/myFun.js'
	export default {
		components: {
			topBar
		},
		data() {
			return {
				uid: '',
				token: '',
				eid: '',
				role: '',
				enterpriseId: '',
				list: {},
				title: '',
				showEmpty: true,
			};
		},
		onShow() {
			this.getStorages();
			this.getDepartmentLevelAndmployees();
			this.title = myFun.getUrlKey('departmentName')
		},
		methods: {
			//获取缓存
			getStorages: function() {
				const storageValue = uni.getStorageSync('user');
				if (storageValue) {
					this.uid = storageValue.id;
					this.eid = storageValue.enterpriseId;
					this.token = storageValue.token;
					this.role = storageValue.role;
					this.enterpriseId = storageValue.enterpriseId;
				} else {
					uni.navigateTo({
						url: '../sign/signin'
					})
				}
			},
			//获取一级部门信息和员工信息
			getDepartmentLevelAndmployees() {
				let data = {
					"departmentId": myFun.getUrlKey('departmentId')
				}
				let _this = this;
				request.toRequest('/mailList/departmentAndEmployeesChild', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						if(res[1].data.backValue.department.length == 0 && res[1].data.backValue.employeesInfo.length == 0) {
							_this.showEmpty = true;
						}
						else {
							this.list = res[1].data.backValue;
							this.list.employeesInfo.forEach(item => {
								item.imgurl = this.apiUrl + item.imgurl;
							})
							_this.showEmpty = false;
						}

					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//进入组织架构
			intoOrganizational(departmentId, departmentName) {
				uni.navigateTo({
					url: '../organizationalstructure/organizationalstructure?departmentId=' + departmentId +
						'&departmentName=' + departmentName
				});
			},
			//进入用户home
			intoUserhome(uid) {
				uni.navigateTo({
					url: '../userhome/userhome?uid=' + uid
				});
			}
		}
	}
</script>

<style lang="scss">
	.maillist {
		.empty {
			margin-top: 150rpx;
		}

		.maillistContent {
			margin-top: 110rpx;

			.maillistItem {
				margin: 20rpx;
				display: flex;
				flex-direction: row;

				.headImgContent {
					.headImg {
						width: 80rpx;
						height: 80rpx;
						border-radius: 10rpx;
						vertical-align: middle;
					}
				}

				.name {
					width: 90%;
					font-size: 36rpx;
					border-bottom: 1px solid #ebebeb;
					line-height: 80rpx;
					display: inline-block;
					margin-left: 30rpx;
					padding-bottom: 15rpx;
				}
			}
		}

	}
</style>
