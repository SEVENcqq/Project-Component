<template>
	<view class="">
		<top-bar>
			<template v-slot:center>
				<view class="title">
					{{title}}
				</view>
			</template>
		</top-bar>
		<u--form labelPosition="left" v-model="model1" ref="form" :rules="rules">
			<view class="formComponents" v-for="item in data.list" :key="item.key">
				<u-form-item class="formItem" labelWidth="150rpx" v-if="item.type == 'textInput'" :label="item.name"
					prop="name" borderBottom ref="item1">
					<MaosInputBox @changeValue="changeValue" :disable="isDisable" :data="formValue[item.model]"
						:cmodel="item.model">
					</MaosInputBox>
				</u-form-item>
				<u-form-item class="formItem" labelWidth="150rpx" v-if="item.type == 'datetime'" :label="item.name"
					:prop="item.model" borderBottom ref="item1">
					<DatetimePickerAllTime @changeValue="changeValue" :data="formValue[item.model]"
						:cmodel="item.model"></DatetimePickerAllTime>
				</u-form-item>
				<u-form-item class="formItem" labelWidth="150rpx" v-if="item.type == 'multilineTextBox'"
					:label="item.name" :prop="item.model" borderBottom ref="item1">
					<MyTextarea :disable="isDisable" @changeValue="changeValue" :data="formValue[item.model]"
						:cmodel="item.model">
					</MyTextarea>
				</u-form-item>
				<u-form-item class="formItem" labelWidth="150rpx" v-if="item.type == 'uploader'" :label="item.name"
					:prop="item.model" borderBottom ref="item1">
					<MyUpload @changeValue="changeValue" :data="formValue[item.model]"></MyUpload>
				</u-form-item>
			</view>
			<view class="nextApprover" v-if="type == 'view' && nextApproverInfo.state == 'approve'">
				下一节点审批人
				<view class="info">
					<image :src="nextApproverInfo.imgurl" mode=""></image>
					<view class="name">
						{{nextApproverInfo.approverName}}
					</view>
				</view>
			</view>
			<u-button type="primary" @tap="submit" v-if="type == 'launch'" class="processBtn">提交</u-button>
			<u-button type="primary" @tap="approve" class="processBtn approve" v-if="type == 'approve'">审批</u-button>
			<u-button type="primary" @tap="refuse" class="processBtn refuse" v-if="type == 'approve'">拒绝</u-button>
		</u--form>
	</view>
</template>

<script>
	import request from '../../network/request.js';
	import myFun from '../../commons/js/myFun.js'
	import MaosInputBox from '@/components/myInput/myInput'
	import DatetimePickerAllTime from '@/components/datetimePickerAllTime/datetimePickerAllTime'
	import MyTextarea from '@/components/myTextarea/myTextarea'
	import MyUpload from '@/components/myUpload/myUpload'
	import topBar from '../../components/topBars/topBar.vue'
	export default {
		components: {
			MaosInputBox,
			DatetimePickerAllTime,
			MyTextarea,
			MyUpload,
			topBar
		},
		data() {
			return {
				uid: '',
				token: '',
				role: '',
				enterpriseId: '',
				show: false,
				value1: Number(new Date()),
				data: {},
				model1: {},
				title: '', //标题
				rules: {}, //校验规则
				formValue: {}, //表单数据
				workFlowModel: {}, //流程模型
				nextApproverId: '', //下一审批人id
				approvalNode: [], //审批节点
				type: '', //审批节点类型 approve审批状态
				approvalNode: '', //审批节点
				state: '', //流程发起状态
				tipsText: '', //提示语
				nextApproverInfo: {}, //下一节点审批人信息
				haveExpression: false, //判断流程是否设置表达式,
				isDisable: false,
			};
		},

		onReady() {
			this.type = myFun.getUrlKey('type');
			this.getStorages();
			this.getFormConfig();
			if (this.type == 'view') {
				this.viewNextApprover();
			}
		},
		methods: {
			//获取缓存
			getStorages: function() {
				const storageValue = uni.getStorageSync('user');
				if (storageValue) {
					this.uid = storageValue.id
					this.token = storageValue.token;
					this.role = storageValue.role;
					this.enterpriseId = storageValue.enterpriseId;
				} else {
					uni.navigateTo({
						url: '../sign/signin'
					})
				}
			},
			//获取表单模型
			getFormConfig() {
				let data = {
					"workflowId": myFun.getUrlKey('workflowId')
				}

				request.toRequest('/initiatingProcess/getFormModel', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						this.data = JSON.parse(res[1].data.configModel);
						this.workFlowModel = JSON.parse(res[1].data.workFlowModel);
						this.title = res[1].data.name;
						JSON.parse(res[1].data.configModel).list.forEach(item => {
							this.rules[item.model] = {
								type: 'string',
								required: item.required[0].required,
								message: item.required[0].message,
								trigger: ['blur', 'change']
							}
							if (myFun.getUrlKey('type') == 'launch')
								this.formValue[item.model] = '';
						})
						if (myFun.getUrlKey('type') == 'view' || myFun.getUrlKey('type') == 'approve') {
							this.isDisable = true;
						}
						if (myFun.getUrlKey('type') == 'approve' || myFun.getUrlKey('type') == 'view') {
							let datas = {
								"pfId": myFun.getUrlKey('pfId')
							}
							request.toRequest('/initiatingProcess/getFormValue', datas, 'POST').then(
								res => {
									let status = res[1].data.status;
									if (status == 200) {
										this.formValue = JSON.parse(res[1].data.formValue);
										this.approvalNode = res[1].data.approvalNode;
									} else if (status == 500) {
										uni.showToast({
											title: '服务器出错啦！',
											icon: 'none',
											duration: 2000
										})
									} else if (status == 300) {
										uni.navigateTo({
											url: '../signin/signin'
										})
									}
								}).catch(err => {
								console.log(err);
							})
						}
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//发起流程
			submit() {
				this.getNextApprover();
				if (this.haveExpression) {
					let data = {
						"uid": this.uid,
						"eid": this.enterpriseId,
						"workFlowId": myFun.getUrlKey('workflowId'),
						"nextApproverId": this.nextApproverId,
						"formValue": JSON.stringify(this.formValue),
						"approvalNode": this.approvalNode,
					}
					request.toRequest('/initiatingProcess/initiatin', data, 'POST').then(res => {
						let status = res[1].data.status;
						if (status == 200) {
							let datas = {
								"uid": this.uid,
								"pfid": res[1].data.pfid,
								"type": "applied"
							}
							request.toRequest('/initiatingProcess/insertCompletedOrApplied', datas, 'POST').then(
								res => {
									let status = res[1].data.status;
									if (status == 200) {

									} else if (status == 500) {
										uni.showToast({
											title: '服务器出错啦！',
											icon: 'none',
											duration: 2000
										})
									} else if (status == 300) {
										uni.navigateTo({
											url: '../signin/signin'
										})
									}
								})
							uni.showToast({
								title: this.tipsText,
								icon: 'none',
								duration: 2000
							})
							setTimeout(function() {
								uni.switchTab({
									url: '/pages/workbench/workbench'
								});
							}, 2000)
						} else if (status == 500) {
							uni.showToast({
								title: '服务器出错啦！',
								icon: 'none',
								duration: 2000
							})
						} else if (status == 300) {
							uni.navigateTo({
								url: '../signin/signin'
							})
						}
					})
				}

			},

			//审批
			approve() {
				this.getNextApprover();
				let data = {
					"pfId": myFun.getUrlKey('pfId'),
					"nextApproverId": this.nextApproverId,
					"approvalNode": this.approvalNode,
					"state": this.state, //审批通过
				}
				request.toRequest('/initiatingProcess/approve', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						let datas = {
							"uid": this.uid,
							"pfid": myFun.getUrlKey('pfId'),
							"type": "completed"
						}
						request.toRequest('/initiatingProcess/insertCompletedOrApplied', datas, 'POST').then(
							res => {
								let status = res[1].data.status;
								if (status == 200) {

								} else if (status == 500) {
									uni.showToast({
										title: '服务器出错啦！',
										icon: 'none',
										duration: 2000
									})
								} else if (status == 300) {
									uni.navigateTo({
										url: '../signin/signin'
									})
								}
							})
						uni.showToast({
							title: this.tipsText,
							icon: 'none',
							duration: 2000
						})
						setTimeout(function() {
							uni.switchTab({
								url: '/pages/workbench/workbench'
							});
						}, 2000)
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//获取下一节点审批人
			getNextApprover() {
				//流程发起时
				let _this = this;
				if (myFun.getUrlKey('type') == 'launch') {
					let formValueCopy = this.formValue;
					if (this.workFlowModel.lineList) {
						this.workFlowModel.lineList.forEach(itemOne => {
							if (itemOne.from == 'nodeA') {
								console.log(itemOne)
								if (itemOne.express) {
									if (eval(itemOne.express)) {
										for (let i = 0; i < this.workFlowModel.nodeList.length; i++) {
											if (itemOne.to == this.workFlowModel.nodeList[i].id) {
												if (this.workFlowModel.nodeList[i].bindingApprover) {
													this.nextApproverId = this.workFlowModel.nodeList[i]
														.bindingApprover
														.userID;
													this.approvalNode = this.approvalNode + itemOne.from + ',' +
														itemOne
														.to + ',';
													this.state = 'approve';
													this.tipsText = '成功发起流程！'
												} else {
													this.nextApproverId = 'end'
													this.tipsText = '流程结束！'
													this.state = 'end';
												}
												this.haveExpression = true;
											}
										}
									}
								} else {
									this.haveExpression = false;
									uni.showToast({
										title: '该流程还未设置分支条件，请设置完流程条件再发起！',
										icon: 'none',
										duration: 2000
									})
								}

							}
						})
					} else {
						uni.showToast({
							title: '该工作流未设置！',
							icon: 'none',
							duration: 2000
						})
					}

				}
				if (myFun.getUrlKey('type') == 'approve') {
					let processNode = this.approvalNode.split(',')
					if (this.workFlowModel.lineList) {
						this.workFlowModel.lineList.forEach(item => {
							if (item.from == processNode[processNode.length - 2]) {
								if (item.express) {
								} else {
									this.workFlowModel.nodeList.forEach(itemTwo => {
										if (itemTwo.id == item.to) {
											if (itemTwo.bindingApprover) {
												this.nextApproverId = itemTwo.bindingApprover.userID;
												this.approvalNode = this.approvalNode + item.from + ',' +
													item
													.to + ',';
												this.state = 'approve';
												this.tipsText = '审批成功！'
											} else {
												this.nextApproverId = this.uid;
												this.tipsText = '流程结束！'
												this.state = 'end';
											}

										}
									})
								}
							}
						})
					} else {
						this.haveExpression = false;
						uni.showToast({
							title: '该流程还未设置分支条件，请设置完流程条件再发起！',
							icon: 'none',
							duration: 2000
						})
					}
					// console.log(this.nextApproverId);
				}
			},
			//拒绝审批
			refuse() {
				let data = {
					"pfId": myFun.getUrlKey('pfId'),
				}
				request.toRequest('/initiatingProcess/refuse', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						this.tipsText = '拒绝审批成功！'
						uni.showToast({
							title: this.tipsText,
							icon: 'none',
							duration: 2000
						})
						let datas = {
							"uid": this.uid,
							"pfid": myFun.getUrlKey('pfId'),
							"type": "completed"
						}
						request.toRequest('/initiatingProcess/insertCompletedOrApplied', datas, 'POST').then(
							res => {
								let status = res[1].data.status;
								if (status == 200) {

								} else if (status == 500) {
									uni.showToast({
										title: '服务器出错啦！',
										icon: 'none',
										duration: 2000
									})
								} else if (status == 300) {
									uni.navigateTo({
										url: '../signin/signin'
									})
								}
							})
						setTimeout(function() {
							uni.switchTab({
								url: '/pages/workbench/workbench'
							});
						}, 2000)
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//当为查看状态时获取下一节点审批人
			viewNextApprover() {
				let data = {
					pfId: myFun.getUrlKey('pfId')
				}
				request.toRequest('/initiatingProcess/viewNextApprover', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						this.nextApproverInfo = res[1].data.backValue;
						this.nextApproverInfo.imgurl = this.apiUrl + this.nextApproverInfo.imgurl;
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//子组件值改变父组件值也改变
			changeValue(back) {
				this.formValue[back.cmodel] = back.newValue;
			},
		}
	}
</script>

<style lang="scss">
	.approve {
		margin-top: 20rpx;
	}

	.nextApprover {
		margin-left: 20rpx;
		margin-top: 20rpx;

		.info {
			text-align: center;

			image {
				width: 100rpx;
				height: 100rpx;
				border-radius: 50%;
			}
		}
	}

	.formItem {
		padding: 0 20rpx 0 20rpx;
	}

	.processBtn {
		width: 90%;
		margin-top: 50rpx;
	}
</style>
