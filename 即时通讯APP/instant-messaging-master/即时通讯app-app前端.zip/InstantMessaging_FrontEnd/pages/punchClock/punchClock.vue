<template>
	<view class="content">
		<view class="punchClock" v-show="type == 'punchClock'">
			<view class="personInfo">
				<view class="left">
					<view class="name">
						xxx
					</view>
					<view class="department">
						<image class="infoImg" src="../../static/images/punchClock/position.png" mode=""></image>研发部
					</view>
					<view class="position">
						<image class="infoImg" src="../../static/images/punchClock/department.png" mode=""></image>
						前端开发工程师
					</view>
				</view>
				<image class="headImg" src="../../static/images/imag/headPic2.png" mode=""></image>
			</view>
			<view class="punchClockContent">
				<u-notice-bar :text="noticeBarText"></u-notice-bar>
				<view class="punchClockTime">
					<view class="timeMoring">
						<view class="circular"></view>
						上班时间9:00
						<view class="timeMoringContent">
							<view class="punchClockCircular" v-if="alreadPunchClockMorning" @tap="morningPunchClock">
								<view class="text">
									上班打卡<br />08:05
								</view>
								<view class="time">
								</view>
							</view>
							<view class="punchClockInfo" v-if="!alreadPunchClockMorning">
								<view class="info">
									<view class="time">
										打卡时间:{{morningPunchClockInfo.PunchClockInfoTime}}
										<view :class="morningPunchClockInfo.state == '正常' ? 'state' : 'stateOther'">
											{{morningPunchClockInfo.state}}
										</view>
									</view>
									<view class="location">
										打卡地点：{{morningPunchClockInfo.punchClockLocation}}
									</view>
								</view>
							</view>
						</view>
					</view>
					<view class="timeAfternoon">
						<view class="circular"></view>
						下班时间18:00
						<view class="timeAfternoonContent">
							<view class="punchClockCircular" v-if="alreadPunchClockAfternoon"
								@tap="afternoonPunchClock">
								<view class="text">
									下班打卡<br />18:05
								</view>
								<view class="time">
								</view>
							</view>
							<view class="punchClockInfo" v-if="!alreadPunchClockAfternoon">
								<view class="info">
									<view class="time">
										打卡时间:{{afternoonPunchClockInfo.PunchClockInfoTime}}
										<view :class="afternoonPunchClockInfo.state == '正常' ? 'state' : 'stateOther'">
											{{afternoonPunchClockInfo.state}}
										</view>
									</view>
									<view class="location">
										打卡地点：{{afternoonPunchClockInfo.punchClockLocation}}
									</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="Statistics" v-show="type == 'Statistics'">
			<ren-calendar ref='ren' :markDays='markDays' :headerBar='true' @onDayClick='onDayClick'></ren-calendar>
			<!-- <view class="change">选中日期：{{curDate}}</view> -->
			<view class="dayPunchClock">
				<view class="titleContent">
					<view class="topTitle">
						上班打卡
					</view>
					<view class="name">
						毛永耀
					</view>
				</view>
				<u-divider></u-divider>
				<view class="dayPunchClockInfo">
					<view class="left">
						<view class="morning">
							09:00
						</view>
						<view class="line">

						</view>
						<view class="afternoon">
							18:00
						</view>
					</view>
					<view class="right" v-if="dataDisplay">
						<view class="morning dayInfo">
							上班<br />
							<view v-if="statisticsInfo.length>=1"
								:class="statisticsInfo[0].state == '迟到' ? 'timeOther' : 'time'">
								{{statisticsInfo[0].state}}打卡{{statisticsInfo[0].PunchClockInfoTime}}
							</view>

						</view>
						<u-divider></u-divider>
						<view class="afternoon dayInfo">
							下班<br />
							<view v-if="statisticsInfo.length>1"
								:class="statisticsInfo[1].state == '早退' ? 'timeOther' : 'time'">
								{{statisticsInfo[1].state}}打卡{{statisticsInfo[1].PunchClockInfoTime}}
							</view>
						</view>
					</view>
				</view>
				<u-divider></u-divider>
				<view class="workingHours" v-if="statisticsInfo.length==2">
					工作时间：{{workingHours}}
				</view>
			</view>
		</view>

		<u-tabbar :value="value" @click="changeType(e)" @change="click1" :fixed="true" :placeholder="false"
			:safeAreaInsetBottom="true">
			<u-tabbar-item text="打卡" icon="home"></u-tabbar-item>
			<u-tabbar-item text="统计" icon="photo"></u-tabbar-item>
		</u-tabbar>
	</view>
</template>

<script>
	import request from '../../network/request.js';
	import QQMapWX from '@/commons/js/qqmap-wx-jssdk'
	import RenCalendar from '@/components/ren-calendar/ren-calendar.vue'
	export default {
		components: {
			RenCalendar
		},
		data() {
			return {
				uid: '',
				eid: '',
				curDate: '',
				markDays: [],
				value: 0,
				// 或者如下，也可以配置keyName参数修改对象键名
				// list: [{name: '未付款'}, {name: '待评价'}, {name: '已付款'}],
				current: 1,
				type: 'punchClock',
				noticeBarText: '',
				alreadPunchClockMorning: true,
				alreadPunchClockAfternoon: true,
				morningPunchClockInfo: {}, //上班打卡数据
				afternoonPunchClockInfo: {}, //下班打卡数据
				statisticsInfo: [], //统计的数据
				dataDisplay: false, //数据显示
				workingHours: '' //工作时长
			}
		},
		onReady() {
			this.getStorages();
			this.searchPunchClockInfo();
			let today = this.$refs.ren.getToday().date;
			this.curDate = today;
			this.markDays.push(today);
		},
		methods: {
			//获取缓存
			getStorages: function() {
				const storageValue = uni.getStorageSync('user');
				if (storageValue) {
					this.uid = storageValue.id;
					this.eid = storageValue.enterpriseId;
					this.token = storageValue.token;
					this.role = storageValue.role;
					this.enterpriseId = storageValue.enterpriseId;
				} else {
					uni.navigateTo({
						url: '../sign/signin'
					})
				}
			},
			click1(name) {
				this.value = name
				if (name == 0) {
					this.type = 'punchClock'
				} else {
					this.type = 'Statistics'
				}
			},
			//点击日历切换选天
			onDayClick(data) {
				this.curDate = data.date;
				let clickDate = data.date.split("-");
				let datas = {
					"uid": this.uid,
					"nowYaer": clickDate[0],
					"nowMonth": clickDate[1],
					"nowDay": clickDate[2],
				}

				request.toRequest('/punchClock/searchPunchClockInfo', datas, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						let resualt = res[1].data.resualt;
						if (resualt.length == 0) {
							this.statisticsInfo = []
						} else {
							resualt.forEach(item => {
								let showClockInfoTime = new Date(item.punchClockTime).getHours() + ":" + (
									new Date(
										item.punchClockTime).getMinutes() < 10 ? '0' + new Date(item
										.punchClockTime)
									.getMinutes() : new Date(item.punchClockTime).getMinutes());
								let showState = ''
								if (item.type == 'morning') {
									if (item.state == 'normal')
										showState = '正常'
									else if (item.state == 'late')
										showState = '迟到'
									this.statisticsInfo.push({
										PunchClockInfoTime: showClockInfoTime,
										punchClockLocation: item.punchClockLocation,
										state: showState
									});
								}
								if (item.type == 'afternoon') {
									if (item.state == 'normal')
										showState = '正常'
									else if (item.state == 'leaveEarly')
										showState = '早退'
									this.statisticsInfo.push({
										PunchClockInfoTime: showClockInfoTime,
										punchClockLocation: item.punchClockLocation,
										state: showState
									});
								}
								this.calculateWorkingHours();

							})
						}
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//上班打卡
			morningPunchClock() {
				// let longitude = 113.410543
				// let latitude = 23.181915
				let punchClockTime = new Date()
				let data = {
					"uid": this.uid,
					"eid": this.eid,
					"punchClockTime": punchClockTime,
					"type": "morning"
				}
				request.toRequest('/punchClock/punchTheClock', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						let showClockInfoTime = new Date(punchClockTime).getHours() + ":" +
							(new Date(
									punchClockTime).getMinutes() < 10 ? '0' + new Date(
									punchClockTime)
								.getMinutes() : new Date(punchClockTime).getMinutes());
						let showState = ''
						if (res[1].data.states == 'normal')
							showState = '正常'
						else if (res[1].data.states == 'late')
							showState = '迟到'
						this.morningPunchClockInfo = {
							PunchClockInfoTime: showClockInfoTime,
							punchClockLocation: 'xxxxx',
							state: showState
						}
						this.alreadPunchClockMorning = false
						uni.showToast({
							title: '上班打卡成功！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})

			},
			//下班打卡
			afternoonPunchClock() {
							let nowYaer = new Date().getFullYear();
							let nowMonth = new Date().getMonth() + 1;
							let nowDay = new Date().getDate();
							let todDatas = {
								"nowYaer": nowYaer,
								"nowMonth": nowMonth,
								"nowDay": nowDay,
								"uid": this.uid,
							}
							request.toRequest('/punchClock/searchPunchClockInfo', todDatas, 'POST').then(
								res => {
									let status = res[1].data.status;
									if (status == 200) {
										if (res[1].data.resualt.length) {
											let punchClockTime = new Date()
											let data = {
												"uid": this.uid,
												"eid": this.eid,
												"punchClockTime": new Date(),
												"type": "afternoon"
											}
											request.toRequest('/punchClock/punchTheClock', data, 'POST')
												.then(res => {
													let status = res[1].data.status;
													if (status == 200) {
														let showClockInfoTime = new Date(
															punchClockTime).getHours() + ":" + (
															new Date(
																punchClockTime).getMinutes() < 10 ?
															'0' + new Date(
																punchClockTime)
															.getMinutes() : new Date(
																punchClockTime).getMinutes());
														let showState = ''
														if (res[1].data.states == 'normal')
															showState = '正常'
														else if (res[1].data.states == 'leaveEarly')
															showState = '早退'
														this.afternoonPunchClockInfo = {
															PunchClockInfoTime: showClockInfoTime,
															punchClockLocation: 'xxxxx',
															state: showState
														}
														this.alreadPunchClockAfternoon = false
														uni.showToast({
															title: '下班打卡成功！',
															icon: 'none',
															duration: 2000
														})
													} else if (status == 500) {
														uni.showToast({
															title: '服务器出错啦！',
															icon: 'none',
															duration: 2000
														})
													} else if (status == 300) {
														uni.navigateTo({
															url: '../signin/signin'
														})
													}
												})


										} else {
											uni.showToast({
												title: '请先打卡上班！',
												icon: 'none',
												duration: 2000
											})
										}
									} else if (status == 500) {
										uni.showToast({
											title: '服务器出错啦！',
											icon: 'none',
											duration: 2000
										})
									} else if (status == 300) {
										uni.navigateTo({
											url: '../signin/signin'
										})
									}
								})

			},
			//进入页面查询打卡数据
			searchPunchClockInfo() {
				let myday = new Date();
				let nowYaer = myday.getFullYear();
				let nowMonth = myday.getMonth() + 1;
				let nowDay = myday.getDate();
				let data = {
					"uid": this.uid,
					"nowYaer": nowYaer,
					"nowMonth": nowMonth,
					"nowDay": nowDay,
				}
				request.toRequest('/punchClock/searchPunchClockInfo', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						let resualt = res[1].data.resualt;
						if (resualt.length == 0)
							this.noticeBarText = '新的一天要从打卡开始，您还没有打卡，请尽快打卡！！！今天也要努力奋斗呀';
						else if (resualt.length == 1)
							this.noticeBarText = '早上已经打过卡了，下午下班了不要忘记打卡哦';
						else
							this.noticeBarText = '忙碌了一天的你，下班以后好好休息一下吧';
						resualt.forEach(item => {
					
							let showClockInfoTime = new Date(item.punchClockTime).getHours() + ":" + (
								new Date(
									item.punchClockTime).getMinutes() < 10 ? '0' + new Date(item
									.punchClockTime)
								.getMinutes() : new Date(item.punchClockTime).getMinutes());
							let showState = ''
							if (item.type == 'morning') {
								if (item.state == 'normal')
									showState = '正常'
								else if (item.state == 'late')
									showState = '迟到'
								this.morningPunchClockInfo = {
									PunchClockInfoTime: showClockInfoTime,
									punchClockLocation: 'xxxxx',
									state: showState
								}
								this.alreadPunchClockMorning = false;
								this.statisticsInfo.push(this.morningPunchClockInfo);
							}
							if (item.type == 'afternoon') {
								if (item.state == 'normal')
									showState = '正常'
								else if (item.state == 'leaveEarly')
									showState = '早退'
								this.afternoonPunchClockInfo = {
									PunchClockInfoTime: showClockInfoTime,
									punchClockLocation: 'xxxxx',
									state: showState
								}
								this.alreadPunchClockAfternoon = false;
								this.statisticsInfo.push(this.afternoonPunchClockInfo);
							}
							this.calculateWorkingHours();
						})
						this.dataDisplay = true;
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//计算工作时长
			calculateWorkingHours() {
				if (this.statisticsInfo.length == 2) {
					let start = 0;
					let end = 0;
					let splitsOne = this.statisticsInfo[0].PunchClockInfoTime.split(":");
					let splitsTwo = this.statisticsInfo[1].PunchClockInfoTime.split(":");
					start = parseInt(splitsOne[0]) * 60 + parseInt(splitsOne[1]);
					end = parseInt(splitsTwo[0]) * 60 + parseInt(splitsTwo[1]);
					this.workingHours = parseInt(((end - start) / 60)) + '小时' + ((end - start) % 60) + '分钟'
				}
			},
		}
	}
</script>

<style lang="scss">
	.content {
		background-color: rgba(243, 243, 243, 1);
		width: 100%;

		.punchClock {
			width: 100%;

			.personInfo {
				height: 180rpx;
				width: 100%;
				display: flex;
				flex-direction: row;
				background-color: #fff;
				position: relative;

				.left {
					margin: auto 30rpx;

					.infoImg {
						width: 30rpx;
						height: 30rpx;
						vertical-align: middle;
						margin-right: 10rpx;
					}

					.name {
						font-size: 36rpx;
						font-weight: 600;
						margin: 0 0 6rpx 10rpx;
					}

					.department {
						font-size: 24rpx;
						margin: 6rpx;
						color: #646464;
					}

					.position {
						margin: 6rpx;
						font-size: 24rpx;
						color: #646464;
					}
				}

				.headImg {
					width: 100rpx;
					height: 100rpx;
					border-radius: 50%;
					position: absolute;
					right: 0;
					top: 0;
					bottom: 0;
					// left: 0;
					margin: auto 60rpx;
				}
			}

			.punchClockContent {
				background-color: #fff;
				// margin-top: 4rpx;
				width: 100%;

				.punchClockTime {
					background-color: #fff;

					.timeMoring {
						float: left;
						margin: 40rpx 0 0 36rpx;
						color: #898989;
						font-size: 24rpx;

						.circular {
							width: 30rpx;
							height: 30rpx;
							background: #45B1FF;
							border-radius: 50%;
							margin: auto 10rpx auto auto;
							display: inline-block;
							vertical-align: middle;
						}

						.timeMoringContent {
							// width: 100%;
							margin: 15rpx;
							padding-left: 200rpx;
							border-left: 1px solid #d9d9d9;

							// min-height: 140rpx;
							.punchClockInfo {
								padding: 20rpx 0;
								position: relative;
								left: -175rpx;

								.time {
									font-size: 32rpx;
									color: #000;
									font-weight: 800;
									margin-bottom: 20rpx;

									.state {
										font-size: 25rpx;
										padding: 5rpx;
										display: inline;
										margin-left: 20rpx;
										font-weight: 200;
										border: 1px solid #08c21e;
										border-radius: 8rpx;
										color: #08c21e;
									}

									.stateOther {
										font-size: 25rpx;
										padding: 5rpx;
										display: inline;
										margin-left: 20rpx;
										font-weight: 200;
										border: 1px solid #e7c607;
										border-radius: 8rpx;
										color: #e7c607;
									}
								}

								.location {
									font-size: 15rpx;
									color: #898989;
									margin-bottom: 20rpx;
									// font-weight: 600;
								}
							}

							.punchClockCircular {
								width: 260rpx;
								height: 260rpx;
								background: #48AAFA;
								box-sizing: border-box;
								border: 2rpx solid #48AAFA;
								box-shadow: 0px 8rpx 20rpx 0rpx rgba(0, 0, 0, 0.3);
								border-radius: 50%;
								text-align: center;
								color: #fff;
								font-size: 32rpx;
								font-weight: 600;

								.text {
									text-align: center;
									padding-top: 70rpx;
									line-height: 50rpx;
								}
							}


						}
					}

					.timeAfternoon {
						float: left;
						margin: 0 0 0 36rpx;
						color: #898989;
						font-size: 24rpx;

						.punchClockInfo {
							padding: 20rpx 0;
							position: relative;
							left: -175rpx;

							.time {
								font-size: 32rpx;
								color: #000;
								font-weight: 800;
								margin-bottom: 20rpx;

								.state {
									font-size: 25rpx;
									padding: 5rpx;
									display: inline;
									margin-left: 20rpx;
									font-weight: 200;
									border: 1px solid #08c21e;
									border-radius: 8rpx;
									color: #08c21e;
								}

								.stateOther {
									font-size: 25rpx;
									padding: 5rpx;
									display: inline;
									margin-left: 20rpx;
									font-weight: 200;
									border: 1px solid #e7c607;
									border-radius: 8rpx;
									color: #e7c607;
								}
							}

							.location {
								font-size: 15rpx;
								color: #898989;
								margin-bottom: 20rpx;
								// font-weight: 600;
							}
						}

						.circular {
							width: 30rpx;
							height: 30rpx;
							background: #45B1FF;
							border-radius: 50%;
							margin: auto 10rpx auto auto;
							display: inline-block;
							vertical-align: middle;
						}

						.timeAfternoonContent {
							// width: 100%;
							margin: 15rpx;
							padding-left: 200rpx;

							// border-left: 1px solid #d9d9d9;
							.punchClockCircular {
								width: 260rpx;
								height: 260rpx;
								background: #48AAFA;
								box-sizing: border-box;
								border: 2rpx solid #48AAFA;
								box-shadow: 0px 8rpx 20rpx 0rpx rgba(0, 0, 0, 0.3);
								border-radius: 50%;
								text-align: center;
								color: #fff;
								font-size: 32rpx;
								font-weight: 600;

								.text {
									text-align: center;
									padding-top: 70rpx;
									line-height: 50rpx;
								}
							}


						}
					}

				}
			}
		}

		.Statistics {
			.dayPunchClock {
				// width: 80%;
				padding: 10rpx 10rpx 20rpx 10rpx;
				margin: 10rpx 10rpx 20rpx 10rpx;
				background-color: #fff;
				border-radius: 8rpx;
				box-sizing: border-box;

				.titleContent {
					margin: 5rpx 0 0 $uni-spacing-col-sm;

					.topTitle {
						font-size: 32rpx;
						margin-bottom: 6rpx;
					}

					.name {
						font-size: 24rpx;
						color: #acacac;
					}
				}

				.dayPunchClockInfo {
					display: flex;
					flex-direction: row;

					.left {
						margin: 5rpx 0 0 $uni-spacing-col-sm;
						text-align: center;

						.morning {
							font-size: 36rpx;
							font-weight: 600;
						}

						.line {
							width: 4rpx;
							height: 100rpx;
							background-color: #c1c1c1;
							margin: 10rpx auto;
						}

						.afternoon {
							font-size: 36rpx;
							font-weight: 600;
						}
					}

					.right {
						width: 100%;
						margin: 5rpx 0 0 30rpx;
						text-align: center;

						.dayInfo {
							text-align: left;
							font-size: 36rpx;

							.time {
								font-size: 24rpx;
							}

							.timeOther {
								font-size: 24rpx;
								color: red;
							}
						}

					}
				}
			}

		}
	}
</style>
