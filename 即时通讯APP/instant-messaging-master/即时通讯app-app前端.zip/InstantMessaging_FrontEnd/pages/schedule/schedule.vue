<template>
	<view>
		<ren-calendar ref='ren' :markDays='markDays' :headerBar='false' @onDayClick='onDayClick'></ren-calendar>
		<view class="change">选择日期：{{curDate}}</view>
		<view class="u-page">
			<u-list>
				<u-list-item v-for="(item, index) in indexList" :key="index" class="itemSchedule">
					<view class="listContent">
						<view class="left">
							{{item.startTime}}
						</view>
						<view class="right">
							{{item.name}}
						</view>
						<view class="delate" v-if="isOwn"  @tap="delateSchedule(item.scheduleID,index)">
							<image src="../../static/images/schedule/delate.png" mode=""></image>
						</view>
					</view>

				</u-list-item>
			</u-list>
		</view>
		<u-action-sheet :title="title" :show="show" :round="15" :closeOnClickOverlay="true" :closeOnClickAction="true"
			@close="closeUActionSheet">
			<slot>
				<view style="height: 55vh;">
					<u--form labelPosition="left" :model="model1" :rules="rules" ref="form1" class="addScheduleForm">
						<u-form-item label="主题" prop="schedule.name" borderBottom ref="item1">
							<u--input v-model="model1.schedule.name" border="none"></u--input>
						</u-form-item>
						<u-form-item label="开始" prop="schedule.startTime" borderBottom ref="item1">
							<u-datetime-picker @confirm="confirmStartTime" @close="closeStartTime"
								:show="showTimeChoose" v-model="startTime" mode="time"></u-datetime-picker>
							<view class="" @click="showTimeChoose = true">
								{{startTime}}
							</view>
						</u-form-item>
						<u-form-item label="结束" prop="schedule.endTime" borderBottom ref="item1">
							<u-datetime-picker @confirm="confirmEndTime" @close="closeEndTime" :show="showEndTimeChoose"
								v-model="endTime" mode="time"></u-datetime-picker>
							<view class="" @click="showEndTimeChoose = true">
								{{endTime}}
							</view>
						</u-form-item>
						<u-form-item label="时长" prop="schedule.duration" borderBottom ref="item1">
							<u--text :text="duration"></u--text>
						</u-form-item>
					</u--form>
					<u-button class="submitBtn"type="primary" text="提交" @tap="submit"></u-button>
				</view>

			</slot>
		</u-action-sheet>
		<view class="addSchedule" v-if="isOwn" @click="show = true">
			<image src="../../static/images/schedule/add.png" mode=""></image>
		</view>
	</view>
</template>

<script>
	import request from '../../network/request.js';
	import myFun from '@/commons/js/myFun.js';
	import RenCalendar from '@/components/ren-calendar/ren-calendar.vue'
	export default {
		components: {
			RenCalendar
		},
		data() {
			return {
				uid: '',
				eid: '',
				//日历
				curDate: '',
				markDays: [],
				//列表
				indexList: [],
				urls: [
					'https://cdn.uviewui.com/uview/album/1.jpg',
					'https://cdn.uviewui.com/uview/album/2.jpg',
					'https://cdn.uviewui.com/uview/album/3.jpg',
					'https://cdn.uviewui.com/uview/album/4.jpg',
					'https://cdn.uviewui.com/uview/album/5.jpg',
					'https://cdn.uviewui.com/uview/album/6.jpg',
					'https://cdn.uviewui.com/uview/album/7.jpg',
					'https://cdn.uviewui.com/uview/album/8.jpg',
					'https://cdn.uviewui.com/uview/album/9.jpg',
					'https://cdn.uviewui.com/uview/album/10.jpg',
				],
				//弹出框
				title: '标题',
				show: false,
				//表单
				showSex: false,
				model1: {
					schedule: {
						name: 'uView UI',
					},
				},
				rules: {
					'schedule.name': {
						type: 'string',
						required: true,
						message: '请填写姓名',
						trigger: ['blur', 'change']
					},
				},
				radio: '',
				switchVal: false,
				//时间选择器
				showTimeChoose: false,
				startTime: myFun.timestampToHM(new Date()),
				showEndTimeChoose: false,
				endTime: myFun.timestampToHM(new Date()),
				//时长
				duration: 0,
				isOwn: false
			};
		},
		onReady() {
			this.getStorages();
			let today = this.$refs.ren.getToday().date;
			this.curDate = today;
			this.markDays.push(today);
			this.loadmore()
			//加载当天日程
			let clickDate = this.curDate.split("-");
			this.getSchedule(clickDate[0], clickDate[1], clickDate[2]);
			if(myFun.getUrlKey('uid') == this.uid)
				this.isOwn = true;
		},
		methods: {
			//获取缓存
			getStorages: function() {
				const storageValue = uni.getStorageSync('user');
				if (storageValue) {
					this.uid = storageValue.id;
					this.eid = storageValue.enterpriseId;
				} else {
					uni.navigateTo({
						url: '../sign/signin'
					})
				}
			},
			//日历
			onDayClick(data) {
				this.curDate = data.date;
				let clickDate = data.date.split("-");
				this.indexList = [];
				this.getSchedule(clickDate[0], clickDate[1], clickDate[2]);
			},
			//列表
			// scrolltolower() {
			// 	this.loadmore()
			// },
			//列表
			loadmore() {
				// for (let i = 0; i < 5; i++) {
				// 	this.indexList.push({
				// 		url: this.urls[uni.$u.random(0, this.urls.length - 1)]
				// 	})
				// }
			},
			//弹出框
			closeUActionSheet() {
				this.show = false;
			},
			//时间选择器
			confirmStartTime() {
				this.showTimeChoose = false;

			},
			//关闭开始时间选择
			closeStartTime() {
				this.showTimeChoose = false;
			},
			//打开结束时间选择
			confirmEndTime(e) {
				this.endTime = e.value;
				let start = this.startTime.split(":");
				let end = this.endTime.split(":");
				let startMin = start[1][0] == '0' ? start[1][1] : start[1]
				let endMin = end[1][0] == '0' ? end[1][1] : end[1]

				if (parseInt(start) * 60 + parseInt(startMin) > parseInt(end[0]) * 60 + parseInt(endMin)) {
					uni.showToast({
						title: '开始时间不能大于结束时间！',
						icon: 'none',
						duration: 2000
					})
				} else {
					let time = (parseInt(end[0]) * 60 + parseInt(endMin)) - (parseInt(start[0]) * 60 + parseInt(startMin))

					if (time >= 60) {
						this.duration = parseInt(time / 60) + '小时' + parseInt(time % 60) + '分钟'
					} else {
						this.duration = time + '分钟'
					}
					this.showEndTimeChoose = false;
				}
			},
			//删除日程
			delateSchedule(scheduleID, index) {
				let data = {
					sid: scheduleID
				}
				request.toRequest('/schedule/delSchedule', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						this.indexList.splice(index, 1);
						uni.showToast({
							title: '删除成功！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				}).catch(err => {
					console.log(err);
				})
			},
			//关闭结束时间选择
			closeEndTime() {
				this.showEndTimeChoose = false;
			},
			//提交日程
			submit() {

				let data = {
					"uid": myFun.getUrlKey('uid'),
					"name": this.model1.schedule.name,
					"startTime": this.startTime,
					"endTime": this.endTime,
					"scheduleDate": this.curDate 
				}
				request.toRequest('/schedule/NewSchedule', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						this.indexList.push({
							scheduleID: res[1].data.scheduleID,
							startTime: this.startTime,
							name: this.model1.schedule.name
						})
						this.sortSchedule(this.indexList);
						uni.showToast({
							title: '添加成功！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				}).catch(err => {
					console.log(err);
				})
				this.sortSchedule(this.indexList);
				this.show = false;
			},
			//日程排序
			sortSchedule(arr) {
				let s = '';
				for (let i = 1; i < arr.length; i++) {
					for (let j = i; j > 0; j--) {
						if (arr[j].startTime < arr[j - 1].startTime) {
							s = arr[j];
							arr[j] = arr[j - 1];
							arr[j - 1] = s;
						}
					}
				}
			},
			//获取日程
			getSchedule(nowYaer, nowMonth, nowDay) {
				let _this = this
				let data = {
					"uid": myFun.getUrlKey('uid'),
					"nowYaer": nowYaer,
					"nowMonth": nowMonth,
					"nowDay": nowDay
				}
				request.toRequest('/schedule/getSchedule', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						res[1].data.backValue.forEach(item => {
							_this.indexList.push({
								scheduleID: item.scheduleID,
								startTime: item.startTime,
								endTime: item.endTime,
								name: item.name
							})
						})

						_this.sortSchedule(_this.indexList);
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				}).catch(err => {
					console.log(err);
				})
			}
		}
	}
</script>

<style lang="scss">
	.addScheduleForm {
		margin: 30rpx;
	}
	.submitBtn {
		margin-top: 80rpx;
		width: 80%;
	}

	.itemSchedule {
		margin: 20rpx;
		border-bottom: 2rpx solid rgb(241, 241, 241);
		padding-bottom: 20rpx;

		.listContent {
			.left {
				float: left;
				margin-right: 20rpx;
				padding-right: 20rpx;
				border-right: 4rpx solid rgb(42, 143, 253);
			}

			.right {
				float: left;
			}

			.delate {
				float: right;

				image {
					width: 40rpx;
					height: 40rpx;
				}
			}
		}
	}

	.change {
		border-bottom: 2rpx solid rgb(241, 241, 241);
		padding-bottom: 20rpx;
		margin: 20rpx;
	}

	.addSchedule {
		width: 112rpx;
		height: 112rpx;
		background: rgb(10, 89, 244);
		border-radius: 50%;
		position: fixed;
		right: 40rpx;
		bottom: 70rpx;
		box-shadow: 0px 16px 24px 0px rgba(10, 89, 244, 0.26),
			0px 2px 6px 0px rgba(10, 89, 244, 0.24),
			0px 0px 1px 0px rgba(10, 89, 244, 0.24);

		image {
			width: 80rpx;
			height: 80rpx;
			position: absolute;
			left: 0;
			right: 0;
			bottom: 0;
			top: 0;
			margin: auto;
		}
	}
</style>
