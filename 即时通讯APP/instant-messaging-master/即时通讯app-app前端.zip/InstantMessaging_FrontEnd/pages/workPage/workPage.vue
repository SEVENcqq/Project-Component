<template>
	<view class="content">
		<top-bar>
			<template v-slot:center>
				<view class="title">
					{{title}}
				</view>
			</template>
		</top-bar>
		<view class="main" v-if="!showEmpty">
			<view class="needDealt" v-for="(item, index) in needDealtList" :key="item.pfId" @tap="intoProcess(item)">
				<view class="left">
					<view class="leftContent">
						<image class="headImg" :src="item.imgurl" mode=""></image>
						<view class="name">{{item.sponsor}}</view>
						<view class="position">前端开发工程师</view>
					</view>

				</view>
				<view class="right">
					<view class="rightCount">
						<view class="processName">
							<view class="title">
								流程名称
							</view>
							<view class="Name">
								{{item.workFlowName}}
							</view>
						</view>
						<view class="creatTime">
							<view class="title">
								发起时间
							</view>
							<view class="Name">
								{{item.launchTime}}
							</view>
						</view>
						<view class="state">
							<view class="title">
								状态
							</view>
							<view
								:class="[item.state == '拒绝' ? 'showStateRefuse' : '',item.state == '待审批' ? 'showState' : '', item.state == '结束' ? 'showStateEnd' : '']">
								{{item.state}}
							</view>

						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="empty" v-if="showEmpty">
			<u-empty mode="data" icon="http://cdn.uviewui.com/uview/empty/data.png">
			</u-empty>
		</view>
	</view>
</template>

<script>
	import request from '../../network/request.js';
	import myFun from '../../commons/js/myFun.js'
	import topBar from '../../components/topBars/topBar.vue'
	export default {
		components: {
			topBar
		},
		data() {
			return {
				needDealtList: [],
				showEmpty: true,
				title: '',
			};
		},
		mounted() {
			if (myFun.getUrlKey('type') == 'needDealt') {
				this.title = '我的待办';
				this.getToDealtData();
			}
			else if (myFun.getUrlKey('type') == 'completed') {
				this.title = '我的已办';
				this.getCompleted();
			}
			else if (myFun.getUrlKey('type') == 'applied') {
				this.title = '我的申请';
				this.getApplied();
			}
		},
		methods: {
			//获取待办信息
			getToDealtData() {
				let data = {
					uid: myFun.getUrlKey('uid')
				}
				request.toRequest('/initiatingProcess/getDoitForMeData', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						if (res[1].data.backValue.length) {
							this.needDealtList = res[1].data.backValue;
							
							this.needDealtList.forEach(item => {
								item.launchTime = myFun.timestampToTime(item.launchTime);
								item.imgurl = this.apiUrl + item.imgurl;
								if (item.state == 'approve')
									item.state = '待审批'
								else if (item.state == 'end')
									item.state = '结束'
								else
									item.state = '拒绝'
							})
							this.showEmpty = false;
						} else {
							this.showEmpty = true;
						}

					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//获取已办信息
			getCompleted() {
				let data = {
					uid: myFun.getUrlKey('uid'),
					type: "completed"
				}
				request.toRequest('/initiatingProcess/searchCompletedOrApplied', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						if (res[1].data.backValue.length) {
							this.needDealtList = res[1].data.backValue;
							this.needDealtList.forEach(item => {
								item.launchTime = myFun.timestampToTime(item.launchTime);
								item.imgurl = this.apiUrl + item.imgurl;
								if (item.state == 'approve')
									item.state = '待审批'
								else if (item.state == 'end')
									item.state = '结束'
								else
									item.state = '拒绝'
							})
							this.showEmpty = false;
						} else {
							this.showEmpty = true;
						}

					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//获取申请信息
			getApplied() {
				let data = {
					uid: myFun.getUrlKey('uid'),
					type: "applied"
				}
				request.toRequest('/initiatingProcess/searchCompletedOrApplied', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						if (res[1].data.backValue.length) {
							this.needDealtList = res[1].data.backValue;
							this.needDealtList.forEach(item => {
								item.launchTime = myFun.timestampToTime(item.launchTime);
								item.imgurl = this.apiUrl + item.imgurl;
								if (item.state == 'approve')
									item.state = '待审批'
								else if (item.state == 'end')
									item.state = '结束'
								else
									item.state = '拒绝'
							})
							this.showEmpty = false;
						} else {
							this.showEmpty = true;
						}

					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//进入表单
			intoProcess(item) {
				if (myFun.getUrlKey('type') == 'needDealt') {
					uni.navigateTo({
						url: '../process/process?type=approve&workflowId=' + item.workFlowID + "&pfId=" + item.pfId
					})
				} else {
					uni.navigateTo({
						url: '../process/process?type=view&workflowId=' + item.workFlowID + "&pfId=" + item.pfId
					})
				}

			}
		}

	}
</script>

<style lang="scss">
	.content {
		background-color: rgb(255, 255, 255);
		// background-color: rgb(247, 247, 247);

		.top-bar {
			position: fixed;
			top: 0;
			left: 0;
			height: 88rpx;
			width: 100%;
			background-color: #E94057;
			text-align: center;
			color: #FFFFFF;
			line-height: 88rpx;
			font-size: 45rpx;
			font-weight: 100;
			font-family: AlibabaPuHuiTiL;
			z-index: 1001;
		}

		.main {
			padding: $uni-spacing-col-base;
			margin-top: 10rpx;

			.needDealt {
				// width: 100%;
				height: 350rpx;
				display: flex;
				flex-direction: row;
				// margin: 40rpx;
				border-radius: 40rpx;
				background: #FDFEFE;
				box-shadow: 0px 16px 24px 0px rgba(59, 58, 59, 0.1),
						0px 2px 6px 0px rgba(59, 58, 59, 0.0),
						0px 0px 1px 0px rgba(59, 58, 59, 0.04);
				position: relative;
				margin-bottom: 20rpx;

				.left {
					width: 30%;
					text-align: center;
					margin: auto;

					.leftContent {
						.headImg {
							width: 128rpx;
							height: 128rpx;
							border-radius: 50%;
							margin-bottom: 24rpx;
						}

						.name {
							font-size: 48rpx;
							font-weight: normal;
							line-height: 32px;
							letter-spacing: 0.3px;
							color: #101326;
						}

						.position {
							font-size: 28rpx;
							font-weight: normal;
							line-height: 20px;
							letter-spacing: 0.3px;
							color: #8F9BB3;
						}
					}

				}

				.right {
					text-align: left;
					// margin: auto ;
					padding-right: 50rpx;
					padding-left: 80rpx;
					background: #F6F8FA;
					border-left: 2rpx solid #e7e7e7;
					border-top-right-radius: 40rpx;
					border-bottom-right-radius: 40rpx;

					.rightCount {
						.processName {
							margin-bottom: 24rpx;
							margin-top: 15rpx;

							.title {
								font-size: 20rpx;
								font-weight: normal;
								line-height: 32rpx;
								letter-spacing: 0.7rpx;
								color: #8F9BB3;
								margin-bottom: 10rpx;
							}

							.Name {
								font-size: 35rpx;
								font-weight: normal;
								line-height: 48rpx;
								letter-spacing: 0.6rpx;
								color: #101326;
							}
						}

						.creatTime {
							margin-bottom: 24rpx;

							.title {
								font-size: 20rpx;
								font-weight: normal;
								line-height: 32rpx;
								letter-spacing: 0.7rpx;
								color: #8F9BB3;
								margin-bottom: 4rpx;
							}

							.Name {
								font-size: 35rpx;
								font-weight: normal;
								line-height: 48rpx;
								letter-spacing: 0.6rpx;
								color: #101326;
							}
						}

						.state {
							margin-bottom: 24rpx;

							.title {
								font-size: 20rpx;
								font-weight: normal;
								line-height: 32rpx;
								letter-spacing: 0.7rpx;
								color: #8F9BB3;
								margin-bottom: 4rpx;
							}

							.showState {
								font-size: 20rpx;
								font-weight: normal;
								line-height: 48rpx;
								letter-spacing: 0.6rpx;
								color: #4AC2AB;
								display: inline;
								padding: 5rpx;
								border-radius: 8rpx;
								background: rgba(74, 194, 171, 0.3)
							}

							.showStateRefuse {
								font-size: 20rpx;
								font-weight: normal;
								line-height: 48rpx;
								letter-spacing: 0.6rpx;
								color: #c20101;
								display: inline;
								padding: 5rpx;
								border-radius: 8rpx;
								background: rgba(194, 43, 5, 0.3)
							}

							.showStateEnd {
								font-size: 20rpx;
								font-weight: normal;
								line-height: 48rpx;
								letter-spacing: 0.6rpx;
								color: #1d98cc;
								display: inline;
								padding: 5rpx;
								border-radius: 8rpx;
								background: rgba(39, 169, 229, 0.3)
							}
						}
					}
				}
			}

		}
	}
</style>
