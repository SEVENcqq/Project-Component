<template>
	<view class="content">
		<view class="top-bar">
			<view class="top-bar-left">
				<image :src="imgurl" mode=""></image>
			</view>
			<view class="top-bar-center">
				通讯录
			</view>
		</view>
		<view class="main">
			<view class="model_one">
				<view class="memorandum" @tap="memorandum">
					<view class="title">
						备忘录
					</view>
					<view class="memorandumContent">
						<view class="memorandumList" v-for="(item, index) in memorandumList" :key="item._id">
							{{(index + 1) + '.'}}{{item.memorandumName}}
						</view>
					</view>
				</view>
				<view class="model_one_right">
					<view class="model_one_right_top">
						<view class="alreadyDone" @tap="intoCompleted">
							<view class="title">
								我的已办
							</view>
							<view class="alreadyDoneContent">
								{{completedCount}}
							</view>
						</view>
						<view class="apply" @tap="intoApplied">
							<view class="title">
								我的申请
							</view>
							<view class="applyContent">
								{{appliedCount}}
							</view>
						</view>
					</view>
					<view class="needDealt" @tap="intoNeedDealt">
						<view>
							<view class="title">
								我的待办
							</view>
							<view class="needDealtContent">
								{{agencyQuantity}}
							</view>
						</view>

						<image class="needDealtImg" src="../../static/images/workbench/needDealtImg.png" mode="">
						</image>
					</view>
				</view>
			</view>
			<view class="model_two">
				<view class="title">
					工具
				</view>
				<view class="content">
					<view class="tool">
						<view class="tool_item punchClock" @tap="punchClock">
							<image class="processImg" src="../../static/images/workbench/process.png" mode=""></image>
							<view class="toolName">
								打卡
							</view>
						</view>
						<view class="tool_item notice" @tap="notice">
							<image class="processImg" src="../../static/images/workbench/process.png" mode=""></image>
							<view class="toolName">
								公告
							</view>
						</view>

						<view class="tool_item schedule" @tap="schedule">
							<image class="processImg" src="../../static/images/workbench/process.png" mode=""></image>
							<view class="toolName">
								日程
							</view>
						</view>

					</view>
				</view>
			</view>
			<view class="model_three">
				<view class="title">
					企业工作流程
				</view>
				<view class="content"> 
					<view class="process" v-for="(item, index) in processList" :key="item.workFlowId"
						@tap="intoProcess(item.workFlowId)">
						<image class="processImg" src="../../static/images/workbench/process.png" mode=""></image>
						<view class="workFlowName">
							{{item.workFlowName}}
						</view>
					</view>
					<u-empty
							width="120"
							height="120"
							v-if="processList.length == 0"
					        mode="data"
					        icon="http://cdn.uviewui.com/uview/empty/data.png"
							style="margin-bottom: 30rpx;"
					>
					</u-empty>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import request from '../../network/request.js';
	export default {
		data() {
			return {
				uid: '',
				imgurl: '',
				eid: '',
				token: '',
				role: '',
				enterpriseId: '',
				processList: [],
				agencyQuantity: '', //我的待办数量
				completedCount: '', //已办数量
				appliedCount: '', //申请数量
				memorandumList: [],
			};
		},
		onShow() {
			this.getStorages();
			this.getProcess();
			this.getDoitForMeCount();
			this.getAppliedCount();
			this.getCompletedCount();
			this.getMemorandum();
		},
		methods: {
			//获取缓存
			getStorages: function() {
				const storageValue = uni.getStorageSync('user');
				if (storageValue) {
					this.uid = storageValue.id;
					this.eid = storageValue.enterpriseId;
					this.token = storageValue.token;
					this.imgurl = this.apiUrl + storageValue.imgurl;
					this.role = storageValue.role;
					this.enterpriseId = storageValue.enterpriseId;
				} else {
					uni.navigateTo({
						url: '../sign/signin'
					})
				}
			},
			//获取我的备忘录
			getMemorandum() {
				let data = {
					"uid": this.uid,
					"from": "workbench"
				}
				request.toRequest('/memorandum/getMemorandum', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						this.memorandumList = res[1].data.resualt
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//获取流程数据
			getProcess() {
				let data = {
					eid: this.enterpriseId,
					pageSize: 10,
					nowPage: 0,
				};
				request.toRequest('/backstage/SearchWorkFlow', data, 'POST')
					.then((res) => {

						this.processList = res[1].data.e;
					})
					.catch((err) => {
						console.log(err);
					});
			},
			//进入流程
			intoProcess(workFlowId) {
				uni.navigateTo({
					url: '../process/process?type=launch&workflowId=' + workFlowId
				})
			},
			//获取我的待办数量
			getDoitForMeCount() {
				let data = {
					uid: this.uid
				}
				request.toRequest('/initiatingProcess/doitForMe', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						this.agencyQuantity = res[1].data.resualt;
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//获取我的已办数量
			getCompletedCount() {
				let data = {
					uid: this.uid,
					type: "completed"
				}
				request.toRequest('/initiatingProcess/searchCompletedOrAppliedCount', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {
						this.completedCount = res[1].data.resualt;

					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				})
			},
			//获取我的申请数量
			getAppliedCount() {
				let data = {
					uid: this.uid,
					type: "applied"
				}
				request.toRequest('/initiatingProcess/searchCompletedOrAppliedCount', data, 'POST').then(res => {
					let status = res[1].data.status;
					if (status == 200) {

						this.appliedCount = res[1].data.resualt;
					} else if (status == 500) {
						uni.showToast({
							title: '服务器出错啦！',
							icon: 'none',
							duration: 2000
						})
					} else if (status == 300) {
						uni.navigateTo({
							url: '../signin/signin'
						})
					}
				}).catch(err => {
					console.log(err);
				})
			},
			//进入我的代办
			intoNeedDealt() {
				uni.navigateTo({
					url: '../workPage/workPage?type=needDealt&uid=' + this.uid
				})
			},
			//进入我的已办
			intoCompleted() {
				uni.navigateTo({
					url: '../workPage/workPage?type=completed&uid=' + this.uid
				})
			},
			//进入我的申请
			intoApplied() {
				uni.navigateTo({
					url: '../workPage/workPage?type=applied&uid=' + this.uid
				})
			},
			//进入打卡
			punchClock() {
				uni.navigateTo({
					url: '../punchClock/punchClock?&uid=' + this.uid
				})
			},
			//进入直播
			liveBroadcast() {
				uni.navigateTo({
					url: '../livebroadcast/livebroadcast?&uid=' + this.uid
				})
			},
			//进入公告
			notice() {
				uni.navigateTo({
					url: '../notice/notice?&uid=' + this.uid + "&eid=" + this.eid
				})
			},
			//进入日程
			schedule() {
				uni.navigateTo({
					url: '../schedule/schedule?&uid=' + this.uid + "&eid=" + this.eid
				})
			},
			//进入备忘录
			memorandum() {
				uni.navigateTo({
					url: '../memorandum/memorandum?&uid=' + this.uid + "&eid=" + this.eid
				})
			}
		}
	}
</script>

<style lang="scss">
	.content {
		// background-color: rgb(247, 247, 247);
		background-color: rgb(255, 255, 255);

		//头部样式
		.top-bar {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 88rpx;
			z-index: 1001;
			padding-top: var(--status-bar-height);
			box-sizing: border-box;
			background: rgba(255, 255, 255, 0.96);
			border-bottom: 1px solid $uni-bg-color;
			/**
		 * 此处有bug
		 box-shadow: 1px 1px 0px 0px rgba(0, 0, 0, 0.1);
		*/
			padding-left: $uni-spacing-col-base;

			.top-bar-left {
				float: left;
				padding-top: 15rpx;
				z-index: 1;
				margin-top: 5rpx;

				image {
					width: 68rpx;
					height: 68rpx;
					border-radius: 50%;

				}
			}

			.top-bar-center {
				position: absolute;
				left: 0;
				right: 0;
				// bottom: 0;
				margin: auto;
				text-align: center;
				padding-top: 20rpx;
				z-index: -1;
				font-size: 50rpx;
				font-weight: 200;
			}
		}

		.main {
			padding: $uni-spacing-col-base;
			margin-top: 88rpx;

			.model_one {
				display: flex;
				flex-direction: row;
				color: #3D3D3D;
				font-weight: 100;


				.memorandum {
					width: 288rpx;
					height: 326rpx;
					border-radius: 20rpx;
					background: #FFFFFF;
					// box-shadow: 0px 8rpx 20rpx 0px rgba(0, 0, 0, 0.3);
					box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.06),
						0px 2px 6px 0px rgba(0, 0, 0, 0.04),
						0px 0px 1px 0px rgba(0, 0, 0, 0.04);

					.title {
						padding: 20rpx;
					}

					.memorandumContent {
						width: 100%;
						height: 220rpx;

						overflow: hidden;
						overflow-y: scroll;

						.memorandumList {
							margin: 30rpx;

						}
					}

				}

				.model_one_right {
					.model_one_right_top {
						display: flex;
						flex-direction: row;

						.alreadyDone {
							width: 184rpx;
							height: 154rpx;
							border-radius: 20rpx;
							background: #FFFFFF;
							// box-shadow: 0px 4px 10px 0px rgba(0, 0, 0, 0.3);
							box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.06),
								0px 2px 6px 0px rgba(0, 0, 0, 0.04),
								0px 0px 1px 0px rgba(0, 0, 0, 0.04);
							margin-left: $uni-spacing-col-sm;
							margin-bottom: $uni-spacing-col-sm;
							text-align: center;

							.title {
								padding: 20rpx;
							}

							.alreadyDoneContent {
								font-size: 50rpx;
							}
						}

						.apply {
							width: 184rpx;
							height: 154rpx;
							border-radius: 20rpx;
							background: #FFFFFF;
							// box-shadow: 0px 8rpx 20rpx 0px rgba(0, 0, 0, 0.3);
							box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.06),
								0px 2px 6px 0px rgba(0, 0, 0, 0.04),
								0px 0px 1px 0px rgba(0, 0, 0, 0.04);
							margin-left: $uni-spacing-col-sm;
							margin-bottom: $uni-spacing-col-sm;
							text-align: center;

							.title {
								padding: 20rpx;
							}

							.applyContent {
								font-size: 50rpx;
							}
						}
					}


					.needDealt {
						width: 382rpx;
						height: 154rpx;
						border-radius: 20rpx;
						background: #FFFFFF;
						// box-shadow: 0px 8rpx 20rpx 0px rgba(0, 0, 0, 0.3);
						box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.06),
							0px 2px 6px 0px rgba(0, 0, 0, 0.04),
							0px 0px 1px 0px rgba(0, 0, 0, 0.04);
						margin-left: $uni-spacing-col-sm;
						display: flex;
						flex-direction: row;

						.title {
							padding: 20rpx;
						}

						.needDealtContent {
							padding-left: 60rpx;
							font-size: 50rpx;

						}

						.needDealtImg {
							width: 135rpx;
							height: 135rpx;
							float: right;
							margin: 10rpx 0 0 60rpx;
							z-index: 0;
						}

					}
				}

			}

			.model_two {
				width: 676rpx;
				border-radius: 20rpx;
				background: #FFFFFF;
				// box-shadow: 0px 8rpx 20rpx 0px rgba(0, 0, 0, 0.3);
				box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.06),
					0px 2px 6px 0px rgba(0, 0, 0, 0.04),
					0px 0px 1px 0px rgba(0, 0, 0, 0.04);
				margin-top: 46rpx;
				color: #3D3D3D;
				font-weight: 100;
				.title {
					padding: 20rpx;
				}
				.content {
					width: 100%;
					overflow: hidden;
					border-radius: 20rpx;
					.tool {
						width: 100%;
						// float: left;
						margin: 7rpx;
						text-align: center;
						font-size: 28rpx;
						.tool_item {
							width: 120rpx;
							float: left;
							margin: 7rpx;
							text-align: center;
							padding-bottom: 15rpx;

							.processImg {
								width: 70rpx;
								height: 70rpx;

							}
						}

					}
				}
			}

			.model_three {
				width: 676rpx;
				// height: 364rpx;
				border-radius: 20rpx;
				background: #FFFFFF;
				// box-shadow: 0px 8rpx 20rpx 0px rgba(0, 0, 0, 0.3);
				box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.06),
					0px 2px 6px 0px rgba(0, 0, 0, 0.04),
					0px 0px 1px 0px rgba(0, 0, 0, 0.04);
				margin-top: 46rpx;
				color: #3D3D3D;
				font-weight: 100;

				.title {
					padding: 20rpx;
				}
				.content {
					width: 100%;
					overflow: auto;
					border-radius: 20rpx;
					.process {
						width: 120rpx;
						float: left;
						margin: 7rpx;
						padding-bottom: 15rpx;
						text-align: center;
						font-size: 28rpx;
						.processImg {
							width: 70rpx;
							height: 70rpx;
						}
					}
				}
			}
		}
	}
</style>
