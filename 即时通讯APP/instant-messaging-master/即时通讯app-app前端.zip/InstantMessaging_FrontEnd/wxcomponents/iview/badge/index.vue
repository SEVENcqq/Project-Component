<template>
<uni-shadow-root class="iview-badge-index"><view class="i-class i-badge">
    <slot></slot>
    <view class="i-badge-dot" v-if="dot"></view>
    <view class="i-badge-count i-class-alone" v-else-if="count !== 0">{{ finalCount }}</view>
</view></uni-shadow-root>
</template>

<script>

global['__wxRoute'] = 'iview/badge/index'
Component({
    externalClasses: ['i-class', 'i-class-alone'],

    properties: {
        count: {
            type: Number,
            value: 0,
            observer: 'finalCount'
        },
        overflowCount: {
            type: Number,
            value: 99
        },
        dot: {
            type: Boolean,
            value: false
        },
    },
    data: {
        finalCount: 0
    },
    methods: {
        finalCount() {
            this.setData({
                finalCount: parseInt(this.data.count) >= parseInt(this.data.overflowCount) ? `${this.data.overflowCount}+` : this.data.count
            });
        },
    }
});
export default global['__wxComponents']['iview/badge/index']
</script>
<style platform="mp-weixin">
.i-badge{position:relative;display:inline-block;line-height:1;vertical-align:middle}.i-badge-count{position:absolute;transform:translateX(50%);top:-6px;right:0;height:18px;border-radius:9px;min-width:18px;background:#ed3f14;border:1px solid transparent;color:#fff;line-height:18px;text-align:center;padding:0 5px;font-size:12px;white-space:nowrap;transform-origin:-10% center;z-index:10;box-shadow:0 0 0 1px #fff;box-sizing:border-box;text-rendering:optimizeLegibility}.i-badge-count-alone{top:auto;display:block;position:relative;transform:translateX(0)}.i-badge-dot{position:absolute;transform:translateX(-50%);transform-origin:0 center;top:-4px;right:-8px;height:8px;width:8px;border-radius:100%;background:#ed3f14;z-index:10;box-shadow:0 0 0 1px #fff}
</style>