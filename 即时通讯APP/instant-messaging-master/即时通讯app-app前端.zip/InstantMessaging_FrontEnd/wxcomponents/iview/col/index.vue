<template>
<uni-shadow-root class="iview-col-index"><view :class="'i-class i-col '+(span ? 'i-col-span-' + span : '')+' '+(offset ? 'i-col-offset-' + offset : '')"><slot></slot></view></uni-shadow-root>
</template>

<script>

global['__wxRoute'] = 'iview/col/index'
Component({
    externalClasses: ['i-class'],

    relations: {
        '../row/index': {
            type: 'parent'
        }
    },

    properties: {
        span: {
            value: 0,
            type: Number
        },
        offset: {
            value: 0,
            type: Number
        }
    }
});
export default global['__wxComponents']['iview/col/index']
</script>
<style platform="mp-weixin">
.i-col{float:left;box-sizing:border-box;width:0}.i-col-span-1{display:block;width:4.16666667%}.i-col-offset-1{margin-left:4.16666667%}.i-col-span-2{display:block;width:8.33333333%}.i-col-offset-2{margin-left:8.33333333%}.i-col-span-3{display:block;width:12.5%}.i-col-offset-3{margin-left:12.5%}.i-col-span-4{display:block;width:16.66666667%}.i-col-offset-4{margin-left:16.66666667%}.i-col-span-5{display:block;width:20.83333333%}.i-col-offset-5{margin-left:20.83333333%}.i-col-span-6{display:block;width:25%}.i-col-offset-6{margin-left:25%}.i-col-span-7{display:block;width:29.16666667%}.i-col-offset-7{margin-left:29.16666667%}.i-col-span-8{display:block;width:33.33333333%}.i-col-offset-8{margin-left:33.33333333%}.i-col-span-9{display:block;width:37.5%}.i-col-offset-9{margin-left:37.5%}.i-col-span-10{display:block;width:41.66666667%}.i-col-offset-10{margin-left:41.66666667%}.i-col-span-11{display:block;width:45.83333333%}.i-col-offset-11{margin-left:45.83333333%}.i-col-span-12{display:block;width:50%}.i-col-offset-12{margin-left:50%}.i-col-span-13{display:block;width:54.16666667%}.i-col-offset-13{margin-left:54.16666667%}.i-col-span-14{display:block;width:58.33333333%}.i-col-offset-14{margin-left:58.33333333%}.i-col-span-15{display:block;width:62.5%}.i-col-offset-15{margin-left:62.5%}.i-col-span-16{display:block;width:66.66666667%}.i-col-offset-16{margin-left:66.66666667%}.i-col-span-17{display:block;width:70.83333333%}.i-col-offset-17{margin-left:70.83333333%}.i-col-span-18{display:block;width:75%}.i-col-offset-18{margin-left:75%}.i-col-span-19{display:block;width:79.16666667%}.i-col-offset-19{margin-left:79.16666667%}.i-col-span-20{display:block;width:83.33333333%}.i-col-offset-20{margin-left:83.33333333%}.i-col-span-21{display:block;width:87.5%}.i-col-offset-21{margin-left:87.5%}.i-col-span-22{display:block;width:91.66666667%}.i-col-offset-22{margin-left:91.66666667%}.i-col-span-23{display:block;width:95.83333333%}.i-col-offset-23{margin-left:95.83333333%}.i-col-span-24{display:block;width:100%}.i-col-offset-24{margin-left:100%}
</style>