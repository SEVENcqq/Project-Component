<template>
  <div id="testEcharts"></div>
</template>

<script>
import * as echarts from "echarts";

export default {
  name: "app",
  methods: {
    drawChart() {
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById("testEcharts"));
      // 绘制图表
      myChart.setOption({
        title: {
          text: "打卡数据",
        },
        xAxis: {
          type: 'category',
          data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            data: [150, 230, 224, 218, 135, 147, 260],
            type: 'line'
          }
        ],
        width: "100%",
        height: "50%",
      });
    },
  },
  mounted() {
    this.drawChart();
  },
};
</script>

<style>
#testEcharts {
  width: 90%;
  height: 70%;
  margin-top: 30px;
}
</style>