import Vue from 'vue'
import App from './App.vue'
import ElementUI from 'element-ui';
import router from './router/index'
import VueBus from 'vue-bus';
import store from '@/store/store'
import 'element-ui/lib/theme-chalk/index.css';
import 'vant/lib/index.css';
import './plugins/vant.js'

Vue.use(ElementUI);
Vue.use(VueBus);
Vue.config.productionTip = false
Vue.prototype.apiUrl = 'http://localhost:8081';


new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
