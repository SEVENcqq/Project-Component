import { request } from './request'

//获取考勤信息
export function CheckAttendance(datas) {
    return request({
        url: '/checkAttendance/getCheckAttendance',
        params: datas,
        method: 'POST'
    });
}
//搜索考勤信息
export function searchCheckAttendance(datas) {
    return request({
        url: '/checkAttendance/searchCheckAttendance',
        params: datas,
        method: 'POST'
    });
}
//查询用户id
export function searchUserId(datas) {
    return request({
        url: '/checkAttendance/searchUserId',
        params: datas,
        method: 'POST'
    });
}

//搜索打卡考勤信息
export function searchExportCA(datas) {
    return request({
        url: '/checkAttendance/searchExportCA',
        params: datas,
        method: 'POST'
    });
}
//导出打卡考勤信息为Excel
export function exportExcel(datas) {
    return request({
        url: '/checkAttendance/exportExcel',
        params: datas,
        method: 'GET'
    });
}