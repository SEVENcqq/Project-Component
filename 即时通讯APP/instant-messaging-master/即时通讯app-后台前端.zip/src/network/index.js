import { request } from './request'
//获取首页信息
export function getIndexInfo(datas) {
    return request({
        url: '/index/getIndexInfo',
        params: datas,
        method: 'POST'
    });
}
//统计企业男女比例
export function maleFemaleRatio(datas) {
    return request({
        url: '/index/maleFemaleRatio',
        params: datas,
        method: 'POST'
    });
}
//获取新员工信息
export function getNewEmployee(datas) {
    return request({
        url: '/index/getNewEmployee',
        params: datas,
        method: 'POST'
    });
}