<template>
    <div class="chackAttendanceContent">
        <div class="title">考勤管理</div>
        <div class="searchType">
            <el-form label-width="80px">
                <el-form-item label="时间筛选" class="item">
                    <el-date-picker v-model="value2" type="daterange" align="right" unlink-panels range-separator="至"
                        start-placeholder="开始日期" end-placeholder="结束日期" :picker-options="pickerOptions">
                    </el-date-picker>
                </el-form-item>
                <el-form-item label="打卡状态" class="item">
                    <el-select v-model="punchClockStatus" clearable placeholder="请选择">
                        <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="打卡时间" class="item">
                    <el-select v-model="punchClockTime" clearable placeholder="请选择">
                        <el-option v-for="item in punchClockTimeOptions" :key="item.value" :label="item.label"
                            :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="用户名" class="item">
                    <el-input v-model="searchUser" placeholder="请输入用户名"></el-input>
                </el-form-item>
                <el-form-item class="item">
                    <el-button type="primary" @click="search">查询</el-button>
                    <el-button type="primary" @click="exportExcelFun">导出Excel</el-button>
                </el-form-item>

            </el-form>

        </div>
        <el-table :data="tableData" style="width: 100%" stripe>
            <el-table-column prop="name" label="用户" width="180">
            </el-table-column>
            <el-table-column prop="punchClockTime" label="打卡时间" width="180">
            </el-table-column>
            <el-table-column prop="state" label="打卡状态">
            </el-table-column>
            <el-table-column prop="type" label="打卡类型">
            </el-table-column>
        </el-table>
        <div class="pagination">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                :current-page.sync="currentPage3" :page-size="10" layout="prev, pager, next, jumper" :total="allCount">
            </el-pagination>
        </div>
    </div>
</template>

<script>
import {
    CheckAttendance, searchCheckAttendance, searchUserId, searchExportCA, exportExcel
} from "@/network/checkAttendance.js";
import utils from "@/utils/utils.js";
export default {
    data() {
        return {
            //时间选择器
            pickerOptions: {
                shortcuts: [{
                    text: '最近一周',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '最近一个月',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '最近三个月',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
                        picker.$emit('pick', [start, end]);
                    }
                }]
            },
            value1: '',
            value2: '',
            //打卡状态
            options: [{
                value: 'normal',
                label: '正常'
            }, {
                value: 'late',
                label: '迟到'
            }, {
                value: 'leaveEarly',
                label: '早退'
            }],
            //打卡状态
            punchClockStatus: '',
            //打卡时间
            punchClockTimeOptions: [{
                value: 'morning',
                label: '上班'
            }, {
                value: 'afternoon',
                label: '下班'
            }],
            //上班时间
            punchClockTime: '',
            //搜索用户
            searchUser: '',

            //表格内容
            tableData: [],
            //分页
            nowPage: 0,
            pageSize: 10,
            currentPage3: 10,
            allCount: 0,
        };
    },
    mounted() {
        this.getCheckAttendance();
    },
    methods: {
        //分页器
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`);
        },
        //分页器
        handleCurrentChange(val) {
            this.nowPage = val - 1;
            this.getCheckAttendance();
        },
        //获取打卡数据
        getCheckAttendance() {
            let data = {
                eid: utils.getUrlKey("eid"),
                nowPage: this.nowPage,
                pageSize: this.pageSize
            };
            console.log(data);
            CheckAttendance(data)
                .then((res) => {
                    if (res.status == 200) {
                        this.tableData = res.backValue;
                        this.tableData.forEach(element => {
                            element.punchClockTime = utils.timestampToTime(element.punchClockTime);
                            if (element.state == 'late')
                                element.state = '迟到'
                            else if (element.state == 'normal')
                                element.state = '正常'
                            else
                                element.state = '早退'
                            if (element.type == 'morning')
                                element.type = '上班'
                            else
                                element.type = '下班'
                        });
                        this.allCount = res.allCount;
                        console.log(res);
                    }
                    else {
                        this.$message.error("服务器错误");
                    }
                })
                .catch((err) => {
                    console.log(err);
                });
        },
        //搜索
        search() {
            let data = {
                searchstr: {
                    punchClockTime: this.value2,
                    state: this.punchClockStatus,
                    type: this.punchClockTime,
                    searchUser: this.searchUser,
                    enterpriseID: utils.getUrlKey("eid"),
                },
                nowPage: this.nowPage,
                pageSize: this.pageSize
            }
            if (data.searchstr.searchUser) {
                let datas = {
                    searchUser: data.searchstr.searchUser
                }
                searchUserId(datas).then(res => {
                    if (res.status == 200) {
                        console.log(res);
                        data.searchstr.searchUser = res.userID;
                        this.searchCheckAttendanceFun(data);
                    }
                    else if (res.status == 500) {
                        this.$message.error('服务器错误');
                    }
                }).catch(err => {
                    this.$message.error(err);
                })
            }
            else {
                this.searchCheckAttendanceFun(data);
            }
        },
        //查询
        searchCheckAttendanceFun(data) {
            searchCheckAttendance(data).then(res => {
                if (res.status == 200) {
                    this.tableData = res.backValue;
                    this.tableData.forEach(element => {
                        element.punchClockTime = utils.timestampToTime(element.punchClockTime);
                        if (element.state == 'late')
                            element.state = '迟到'
                        else if (element.state == 'normal')
                            element.state = '正常'
                        else
                            element.state = '早退'
                        if (element.type == 'morning')
                            element.type = '上班'
                        else
                            element.type = '下班'
                    });
                    this.allCount = res.allCount;
                    console.log(res);
                }
                else if (res.status == 500)
                    this.$message.error("err");
            }).catch(err => {
                this.$message.error("err");
            })
        },
        //导出Excel
        exportExcelFun() {
            let data = {
                searchstr: {
                    punchClockTime: this.value2,
                    state: this.punchClockStatus,
                    type: this.punchClockTime,
                    searchUser: this.searchUser,
                    enterpriseID: utils.getUrlKey("eid"),
                },
            }
            if (data.searchstr.searchUser) {
                let datas = {
                    searchUser: data.searchstr.searchUser
                }
                searchUserId(datas).then(res => {
                    if (res.status == 200) {
                        console.log(res);
                        data.searchstr.searchUser = res.userID;
                        searchExportCA(data).then(res => {
                            let wherestr = JSON.stringify(res.wherestr)
                            const link = document.createElement('a');
                            link.style.display = 'none';
                            link.href = this.apiUrl + '/checkAttendance/exportExcel?wherestr=' + wherestr;
                            console.log(link);
                            link.download = data.fileName;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);

                        })
                    }
                    else if (res.status == 500) {
                        this.$message.error('服务器错误');
                    }
                }).catch(err => {
                    this.$message.error(err);
                })
            }
            else {
                searchExportCA(data).then(res => {
                    let wherestr = JSON.stringify(res.wherestr)
                    const link = document.createElement('a');
                    link.style.display = 'none';
                    link.href = this.apiUrl + '/checkAttendance/exportExcel?wherestr=' + wherestr;
                    console.log(link);
                    link.download = data.fileName;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);

                })
            }

        },
    },
}
</script>

<style lang="scss" scoped>
.chackAttendanceContent {
    padding-left: 20px;

    .title {
        font-family: DMSans-Bold;
        font-size: 38px;
        font-weight: 600;
        line-height: 61px;
        letter-spacing: 0px;
        /* 外部/text-primary */
        color: #3f3f3f;
        text-align: left;
        padding-top: 50px;
        padding-bottom: 50px;
    }

    .searchType {
        .item {
            float: left;
        }
    }

    .pagination {
        float: right;
        padding: 30px 50px 50px 0;
    }

    .el-table .warning-row {
        background: oldlace;
    }

    .el-table .success-row {
        background: #f0f9eb;
    }
}
</style>