<template>
  <div class="container">
    <div class="back" @click="bakc">
      <img class="imgback" src="@/assets/Index/back.png" alt="" />
    </div>
    <div class="home_content">
      <div class="left">
        <div class="macStyle"></div>
        <div class="logo">
          <div class="circular"></div>
          <span class="font">Instant_Messaging</span>
        </div>
        <div class="headImg">
          <img :src="this.userData.img" alt="" class="avatar" />
        </div>
        <div class="name">{{ this.userData.name }}</div>
        <div class="position">{{ this.userData.role }}</div>
        <div class="nav">
          <div
            class="nav_item"
            :class="this.$store.state.navIndex == '1' ? 'nav_item_active' : ''"
            @click="toIndex('1')"
          >
            😀 首页
          </div>
          <div
            class="nav_item"
            :class="this.$store.state.navIndex == '2' ? 'nav_item_active' : ''"
            @click="toMailList('2')"
          >
            📠 企业通讯录
          </div>
          <div
            class="nav_item"
            :class="this.$store.state.navIndex == '3' ? 'nav_item_active' : ''"
            @click="toForm('3')"
          >
            📑 表单配置
          </div>
          <div
            class="nav_item"
            :class="this.$store.state.navIndex == '4' ? 'nav_item_active' : ''"
            @click="toProcess('4')"
          >
            💼 流程配置
          </div>
          <div
            class="nav_item"
            :class="this.$store.state.navIndex == '5' ? 'nav_item_active' : ''"
            @click="toAllNotice('5')"
          >
            📰 公告管理
          </div>
          <div
            class="nav_item"
            :class="this.$store.state.navIndex == '6' ? 'nav_item_active' : ''"
            @click="toCheckAttendance('6')"
          >
            📆 考勤管理
          </div>
        </div>
      </div>
      <div class="right">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script>
import NavMenu from "../../components/main/navMenu/NavMenu.vue";
export default {
  components: {
    NavMenu,
  },
  data() {
    return {
      userData: {},
      // classActivit: this.$store.state.navIndex
    };
  },
  created() {
    this.getLocalStorage();
    console.log(this.$store.state.navIndex);
  },
  methods: {
    //获取缓存
    getLocalStorage() {
      let userStorage = JSON.parse(localStorage.getItem("backstage_user"));
      if (userStorage) {
        this.userData = userStorage;
        this.userData.img = this.apiUrl + this.userData.img;
        if (this.userData.role == "admin") {
          this.userData.role = "管理员";
        } else {
          this.userData.role = "创建者";
        }
      } else {
        this.$router.push({ path: "/Login" });
      }
    },
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath);
    },
    //退出
    bakc() {
      this.$alert("确定要退出吗", "提醒", {
        confirmButtonText: "确定",
        callback: (action) => {
          if (action == "confirm") {
            this.$router.push({
              path: "/Login",
              name: "Login",
            });
            localStorage.removeItem("backstage_user");
          }
        },
      });
    },
    //进入首页
    toIndex(index) {
      this.$store.state.navIndex = index;
      this.$router.push({
        path: "/Index",
        name: "Index",
        query: {
          eid: this.userData.eid,
          uid: this.userData.uid,
        },
      });
    },
    //进入通讯录
    toMailList(index) {
      this.$store.state.navIndex = index;
      this.$router.push({
        path: "/MailList",
        name: "MailList",
        query: {
          eid: this.userData.eid,
          uid: this.userData.uid,
        },
      });
    },
    //进入表单
    toForm(index) {
      this.$store.state.navIndex = index;
      this.$router.push({
        path: "/FormList",
        name: "FromList",
        query: {
          eid: this.userData.eid,
          uid: this.userData.uid,
        },
      });
    },
    //进入流程
    toProcess(index) {
      this.$store.state.navIndex = index;
      this.$router.push({
        path: "/ProcessList",
        name: "ProcessList",
        query: {
          eid: this.userData.eid,
          uid: this.userData.uid,
        },
      });
    },
    //进入所有公告
    toAllNotice(index) {
      this.$store.state.navIndex = index;
      this.$router.push({
        path: "/AllNotice",
        name: "AllNotice",
        query: {
          eid: this.userData.eid,
          uid: this.userData.uid,
        },
      });
    },
    //进入考勤
    toCheckAttendance(index) {
      this.$store.state.navIndex = index;
      this.$router.push({
        path: "/CheckAttendance",
        name: "CheckAttendance",
        query: {
          eid: this.userData.eid,
          uid: this.userData.uid,
        },
      });
    },
  },
};
</script>
<style scoped lang="scss" >
.container {
  background: rgb(247, 247, 247);
  // background: rgb(232,131,118);
  width: 100%;
  height: 100vh;
  .back {
    position: fixed;
    right: 100px;
    top: 20px;
    z-index: 1;

    .imgback {
      width: 30px;
      height: 30px;
    }
  }
  .home_content {
    width: 100%;
    height: 100vh;
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    margin: auto;
    background: rgba(255, 255, 255, 1);
    // border-radius: 20px;
    box-shadow: 0px 4px 10px 0px rgba(0, 0, 0, 0.3);

    // filter: blur(20px); /*滤镜*/
    .left {
      width: 20%;
      height: 100%;
      border-radius: 20px;
      background: #fff;
      float: left;
      position: relative;

      .macStyle {
        position: relative;
        margin-bottom: 20px;

        &::after {
          content: " ";
          background: #fc625d;
          width: 12px;
          height: 12px;
          border-radius: 50%;
          position: absolute;
          margin: 20px 0 0 20px;
          left: 0;
          box-shadow: 20px 0 #fdbc40, 40px 0 #35cd4b;
        }
      }

      .logo {
        width: 80%;
        height: 100px;
        margin: auto;
        // background: #000;
        font-size: 20px;
        padding-top: 50px;
        position: relative;

        .circular {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background-color: rgba(244, 222, 77, 1);
        }

        .font {
          position: absolute;
          left: 35px;
          top: 65px;
        }
      }

      .headImg {
        .avatar {
          width: 80px;
          height: 80px;
          border-radius: 50%;
          margin: auto;
        }
      }

      .name {
        padding: 10px 0 5px 0;
        font-size: 22px;
        font-weight: 600;
      }

      .position {
        color: rgb(131, 131, 131);
      }

      .nav {
        margin: 20px 0 0 20px;
        text-align: left;
        font-size: 22px;
        font-weight: 300;
        position: absolute;
        left: 30px;
        overflow: hidden;
        overflow-y: scroll;

        .nav_item {
          cursor: default;
          padding: 15px;
          border-radius: 10px;
        }

        .nav_item_active {
          background-image: linear-gradient(to right, #8385ff 0%, #23b5f9 100%);
          color: #fff;
        }
      }
    }

    .right {
      width: 80%;
      height: 100%;
      float: left;
      border-radius: 20px;
      overflow: hidden;
      overflow-y: scroll;
      // background: #000;
    }
  }
}

::-webkit-scrollbar {
  display: none;
}
</style>