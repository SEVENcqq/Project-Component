<template>
  <div class="index_content">
    <div class="title">企业信息</div>
    <div class="contenter">
      <div class="left">
        <div class="card">
          <div class="enterprise_card">
            <div class="enterprise_name info">{{ infoValue.ename }}</div>
            <div class="enterprise_Id info">{{ infoValue.eid }}</div>
            <div class="enterprise_info info">
              <div class="enterprise_builder">
                <div class="enterprise_info_title">创办人</div>
                <div>{{ infoValue.builderName }}</div>
              </div>
              <div class="enterprise_creatTime">
                <div class="enterprise_info_title">创办时间</div>
                <div>{{ infoValue.registrationTime }}</div>
              </div>
            </div>
          </div>
          <div class="other_info">
            <div class="info_item">
              <div class="item_name">员工</div>
              <div class="number">👨‍💼 {{ infoValue.EnterpriseEmployees }}</div>
            </div>
            <div class="info_item">
              <div class="item_name">部门</div>
              <div class="number">🏬 {{ infoValue.OrganizationalStructure }}</div>
            </div>
          </div>
        </div>
        <LineChart :data="datacollection"></LineChart>
      </div>
      <div class="right">
        <div class="statistics_Info">
          <div class="statistics_item">
            <div class="count">{{ infoValue.WorkFlow }}</div>
            <div class="time">12/20/11</div>
            <div class="img">
              <img src="@/assets/Index/formImg.png" alt="" />
            </div>
            <div class="statistics_Name">流程总数</div>
          </div>
          <div class="statistics_item">
            <div class="count">{{ infoValue.CustomerForm }}</div>
            <div class="time">12/20/11</div>
            <div class="img">
              <img src="@/assets/Index/formImg.png" alt="" />
            </div>
            <div class="statistics_Name">表单总数</div>
          </div>
          <div class="statistics_item">
            <div class="count">{{ infoValue.AnnouncementArticle }}</div>
            <div class="time">12/20/11</div>
            <div class="img">
              <img src="@/assets/Index/formImg.png" alt="" />
            </div>
            <div class="statistics_Name">公告总数</div>
          </div>
        </div>
        <div style="clear: both"></div>
        <div class="proportional_statistics">
          <div class="proportional_title">男女比例统计</div>
          <div class="proportional_content">
            <div class="proportional_item">
              <div class="emoji">🧍‍♂️</div>
              <div class="progress">
                <el-progress :text-inside="true" :stroke-width="26" :percentage="sexRatio.male"></el-progress>
              </div>
            </div>
            <div class="proportional_item">
              <div class="emoji">🧍‍♀️</div>
              <div class="progress">
                <el-progress :text-inside="true" :stroke-width="26" :percentage="sexRatio.female"></el-progress>
              </div>
            </div>
            <div class="proportional_item">
              <div class="emoji" style="font-size: 30px">🤖</div>
              <div class="progress">
                <el-progress :text-inside="true" :stroke-width="26" :percentage="sexRatio.asexual"></el-progress>
              </div>
            </div>
          </div>
        </div>
        <div class="newEmployee">
          <div class="newEmployee_title">新员工</div>
          <div class="newEmployeeContent">
            <div class="newEmployee_item"  v-for="item in newEmployee" :key="item.id">
              <img class="headImg" :src="item.imgurl" alt="" />
              <div class="employeeName">{{item.name}}</div>
            </div>
            <!-- <div class="newEmployee_item">
              <img class="headImg" src="@/assets/Index/add.png" alt="" />
              <div class="employeeName">导入</div>
            </div> -->
            <div style="clear: both"></div>
          </div>
        </div>
        <div class="other">
          <Pie></Pie>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import LineChart from "@/components/chart/LineChart.vue";
import Pie from "@/components/chart/Pie.vue";

import {
  getIndexInfo,
  maleFemaleRatio,
  getNewEmployee
} from "@/network/index.js";
import utils from "@/utils/utils.js";
export default {
  components: {
    LineChart,
    Pie,
  },
  data() {
    return {
      datacollection: {
        labels: [
          "January",
          "February",
          "March",
          "April",
          "May",
          "June",
          "July",
          "August",
          "September",
          "October",
          "November",
          "December",
        ],
        datasets: [
          {
            label: "GitHub Commits",
            backgroundColor: "rgba(0,193,222,.6)",
            hoverBackgroundColor: "rgba(0,193,222,.8)",
            data: [-4, 40, 20, 12, 39, 10, 40, 39, 80, 40, 20, 12, 11],
          },
        ],
      },
      infoValue: {}, //首页信息
      sexRatio: {}, //性别比例
      newEmployee:[], //新员工信息
    };
  }, //endData
  mounted() {
    this.getIndexValue();
    this.getMaleFemaleRatio();
    this.getNewEmployeeFun();
  },
  methods: {
    //获取首页信息
    getIndexValue() {
      let data = {
        eid: utils.getUrlKey("eid"),
      };
      getIndexInfo(data)
        .then((res) => {
          if (res.status == 200) {
            this.infoValue = res.backValue;
            this.infoValue.registrationTime = utils.timestampToTimeYMD(this.infoValue.registrationTime);
            this.infoValue.eid = utils.getUrlKey("eid");
          }
          else {
            this.$message.error("服务器错误");
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    //统计企业男女比例
    getMaleFemaleRatio() {
      let data = {
        eid: utils.getUrlKey("eid"),
      };
      maleFemaleRatio(data)
        .then((res) => {
          if (res.status == 200) {
            this.sexRatio = res.backValue;
          }
          else {
            this.$message.error("服务器错误");
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
      //获取新员工信息
  getNewEmployeeFun() {
    let data = {
      eid: utils.getUrlKey("eid"),
    };
    getNewEmployee(data)
      .then((res) => {
        if (res.status == 200) {
          this.newEmployee = res.backValue;
          this.newEmployee.forEach(element => {
            element.imgurl = this.apiUrl + element.imgurl;
          });
        }
        else {
          this.$message.error("服务器错误");
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }
  },

};
</script>

<style lang="scss" scoped>
.index_content {
  padding-left: 20px;

  .title {
    font-family: DMSans-Bold;
    font-size: 38px;
    font-weight: 600;
    line-height: 61px;
    letter-spacing: 0px;
    /* 外部/text-primary */
    color: #3f3f3f;
    text-align: left;
    padding-top: 50px;
     padding-bottom: 20px;
  }

  .contenter {
    display: flex;
    flex-direction: row;

    .left {
      width: 50%;
      height: 75vh;

      .card {
        width: 95%;
        height: 40%;
        border-radius: 28px;
        padding-top: 30px;
        background: linear-gradient(180deg,
            #ffffff -3%,
            #ffffff -3%,
            #ffffff 100%,
            #ffffff 100%);
        box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.06),
          0px 2px 6px 0px rgba(0, 0, 0, 0.04),
          0px 0px 1px 0px rgba(0, 0, 0, 0.04);

        .enterprise_card {
          width: 60%;
          height: 90%;
          margin-left: 25px;
          border-radius: 26px;
          float: left;
          color: #ffffff;
          text-align: left;
          background-image: linear-gradient(to right, #fa709a 0%, #fee140 100%);
          box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.08),
            0px 2px 6px 0px rgba(255, 213, 29, 0.08),
            0px 0px 1px 0px rgba(255, 213, 29, 0.08);

          .enterprise_name {
            padding-top: 20px;
            font-size: 25px;
            font-weight: 600;
          }

          .enterprise_Id {
            padding-top: 10%;
            font-size: 22px;
            font-weight: 300;
          }

          .enterprise_info {
            padding-top: 12%;

            .enterprise_builder {
              float: left;
              margin-right: 20px;
              font-size: 15px;

              .enterprise_info_title {
                font-size: 10px;
                font-weight: 100;
                padding-bottom: 5px;
              }
            }

            .enterprise_creatTime {
              float: left;
              margin-right: 20px;
              font-size: 15px;

              .enterprise_info_title {
                font-size: 10px;
                padding-bottom: 7px;
                font-weight: 100;
              }
            }
          }

          .info {
            margin-left: 20px;
          }
        }

        .other_info {
          float: left;
          width: 35%;

          .info_item {
            margin: 0 0 15px 30px;
            width: 80%;
            border-radius: 15px;
            padding: 6% 0 10% 0;
            box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.06),
              0px 2px 6px 0px rgba(0, 0, 0, 0.04),
              0px 0px 1px 0px rgba(0, 0, 0, 0.04);

            .item_name {
              font-size: 13px;
              text-align: left;
              padding: 0 0 5px 10px;
              font-weight: 400;
            }

            .number {
              font-family: Lato-Bold;
              font-size: 30px;
              font-weight: bold;
              line-height: 44px;
              text-align: center;
            }
          }
        }
      }
    }

    .right {
      width: 50%;
      height: 75vh;
      background: #fff;

      .statistics_Info {
        width: 100%;

        .statistics_item {
          width: 25%;
          height: 150px;
          background: #fff;
          float: left;
          margin: 5px 15px 25px 5px;
          border-radius: 15px;
          text-align: left;
          padding-left: 15px;
          padding-top: 15px;
          box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.06),
            0px 2px 6px 0px rgba(0, 0, 0, 0.04),
            0px 0px 1px 0px rgba(0, 0, 0, 0.04);

          .count {
            font-family: Lato-SemiBold;
            font-size: 23.98px;
            font-weight: 600;
            line-height: 34px;
            letter-spacing: 0px;
            color: #696969;
          }

          .time {
            font-family: DMSans-Regular;
            font-size: 14px;
            font-weight: normal;
            line-height: 20px;
            letter-spacing: 0px;
            color: #aeaeae;
            padding-bottom: 30px;
          }

          .img {
            img {
              width: 25px;
              height: 25px;
            }
          }

          .statistics_Name {
            font-family: DMSans-Regular;
            font-size: 18px;
            font-weight: normal;
            line-height: 28px;
            letter-spacing: 0px;
            /* 外部/text-primary */
            color: #3f3f3f;
          }
        }
      }

      .proportional_statistics {
        width: 100%;
        height: 30%;
        text-align: left;
        margin-bottom: 50px;
        font-family: DMSans-Bold;
        font-size: 20.11px;
        font-weight: 600;
        line-height: 28px;
        letter-spacing: 0px;
        /* 外部/text-primary */
        color: #3f3f3f;

        .proportional_title {
          padding-bottom: 20px;
        }

        .proportional_content {
          width: 90%;

          .proportional_item {
            margin-bottom: 30px;

            .emoji {
              width: 40px;
              height: 100%;
              vertical-align: middle;
              font-size: 40px;
              display: inline-block;
              margin-right: 10px;
              border-radius: 3px;
              /* 外部/1 */
            }

            .progress {
              width: 90%;
              display: inline-block;
            }
          }
        }
      }

      .newEmployee {
        // width: 50%;
        padding-right: 5%;
        float: left;
        box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.06),
          0px 2px 6px 0px rgba(0, 0, 0, 0.04),
          0px 0px 1px 0px rgba(0, 0, 0, 0.04);
        border-radius: 15px;

        .newEmployee_title {
          text-align: left;
          padding: 20px 0 0 20px;
          font-size: 20.11px;
          font-weight: 600;
          line-height: 28px;
          letter-spacing: 0px;
          /* 外部/text-primary */
          color: #3f3f3f;
        }

        .newEmployee_item {
          float: left;
          padding: 20px 0 20px 20px;

          .headImg {
            width: 45px;
            height: 45px;
            border-radius: 50%;
          }

          .employeeName {
            font-size: 12px;
            font-weight: normal;
            line-height: 17px;
            letter-spacing: 0px;
            /* 外部/text-primary */
            color: #3f3f3f;
          }
        }
      }

      .other {
        width: 50%;
        height: 155px;
        float: left;
        border-radius: 15px;
        margin-left: 20px;
        box-shadow: 0px 16px 24px 0px rgba(0, 0, 0, 0.06),
          0px 2px 6px 0px rgba(0, 0, 0, 0.04),
          0px 0px 1px 0px rgba(0, 0, 0, 0.04);
      }
    }
  }
}
</style>

