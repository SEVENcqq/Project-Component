<template>
<flow-panel></flow-panel>
</template>

<script>
import FlowPanel from "@/components/ef/panel.vue";
export default {
  components: {
    FlowPanel,
  },
};
</script>

<style>
</style>