1.修改config -- db.js 中的代码，进行数据库连接
    var db = mongoose.createConnection('mongodb://数据库用户名:数据库密码@数据库地址/数据库名称');
2.修改config -- credentials.js 中的代码，进行邮箱验证
    module.exports = {
        qq: {
            user: 'xxxxxxxxxx@qq.com',
            pass: 'xxxxxxxxxxxx'
        }

    }
    修改user字段，改成自己的qq号,pass字段自行百度“qq邮箱授权码如何获取”查看操作