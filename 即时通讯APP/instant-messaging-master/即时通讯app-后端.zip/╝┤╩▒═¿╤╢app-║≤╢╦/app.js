const express = require('express');
const jwt = require('./dao/jwt');

const app = express();
const port = 8081;
var bodyParser = require('body-parser');
const socket = require('./dao/socket');
//socket.io
var server = app.listen(3000);
var io = require('socket.io').listen(server);

require('./dao/socket')(io); 


//解析前端数据
app.use(bodyParser.urlencoded({ extended: false ,'Content-Type': 'application' }))
app.use(bodyParser.json());

//托管data静态资源目录,使得图片或文件资源能够以连接的形式访问
app.use(express.static('data'))

//解决跨域问题
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*')
    res.header('Access-Control-Allow-Headers', 'Authorization,X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method' )
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PATCH, PUT, DELETE')
    res.header('Allow', 'GET, POST, PATCH, OPTIONS, PUT, DELETE')
    next();
    });
    
//路由
require('./router/index.js')(app);
require('./router/files.js')(app);
require('./router/articalPhoto.js')(app);
require('./router/backstage.js')(app);




app.get('/', (req, res) => {res.send('你好')});

//token验证
app.use(function(req, res, next) {
    if(typeof(req.body.token) != 'undefined') {
        let token = req.body.token;
        let tokenMatch = jwt.verifyToken(token);
        if(tokenMatch) {
            //通过验证
            console.log('通过验证');
            next();
        }
        else {
            //返回登录界面
            console.log('token验证失败');
            res.send({status: 300});
        }
    }
})

//处理404错误
app.use(function(req, res, next) {
    let err = new Error('Not Foundsss');
    err.status = 404;
    next(err);
})

//处理500错误
app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.send(err.message);
})

app.listen(port, () => console.log(`'端口启动：' + ${port}`));