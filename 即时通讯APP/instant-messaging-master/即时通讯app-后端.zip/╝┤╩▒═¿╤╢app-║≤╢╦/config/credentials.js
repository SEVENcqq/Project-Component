//链接qq邮箱
module.exports = {
    qq: {
        user: '',
        pass: ''
    }

}