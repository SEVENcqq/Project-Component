var mongoose = require('mongoose');

var db = mongoose.createConnection('mongodb://admin:');
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  // we're connected!
  console.log('连接成功');
});

module.exports = db;