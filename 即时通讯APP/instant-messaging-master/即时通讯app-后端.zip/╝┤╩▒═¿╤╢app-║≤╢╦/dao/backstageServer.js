const express = require('express');
const { param } = require('express/lib/request');
const res = require('express/lib/response');
const { status } = require('express/lib/response');
var mongoose = require('mongoose');
var dbmodel = require('../model/dbmodel');
var bcrypt = require('./bcryptjs');
var jwt = require('./jwt')
var emailserver = require('./emailserver')
var nodeExcel = require('excel-export')
var utile = require('../utile/utile')

var User = dbmodel.model('User');
var Friend = dbmodel.model('Friend');
var Message = dbmodel.model('Message');
var Group = dbmodel.model('Group');
var GroupUser = dbmodel.model('GroupUser');
var GroupMsg = dbmodel.model('GroupMsg');
var Enterprise = dbmodel.model('Enterprise');
var EnterpriseEmployees = dbmodel.model('EnterpriseEmployees');
var Application = dbmodel.model('Application');
var CustomerForm = dbmodel.model('CustomerForm');
var WorkFlow = dbmodel.model('WorkFlow');
var AnnouncementArticle = dbmodel.model('AnnouncementArticle');
var OrganizationalStructure = dbmodel.model('OrganizationalStructure');
var CheckWorkAttendance = dbmodel.model('CheckWorkAttendance');

//用户验证(密码登录)
exports.userMatch = function (data, pwd, res) {
    let wherestr = { $or: [{ 'name': data }, { 'email': data }] };
    let out = { 'name': 1, 'imgurl': 1, 'pwd': 1 };
    User.find(wherestr, out, function (err, result) {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            if (result == '') {
                res.send({ status: 400 });
            }
            console.log(result);
            result.map(function (e) {
                const pwdMatch = bcrypt.verification(pwd, e.pwd);
                if (pwdMatch) {
                    let token = jwt.generateToken(e._id);
                    let backValue = {
                        id: e._id,
                        name: e.name,
                        imgurl: e.imgurl,
                        token: token
                    }
                    let wherestr = { 'userID': e._id };
                    console.log(wherestr);
                    EnterpriseEmployees.findOne(wherestr, function (err, EResult) {
                        if (err) {
                            res.send({ status: 500 });
                        }
                        else {
                            console.log('查询结果：', EResult);
                            if (EResult.role == 'builder' || EResult.role == 'admin') {
                                backValue['eid'] = EResult.enterpriseID;
                                backValue['role'] = EResult.role;
                                res.send({ status: 200, backValue });
                                
                            } else {
                                res.send({ status: 501 });
                            }

                        }
                    })
                }
                else {
                    res.send({ status: 400 });
                }
            })
        }
    })
}
//创建表单
exports.createForm = function (data, res) {
    let datas = {
        userID: data.uid,
        enterpriseID: data.eid,
        name: data.name,
        configModel: data.configModel,
        creatTime: new Date(),
        modificationTime: new Date(),
    }
    let customerForm = new CustomerForm(datas);

    customerForm.save(function (err,resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, id: resualt._id });
        }
    })
}
//单个查询表单信息
exports.searchFormOneData = function (data, res) {

    let wherestr = { '_id': data.formId };
    CustomerForm.find(wherestr).exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            console.log(resualt);
            let backValue = {
                configModel: resualt[0].configModel
            }
            res.send({ status: 200, backValue });
        }
    })
}
//分页查询表单信息
exports.searchFormData = function (data, res) {
    var skipNum = data.nowPage * data.pageSize; //跳过的条数
    let wherestr = { 'eid': data.eid };
    CustomerForm.find(wherestr).sort({ 'time': -1 }).skip(skipNum).populate('userID').limit(data.pageSize).exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            let e = []
            console.log(resualt);
            for (let i = 0; i < resualt.length; i++) {
                e.push({
                    formId: resualt[i]._id,
                    formName: resualt[i].name,
                    creatTime: resualt[i].creatTime,
                    createrName: resualt[i].userID.name,
                    modificationTime: resualt[i].modificationTime,
                })
            }
            res.send({ status: 200, e });
        }
    }) 
}
//删除表单
exports.delateForm = function (data, res) {
    let wherestr = { '_id': data.formId };
    CustomerForm.remove(wherestr).exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            res.send({ status: 200 });
        }
    })
}
//更新表单
exports.updataForm = function (data, res) {
    let updatastr = {
        configModel: data.configModel,
        modificationTime: new Date(),
    };
    CustomerForm.findByIdAndUpdate(data.formId, updatastr, function (err) {
        if (err)
            res.send({ status: 500 })
        else {
            console.log('更新成功');
            res.send({ status: 200 })
        }
    })
}
//创建流程
exports.createWorkFlow = function (data, res) {
    let updatastr = {
        userID: data.userID,
        enterpriseID: data.enterpriseID,
        name: data.name,
        associatedForm: data.associatedForm,
        creatTime: new Date(),
        modificationTime: new Date(),
    };
    let workFlow = new WorkFlow(updatastr);
    workFlow.save(function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, workFlowId: resualt._id });
        }
    })
}
//分页查询流程
exports.SearchWorkFlow = function (data, res) {
    var skipNum = data.nowPage * data.pageSize; //跳过的条数
    let wherestr = { 'eid': data.eid };
    console.log('分页查询流程');
    WorkFlow.find(wherestr).sort({ 'time': -1 }).skip(skipNum).populate('userID').limit(data.pageSize).exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            let e = []
            console.log(resualt);
            if (resualt.length) {
                for (let i = 0; i < resualt.length; i++) {
                    e.push({
                        workFlowId: resualt[i]._id,
                        workFlowName: resualt[i].name,
                        creatTime: resualt[i].creatTime,
                        createrName: resualt[i].userID.name,
                        modificationTime: resualt[i].modificationTime,
                    })
                }
            }

            res.send({ status: 200, e });
        }
    })
}
//统计流程
exports.searchWorkFlowCount = function (data, res) {
    let wherestr = { 'eid': data.eid };
    console.log('查询流程总数');
    WorkFlow.countDocuments(wherestr).exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            res.send({ status: 200, resualt });
        }
    })
}
//查询一条流程
exports.searchFlowOneData = function (data, res) {
    let wherestr = { '_id': data.workFlowId };
    console.log(data);
    WorkFlow.find(wherestr).exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            if (resualt.length) {
                let backValue = {
                    'associatedForm': resualt[0].associatedForm,
                    'workFlowModel': resualt[0].workFlowModel
                }
                res.send({ status: 200, backValue });
            } else {
                res.send({ status: 200 });
            }

        }
    })
}
//删除流程
exports.delateFlow = function (data, res) {
    let wherestr = { '_id': data.workFlowId };
    WorkFlow.remove(wherestr).exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            res.send({ status: 200 });
        }
    })
}
//更新流程
exports.updataWorkFlow = function (data, res) {
    let updatastr = {
        workFlowModel: data.workFlowModel,
        modificationTime: new Date(),
    };
    WorkFlow.findByIdAndUpdate(data.workFlowId, updatastr, function (err) {
        if (err)
            res.send({ status: 500 })
        else {
            console.log('更新成功');
            res.send({ status: 200 })
        }
    })
}

//获取企业员工
exports.getEmployees = function (data, res) {
    EnterpriseEmployees.find({ 'enterpriseID': data.enterpriseID }).populate('userID').exec(function (err, e) {
        if (err) {
            res.send({ status: 500 });
        } else {
            console.log(e);
            let backValue = []
            for (let item of e) {
                backValue.push({
                    userID: item.userID._id,
                    name: item.userID.name,
                    position: item.position,
                    department: item.department,
                })
            }
            res.send({ status: 200, backValue });

        }
    })
}
//上传公告文章
exports.uploadArticle = function (data, res) {
    let datas = {
        userID: data.uid,
        enterpriseID: data.eid,
        title: data.title,
        imgurl: data.imgurl,
        content: data.content,
        releaseTime: new Date(),
        modificationTime: new Date(),
    };
    console.log(data);
    let announcementArticle = new AnnouncementArticle(datas);
    announcementArticle.save(function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200 });
        }
    })
}

//分页获取文章展示--后台用
exports.getArticleInformationBackstage = function (data, res) {
    let wherestr = {
        enterpriseID: data.eid,
    };
    let backValue = [];
    var skipNum = data.nowPage * data.pageSize; //跳过的条数
    return new Promise(resolve => {
        AnnouncementArticle.find(wherestr).sort({ 'time': -1 }).populate("userID").skip(skipNum).limit(data.pageSize).exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            } else {
                console.log(resualt);

                resualt.forEach(item => {
                    backValue.push({
                        "articalId": item._id,
                        "title": item.title,
                        "imgurl": item.imgurl,
                        "userName": item.userID.name,
                        "headImgurl": item.userID.imgurl,
                        "releaseTime": item.releaseTime,
                        "modificationTime": item.modificationTime
                    })
                })
                resolve();
            }
        })
    }).then(result => {
        AnnouncementArticle.countDocuments(wherestr).exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            } else {
                console.log(resualt);
                res.send({ status: 200, backValue, count: resualt });
            }
        })
    })
}
//删除文章
exports.deleteArticle = function (data, res) {
    let wherestr = {
        _id: data.articalId,
    };
    AnnouncementArticle.remove(wherestr).exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            res.send({ status: 200 });
        }
    })
}
//获取文章内容 
exports.getArticalContent = function (data, res) {
    let wherestr = {
        _id: data.articalId,
    };
    AnnouncementArticle.findOne(wherestr).exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            let backValue = {
                content: resualt.content,
                title: resualt.title,
                imgurl: resualt.imgurl,

            }
            res.send({ status: 200, backValue });
        }
    })
}

//更新文章内容 
exports.updataArticalContent = function (data, res) {
    let updatastr = {
        title: data.title, //文章标题
        imgurl: data.imgurl, //封面链接
        content: data.content, //内容
        modificationTime: new Date(), //修改时间
    };
    AnnouncementArticle.findByIdAndUpdate(data.aid, updatastr, function (err) {
        if (err)
            res.send({ status: 500 })
        else {
            console.log('更新成功');
            res.send({ status: 200 })
        }
    })
}

//获取部门一级架构
exports.loadfirstnode = function (data, res) {
    let wherestr = {
        enterpriseID: data.eid,
        level: data.level
    };
    OrganizationalStructure.findOne(wherestr, function (err, resualt) {
        if (err)
            res.send({ status: 500 })
        else {
            res.send({ status: 200, resualt })
        }
    })
}
//获取部门子级架构
exports.loadchildnode = function (data, res) {
    let wherestr = {
        enterpriseID: data.eid,
        parentID: data.parentId,
    };
    OrganizationalStructure.find(wherestr, function (err, resualt) {
        if (err)
            res.send({ status: 500 })
        else {
            console.log(resualt);
            res.send({ status: 200, resualt })
        }
    })
}
//添加部门架构
exports.addDepartment = function (data, res) {
    let insertStr = {
        enterpriseID: data.eid,   //企业id
        departmentName: data.departmentName,   //组织名称
        parentID: data.parentID, //父节点id
        level: parseInt(data.level) + 1
    };
    console.log(insertStr);
    let organizationalStructure = new OrganizationalStructure(insertStr);
    organizationalStructure.save(function (err, resualt) {
        if (err)
            res.send({ status: 500 })
        else {
            console.log(resualt);
            res.send({ status: 200, resualt })
        }
    })
}
//删除部门
exports.delateDepartment = function (data, res) {
    let wherestr = {
        parentID: data.departmentId
    };
    OrganizationalStructure.countDocuments(wherestr, function (err, resualt) {
        if (err)
            res.send({ status: 500 })
        else {
            if (resualt)
                res.send({ status: 1 })
            else {
                let datas = { '_id': data.departmentId };
                OrganizationalStructure.remove(datas).exec(function (err) {
                    if (err) {
                        res.send({ status: 500 });
                    } else {
                        res.send({ status: 200 });
                    }
                })
            }
        }
    })
}
//修改部门名称
exports.changeDepartmentName = function (data, res) {
    let updatestr = {
        departmentName: data.departmentName
    };
    OrganizationalStructure.findByIdAndUpdate(data.departmentId, updatestr, function (err, resualt) {
        if (err)
            res.send({ status: 500 })
        else {
            res.send({ status: 200 })
        }
    })
}
//获取公司员工 
exports.getEnterpriseemployees = function (data, res) {
    let wherestr = {
        enterpriseID: data.eid
    };
    var skipNum = data.nowPage * data.pageSize; //跳过的条数
    let backValue = [];
    return new Promise(resolve => {
        EnterpriseEmployees.find(wherestr).sort({ 'time': -1 }).populate("userID").skip(skipNum).limit(data.pageSize).exec(function (err, resualt) {
            if (err)
                res.send({ status: 500 })
            else {
                resualt.forEach(item => {
                    backValue.push({
                        employeesId: item._id,
                        name: item.userID.name,
                        uid: item.userID._id,
                        email: item.userID.email,
                        imgurl: item.userID.imgurl,
                        sex: item.userID.sex,
                        joiningTime: item.joiningTime,
                        position: item.position,
                    })
                })
                resolve()
            }

        })
    }).then(result => {
        EnterpriseEmployees.countDocuments(wherestr).exec(function (err, resualt) {
            if (err)
                res.send({ status: 500 });
            else {
                res.send({ status: 200, backValue, count: resualt });
            }
        })
    })

}
//获取部门成员 
exports.getDepartmentMembers = function (data, res) {
    let wherestr = {
        department: data.department,
        enterpriseID: data.eid
    };
    let backValue = [];
    var skipNum = data.nowPage * data.pageSize; //跳过的条数
    return new Promise(resolve => {
        EnterpriseEmployees.find(wherestr).sort({ 'time': -1 }).populate("userID").skip(skipNum).limit(data.pageSize).exec(function (err, resualt) {
            if (err)
                res.send({ status: 500 })
            else {

                resualt.forEach(item => {
                    backValue.push({
                        employeesId: item._id,
                        uid: item.userID._id,
                        name: item.userID.name,
                        email: item.userID.email,
                        imgurl: item.userID.imgurl,
                        sex: item.userID.sex,
                        joiningTime: item.joiningTime,
                        position: item.position,
                    })
                })
                resolve();
            }
        })
    }).then(result => {
        EnterpriseEmployees.countDocuments(wherestr).exec(function (err, resualt) {
            if (err)
                res.send({ status: 500 })
            else {
                res.send({ status: 200, backValue, count: resualt })
            }
        })
    })
}
//添加部门成员 
exports.addDepartmentMembers = function (data, res) {
    let wherestr = { _id: { $in: data.uids } };
    let updatastr = { department: data.departmentId }
    EnterpriseEmployees.updateMany(wherestr, updatastr, function (err, resualt) {
        if (err)
            res.send({ status: 500 })
        else {
            res.send({ status: 200 })
        }
    })
}
//删除公司员工信息  
exports.deleteEmployees = function (data, res) {
    let wherestr = { 'userID': data.uid };
    //EnterpriseEmployees Friend Message Group GroupMsg CompletedAndApplied CheckWorkAttendance 
    return new Promise(function (resolve, reject) {
        EnterpriseEmployees.remove(wherestr).exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            } else {
                resolve();
            }
        })
    }).then(function (result) {
        Friend.remove({ $or: [{ 'userID': data.uid }, { 'friendID': data.uid }] }).exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            } else {
                resolve();
            }
        })
    }, function (reason) {
        console.log(reason);
    }).then(function (result) {
        Message.remove({ $or: [{ 'userID': data.uid }, { 'friendID': data.uid }] }).exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            } else {
                resolve();
            }
        })
    }, function (reason) {
        console.log(reason);
    }).then(function (result) {
        Group.remove({ $or: [{ 'userID': data.uid }, { 'friendID': data.uid }] }).exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            } else {
                resolve();
            }
        })
    }, function (reason) {
        console.log(reason);
    }).then(function (result) {
        CompletedAndApplied.remove(wherestr).exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            } else {
                resolve();
            }
        })
    }, function (reason) {
        console.log(reason);
    }).then(function (result) {
        CheckWorkAttendance.remove({ $or: [{ 'userID': data.uid }, { 'friendID': data.uid }] }).exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            } else {
                res.send({ status: 200 });
            }
        })
    }, function (reason) {
        console.log(reason);
    }).catch(function onRejected(error) {
        res.send(error);
    })
}
/******************首页信息获取***** Enterprise EnterpriseEmployees OrganizationalStructure WorkFlow CustomerForm AnnouncementArticle***************/
exports.getIndexInfo = function (data, res) {
    let backValue = {};
    let wherestr = { 'Enterprise': data.eid };
    return new Promise(resolve => {
        Enterprise.findOne(wherestr).populate("userID").exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            } else {
                backValue.ename = resualt.name;
                backValue.registrationTime = resualt.registrationTime;
                backValue.builderName = resualt.userID.name;
                resolve();
            }
        })
    }).then(result => {
        return new Promise((resolve) => {
            EnterpriseEmployees.countDocuments(wherestr).exec(function (err, resualt) {
                if (err) {
                    res.send({ status: 500 });
                } else {
                    backValue.EnterpriseEmployees = resualt;
                    resolve();
                }
            })
        })
    }).then(result => {
        return new Promise((resolve) => {
            OrganizationalStructure.countDocuments(wherestr).exec(function (err, resualt) {
                if (err) {
                    res.send({ status: 500 });
                } else {
                    backValue.OrganizationalStructure = resualt;
                    resolve();
                }
            })
        })
    }).then(result => {
        return new Promise((resolve) => {
            WorkFlow.countDocuments(wherestr).exec(function (err, resualt) {
                if (err) {
                    res.send({ status: 500 });
                } else {
                    backValue.WorkFlow = resualt;
                    resolve();
                }
            })
        })
    }).then(result => {
        return new Promise((resolve) => {
            CustomerForm.countDocuments(wherestr).exec(function (err, resualt) {
                if (err) {
                    res.send({ status: 500 });
                } else {
                    backValue.CustomerForm = resualt;
                    resolve();
                }
            })
        })
    })
        .then(result => {
            return new Promise((resolve) => {
                AnnouncementArticle.countDocuments(wherestr).exec(function (err, resualt) {
                    if (err) {
                        res.send({ status: 500 });
                    } else {
                        backValue.AnnouncementArticle = resualt;
                        res.send({ status: 200, backValue });

                    }
                })
            })
        })
}
//统计企业男女比例
exports.maleFemaleRatio = function (data, res) {
    EnterpriseEmployees.find({ enterpriseID: data.eid }).populate("userID").exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            let numberPeople = resualt.length;
            let male = 0;
            let female = 0;
            resualt.forEach(item => {
                if (item.userID.sex == 'male') {
                    male++;
                }
                else if (item.userID.sex == 'female') {
                    female++;
                }
            })
            let backValue = {
                male: parseInt(male / numberPeople * 100),
                female: parseInt(female / numberPeople * 100),
                asexual: 100 - parseInt(male / numberPeople * 100) - parseInt(female / numberPeople * 100),
            }
            res.send({ status: 200, backValue });
        }
    })
}
//获取新员工信息（最近加入的三个员工信息） 
exports.getNewEmployee = function (data, res) {
    EnterpriseEmployees.find({ enterpriseID: data.eid }).sort({ 'joiningTime': -1 }).populate("userID").exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            let backValue = [];
            console.log(resualt);
            if(resualt.length < 3) {
                for (let index = 0; index < resualt.length; index++) {
                    backValue.push({
                        name: resualt[index].userID.name,
                        imgurl: resualt[index].userID.imgurl,
                        id: resualt[index].userID._id
                    })
                }
            }
            else {
                for (let index = 0; index < 3; index++) {
                    backValue.push({
                        name: resualt[index].userID.name,
                        imgurl: resualt[index].userID.imgurl,
                        id: resualt[index].userID._id
                    })
                }
            }

            res.send({ status: 200, backValue });
        }
    })
}
/********************考勤打卡*********************************/
//获取考勤信息 getCheckAttendance
exports.getCheckAttendance = function (data, res) {
    let wherestr = {
        enterpriseID: data.eid,
    };
    var skipNum = data.nowPage * data.pageSize; //跳过的条数
    let backValue = [];
    return new Promise(resolve => {
        CheckWorkAttendance.find(wherestr).sort({ 'punchClockTime': -1 }).skip(skipNum).limit(data.pageSize).populate("userID").exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            } else {
                resualt.forEach(item => {
                    backValue.push({
                        name: item.userID.name,
                        punchClockTime: item.punchClockTime,
                        state: item.state,
                        type: item.type,
                    })
                })
                resolve();
            }
        })
    }).then(result => {
        CheckWorkAttendance.countDocuments(wherestr).exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            } else {
                res.send({ status: 200, backValue, allCount: resualt });
            }
        })
    })
}
//搜索打卡数据 searchCheckAttendance
exports.searchCheckAttendance = function (data, res) {
    let wherestr = {};
    let backValue = [];
    let searchStr = JSON.parse(data['searchstr'])
    var skipNum = data.nowPage * data.pageSize; //跳过的条数
    for (var key in searchStr) {
        if (searchStr[key]) {
            if (key == 'punchClockTime') {
                let startTime = new Date(searchStr[key][0]);
                let endTime = new Date(searchStr[key][1]);
                const start = startTime.getFullYear() + '-' + (parseInt(startTime.getMonth()) + 1) + '-' + startTime.getDate() + ' 00:00:00';
                const end = endTime.getFullYear() + '-' + (parseInt(endTime.getMonth()) + 1) + '-' + endTime.getDate() + ' 23:59:59';
                wherestr[key] = { '$gte': new Date(start), '$lte': new Date(end) }
            }
            else if (key == 'searchUser') {
                wherestr['userID'] = searchStr[key]
            }
            else
                wherestr[key] = searchStr[key]
        }
    }
    console.log(wherestr);
    return new Promise(resolve => {
        CheckWorkAttendance.find(wherestr).sort({ 'punchClockTime': -1 }).skip(skipNum).limit(data.pageSize).populate("userID").exec(function (err, resualt) {
            if (err) {
                console.log(err);
                res.send({ status: 500 });
            } else {

                resualt.forEach(item => {
                    backValue.push({
                        name: item.userID.name,
                        punchClockTime: item.punchClockTime,
                        state: item.state,
                        type: item.type,
                    })
                })
                resolve();
            }
        })
    }).then(result => {
        CheckWorkAttendance.countDocuments(wherestr).exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            } else {
                res.send({ status: 200, backValue, allCount: resualt });
            }
        })
    })

}
//查询导出打卡考勤信息
exports.searchExportCA = function (data, res) {
    let wherestr = {};
    let backValue = [];
    let searchStr = JSON.parse(data['searchstr'])
    for (var key in searchStr) {
        if (searchStr[key]) {
            if (key == 'punchClockTime') {
                let startTime = new Date(searchStr[key][0]);
                let endTime = new Date(searchStr[key][1]);
                const start = startTime.getFullYear() + '-' + (parseInt(startTime.getMonth()) + 1) + '-' + startTime.getDate() + ' 00:00:00';
                const end = endTime.getFullYear() + '-' + (parseInt(endTime.getMonth()) + 1) + '-' + endTime.getDate() + ' 23:59:59';
                wherestr[key] = { '$gte': new Date(start), '$lte': new Date(end) }
            }
            else if (key == 'searchUser') {
                wherestr['userID'] = searchStr[key]
            }
            else
                wherestr[key] = searchStr[key]
        }
    }
    res.send({ status: 200, wherestr });


}
//下载Excel
exports.exportExcel = function (data, res) {
    /********导出Excel */
    console.log(data.wherestr);
    let wherestr = JSON.parse(data.wherestr)
    let backValue = [];
    CheckWorkAttendance.find(wherestr).sort({ 'punchClockTime': -1 }).populate("userID").exec(function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        } else {
            resualt.forEach(item => {
                if (item.state == 'late')
                    item.state = '迟到'
                else if (item.state == 'normal')
                    item.state = '正常'
                else
                    item.state = '早退'
                if (item.type == 'morning')
                    item.type = '上班'
                else
                    item.type = '下班'
                backValue.push({
                    name: item.userID.name,
                    punchClockTime: utile.timestampToTime(item.punchClockTime),
                    state: item.state,
                    type: item.type,
                })
            })
            console.log(backValue);
            var conf = {
                cols: [],
                rows: [],
            };
            conf.name = "mysheet";
            conf.cols = [{
                caption: '用户',
                type: 'string',
            }, {
                caption: '打卡时间',
                type: 'string',
            }, {
                caption: '打卡状态',
                type: 'string'
            }, {
                caption: '打卡类型',
                type: 'string'
            }];
            for (let i = 0; i < backValue.length; i++) {
                conf.rows.push([backValue[i].name, backValue[i].punchClockTime, backValue[i].state, backValue[i].type])
            }
            console.log('转换Excel');
            var result = nodeExcel.execute(conf);
            res.setHeader('Content-Type', 'application/vnd.openxmlformats');
            res.setHeader("Content-Disposition", "attachment; filename=" + "Report.xlsx");
            res.end(result, 'binary');
            console.log('导出完毕');
        }
    })

}
//查询用户id searchUserId
exports.searchUserId = function (data, res) {
    let wherestr = { $or: [{ 'name': { $regex: data.searchUser } }, { 'email': { $regex: data.searchUser } }] };
    User.findOne(wherestr).exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            res.send({ status: 200, userID: resualt._id });
        }
    })
}

//获取员工职位和员工权限角色 
exports.getEmployeesInfo = function (data, res) {
    let wherestr = {
        userID: data.uid
    };
    EnterpriseEmployees.findOne(wherestr).exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            let backValue = {
                position: resualt.position,
                role: resualt.role
            }
            res.send({ status: 200, backValue });
        }
    })
}
//更新员工职位和员工权限角色
exports.updateEmployeesInfo = function (data, res) {
    let updatastr = {
        position: data.position,
        role: data.role
    };
    console.log(data);
    EnterpriseEmployees.updateOne({ userID: data.uid }, updatastr, function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            res.send({ status: 200 });
        }
    })
}