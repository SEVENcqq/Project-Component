//密码加密解密
var bcryptjs = require('bcryptjs');

//生成hash密码
exports.encryption = function(e) {
    //生成随机salt

    let salt = bcryptjs.genSaltSync(10);
    let hash = bcryptjs.hashSync(e, salt);
    return hash;
}

//解密,第一个参数为传入的密码，第二个参数为数据库中查询出的密码
exports.verification = function(e, hash) {
    let verif = bcryptjs.compareSync(e, hash);
    return verif;
}