const express = require('express');
const { param } = require('express/lib/request');
const res = require('express/lib/response');
const { status } = require('express/lib/response');
var mongoose = require('mongoose');
var dbmodel = require('../model/dbmodel');
var bcrypt = require('./bcryptjs');
var jwt = require('./jwt')
var emailserver = require('./emailserver')

var User = dbmodel.model('User');
var Friend = dbmodel.model('Friend');
var Message = dbmodel.model('Message');
var Group = dbmodel.model('Group');
var GroupUser = dbmodel.model('GroupUser');
var GroupMsg = dbmodel.model('GroupMsg');
var Enterprise = dbmodel.model('Enterprise');
var EnterpriseEmployees = dbmodel.model('EnterpriseEmployees');
var Application = dbmodel.model('Application');
var WorkFlow = dbmodel.model('WorkFlow');
var ProcessInformation = dbmodel.model('ProcessInformation');
var CompletedAndApplied = dbmodel.model('CompletedAndApplied');
var CheckWorkAttendance = dbmodel.model('CheckWorkAttendance');
var AnnouncementArticle = dbmodel.model('AnnouncementArticle');
var OrganizationalStructure = dbmodel.model('OrganizationalStructure');
var Schedule = dbmodel.model('Schedule');
var Memorandum = dbmodel.model('Memorandum');
var UsersChatRoom = dbmodel.model('UsersChatRoom');

//建立用户
exports.buildUser = function (name, email, pwd, res) {
    //密码加密
    let passWord = bcrypt.encryption(pwd);
    let data = {
        name: name,
        email: email,
        pwd: passWord,
        time: new Date()
    }

    let user = new User(data);
    user.save(function (err, resualt) {
        if (err)
            res.send({ status: 500 });
        else {
            res.send({ status: 200, "id": resualt._id });
            console.log('成功注册');
        }
    })
}

//匹配用户表元素个数
exports.countUserValue = function (data, type, res) {
    let wherestr = {};
    wherestr[type] = data;

    User.countDocuments(wherestr, function (err, result) {
        if (err)
            res.send({ status: 500 });
        else {
            res.send({ status: 200, result });
        }
    })
}

//用户验证(密码登录)
exports.userMatch = function (data, pwd, res) {
    let wherestr = { $or: [{ 'name': data }, { 'email': data }] };
    let out = { 'name': 1, 'imgurl': 1, 'pwd': 1 };
    User.find(wherestr, out, function (err, result) {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            if (result == '') {
                res.send({ status: 400 });
            }
            result.map(function (e) {
                const pwdMatch = bcrypt.verification(pwd, e.pwd);
                if (pwdMatch) {
                    let token = jwt.generateToken(e._id);
                    let backValue = {
                        id: e._id,
                        name: e.name,
                        imgurl: e.imgurl,
                        token: token
                    }
                    res.send({ status: 200, backValue });
                }
                else {
                    res.send({ status: 400 });
                }
            })
        }
    })
}
//用户验证(验证发送的邮箱验证码是否正确)
exports.matchCode = function (data, res) {
    let wherestr = { 'email': data.email };
    User.findOne(wherestr, function (err, result) {

        if (err) {
            res.send({ status: 500 });
        }
        else {
            if (result == '') {
                res.send({ status: 400 });
            }
            else {
                let token = jwt.generateToken(result._id);
                let backValue = {
                    id: result._id,
                    name: result.name,
                    imgurl: result.imgurl,
                    token: token
                }
                if (result.checkCode == data.code) {
                    res.send({ status: 200, backValue });
                }
                else {
                    res.send({ status: 500 });
                }
            }
        }
    })
}
//用户验证(邮箱验证码生成)
exports.generateVerificationCode = function (data, res) {
    let timer;
    let code = Math.floor(Math.random() * (9999 - 1000)) + 1000;//随机生成四位数
    User.updateOne({ email: data.email }, { checkCode: code }, function (err, resualt) {
        if (err) {
            res.send({ status: 500 })
        }
        else {
            res.send({ status: 200 })
            emailserver.emailLogin(data.email, code);
            if (timer) {
                clearTimeout(timer);
            }
            timer = setTimeout(function () {
                User.updateOne({ email: data.email }, { checkCode: 'none' }, function (err, resualt) {
                    if (err) {
                        console.log(err);
                    } else {
                        console.log('清除成功');
                    }
                })
            }, 300000)
        }
    })
}
//搜索用户
exports.searchUser = function (data, res) {
    let wherestr = {};
    if (data == 'maoss') {
        wherestr = {}
    }
    else {
        wherestr = { $or: [{ 'name': { $regex: data } }, { 'email': { $regex: data } }] };
    }
    let out = {
        'name': 1,
        'email': 1,
        'imgurl': 1,
    }
    User.find(wherestr, out, function (err, resualt) {

        if (err) {
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, resualt });
        }
    })
}

//搜索群组
exports.searchGroup = function (data, res) {
    let wherestr = {}
    if (data == 'maos') {
        wherestr = {}
    }
    else {
        wherestr = { $or: [{ 'name': { $regex: data } }] };
    }
    let out = {
        'name': 1,
        'imgurl': 1,
    }
    Group.find(wherestr, out, function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, resualt });
        }
    })
}

//用户详情
exports.userDetail = function (id, res) {
    let wherestr = { '_id': id };
    let out = {
        "pwd": 0
    }
    User.find(wherestr, out, function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, resualt });
        }
    })
}

//用户信息修改
exports.userDetailUpdata = function (data, res) {

    let updatastr = {};
    updatastr[data.type] = data.newData;
    User.findByIdAndUpdate(data.id, updatastr, function (err, resualt) {

        if (err)
            res.send({ status: 500 })
        else
            res.send({ status: 200 })
    })
}


//添加好友表 
exports.buildFriend = function (uid, fid, state, res) {
    let data = {
        userID: uid,
        friendID: fid,
        state: state,
        time: new Date(),
        lastTime: new Date()
    }
    let friend = new Friend(data);
    friend.save(function (err, result) {
        if (err) {
            console.log('申请好友出错');
            // res.send({status: 500})
        }
        else {
            console.log('申请好友成功');
            // res.send({status: 200})
        }
    })
}

//好友最后通讯时间
exports.upFriendLastTime = function (uid, fid, res) {
    let wherestr = { $or: [{ 'userID': uid, 'friendID': fid }, { 'userID': fid, 'friendID': uid }] };
    let updatestr = { 'lastTime': new Date() };
    Friend.updateMany(wherestr, updatestr, function (err) {
        if (err) {
            console.log('最后通讯时间更改失败');
            console.log(err);
            // res.send({status: 500});
        }
        else {
            console.log('最后通信时间更改成功');

        }
    })
}

//添加一对一消息
exports.insertMsg = function (uid, fid, msg, type, res) {
    let _this = this;
    let wherestr = {
        userID: fid
    }
    let data = {
        userID: uid,
        friendID: fid,
        message: msg,
        types: type,
        time: new Date(),
        state: ''    //发送消息（1是已读，0是未读）
    }
    UsersChatRoom.findOne(wherestr, function (err, resualt) {
        if (err) {
            if (res) {
                res.send({ status: 500 })
            }
        }
        else {
            if (resualt) {
                if (resualt.state == uid)
                    data.state = 0
                else
                    data.state = 1
            }
            else
                data.state = 1
            let message = new Message(data);
            message.save(function (err, result) {
                if (err) {
                    res.send({ status: 500 })
                }
                else {
                    console.log('修改最后通讯时间');
                    _this.upFriendLastTime(uid, fid, res);
                }
            })
        }
    })
}
//添加用户所在聊天室
exports.addUsersChatRoom = function (datas, res) {
    let data = {
        userID: datas.uid,
        state: datas.fid,
    }
    let usersChatRoom = new UsersChatRoom(data);
    usersChatRoom.save(function (err, result) {
        if (err) {
            if (res) {
                res.send({ status: 500 })
            }
        }
        else {
            if (res) {
                res.send({ status: 200 })
            }
        }
    })
}
//删除用户所在聊天室 delateUsersChatRoom 
exports.delateUsersChatRoom = function (data, res) {
    UsersChatRoom.deleteMany({ userID: data.uid }, function (err, result) {
        if (err) {
            if (res) {
                res.send({ status: 500 })
            }
        }
        else {
            if (res) {
                res.send({ status: 200 })
            }
        }
    })
}
//搜索用户所在聊天室
exports.searchChatRoom = function (data, res) {
    UsersChatRoom.findOne({ _id: data.uid }, function (err, result) {
        if (err) {
            res.send({ status: 500 })
        }
        else {
            res.send({ status: 200 })
        }
    })
}
//好友申请
exports.applyFriend = function (data, res) {
    //判断是否已经申请过了
    let wherestr = { 'userID': data.uid, 'friendID': data.fid };

    Friend.countDocuments(wherestr, (err, result) => {
        if (err) {
            res.send({ status: 500 });
        }
        else {

            //为0代表首次申请
            if (result == 0) {
                this.buildFriend(data.uid, data.fid, 2);
                this.buildFriend(data.fid, data.uid, 1);
            }
            else {
                //已经申请过好友了，再次申请只更新时间
                this.upFriendLastTime(data.uid, data.fid);
            }
            //添加通过以后
            this.insertMsg(data.uid, data.fid, data.msg, 0, res);
        }
    })
}

//更新好友状态
exports.updateFriendState = function (data, res) {
    let wherestr = { $or: [{ 'userID': data.uid, 'friendID': data.fid }, { 'userID': data.fid, 'friendID': data.uid }] };
    Friend.updateMany(wherestr, { 'state': 0 }, function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            console.log('添加好友成功');
            res.send({ status: 200 });
        }
    })
}

//删除或拒绝好友
exports.deleteFriend = function (data, res) {
    let wherestr = { $or: [{ 'userID': data.uid, 'friendID': data.fid }, { 'userID': data.fid, 'friendID': data.uid }] };
    Friend.deleteMany(wherestr, function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200 });
        }
    })
}

//按要求获取用户列表
exports.getUsers = function (data, res) {
    let resualt = [];
    Friend.find({ 'userID': data.uid, 'state': data.state }).sort({ 'lastTime': -1 }).populate('friendID').exec(function (err, e) {
        if (err) {
            res.send({ status: 500 });
        } else {
            for (let item of e) {
                if (JSON.stringify(item.friendID._id) != JSON.stringify(data.uid)) {
                    resualt.push({
                        id: item.friendID._id,
                        name: item.friendID.name,
                        imgurl: item.friendID.imgurl,
                        lastTime: item.lastTime,
                        type: 0 //0代表1对1聊天 1代表群聊
                    })
                }

            }
            res.send({ status: 200, resualt });

        }
    })
}

//按要求获取一对一最后一条消息
exports.getOneLastMsg = function (data, res) {
    Message.findOne({ $or: [{ 'userID': data.uid, 'friendID': data.fid }, { 'userID': data.fid, 'friendID': data.uid }] }).sort({ 'time': -1 }).exec(function (err, e) {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            if (e) {
                let resualt = {
                    message: e.message,
                    time: e.time,
                    types: e.types
                }
                console.log(resualt);
                res.send({ status: 200, resualt });
            }
            else
                res.send({ status: 200, resualt: 'null' });


        }
    })
}

//汇总一对一消息未读消息数
exports.unreadMsg = function (data, res) {
    let wherestr = { 'userID': data.fid, 'friendID': data.uid, 'state': 1 };
    Message.countDocuments(wherestr, (err, resualt) => {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, resualt });
        }
    })
}

//未读消息数清零
exports.updataStateMsg = function (data, res) {
    let wherestr = { 'userID': data.fid, 'friendID': data.uid };
    let updatastr = { 'state': 0 };
    Message.updateMany(wherestr, updatastr, (err, resualt) => {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200 });
        }
    })
}
//创建群聊
exports.createGroup = function (data, res) {
    var _this = this;
    return new Promise(function (resolve, reject) {
        let groupData = {
            userID: data.uid, //用户id
            name: data.name,  //群名称
            imgurl: data.imgurl,  //群头像
            time: new Date(),   //创建时间
        }
        var group = new Group(groupData);
        group.save(function (err, result) {
            if (err) {
                reject(err);
                reject({ status: 500 });
            }
            else {
                data['groupID'] = result._id;
                data['user'] = data['user'].split(",")

                resolve(data);

            }
        })
    }).then(function (result) {
        //添加好友入群
        for (let i = 0; i < result.user.length; i++) {
            let fdata = {
                groupID: result.groupID, //群id
                userID: result.user[i],
                time: new Date,
                lastTime: new Date
            };
            //好友入群
            _this.insertGroupUser(fdata);
        }
        res.send({ status: 200, 'groupID': result.groupID });
    }, function (reason) {
    }).catch(function onRejected(error) {
        res.send(error);
    })
}
//添加群成员
exports.insertGroupUser = function (data) {
    let groupuser = new GroupUser(data);
    groupuser.save(function (err, res) {
        if (err) {
            // res.send({ status: 500 });
            console.log("添加成员失败");
        }
        else {
            // res.send({status: 200});
            console.log("添加成员成功");
        }
    })
}
//群信息修改
exports.groupDetailUpdata = function (data, res) {
    let updatastr = {};
    updatastr[data.type] = data.newData;
    Group.findByIdAndUpdate(data.gid, updatastr, function (err, resualt) {
        if (err)
            res.send({ status: 500 })
        else {
            res.send({ status: 200 })
        }
    })
}
//解散群
exports.groupDissolution = function (data, res) {
   return new Promise((resolve, reject) => {
    Group.deleteMany({_id: data.gid}, function (err, resualt) {
        if (err)
            res.send({ status: 500 })
        else {
            resolve()
        }
    })
   }).then( _ => {
    GroupUser.deleteMany({groupID: data.gid},function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            console.log('删除成功');
            res.send({ status: 200 })
        }
    })
   })
}
//退出群
exports.groupSignOut = function (data, res) {
    let updatastr = {};
    updatastr[data.type] = data.newData;
    GroupUser.deleteMany({groupID: data.gid, userID: data.uid},function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            console.log('删除成功');
            res.send({ status: 200 })
        }
    })
}
//查询群信息
exports.searchGroupUser = function (data, res) {
    let backValue = {
        groupData:{},
        groupUser:[]
    };
    return new Promise(function (resolve, reject) {
        console.log(data.gid);
        Group.findOne({_id: data.gid}, function (err, resualt) {
            if (err) {
                reject(err);
                res.send({ status: 500 });
            }
            else {
                resolve(resualt)
            }
        })
    }).then(resualt => {
        backValue.groupData = resualt
        GroupUser.find({ groupID: data.gid }).populate('userID').exec(function (err, e) {
            if (err) {
                res.send({ status: 500 });
            } else {
                if(e.length) {
                e.forEach(item => {
                    backValue.groupUser.push({
                        userID: item.userID._id,
                        name: item.userID.name,
                        imgurl: item.userID.imgurl,
                    })
                })
                }
                res.send({ status: 200, backValue });
            }
        })
    })
}
//查询群成员
exports.groupMembers = function (data, res) {
    let resualt = [];
    GroupUser.find({ 'groupID': data.groupId }).exec(function (err, e) {
        if (err) {
            res.send({ status: 500 });
        } else {

            for (let item of e) {
                resualt.push(item.userID)
            }
            res.send({ status: 200, resualt });

        }
    })
}

//按要求获取群列表
exports.getGroup = function (data, res) {
    let resualt = [];
    GroupUser.find({ 'userID': data.uid }).sort({ 'lastTime': -1 }).populate('groupID').exec(function (err, e) {
        if (err) {
            res.send({ status: 500 });
        } else {
            for (let item of e) {
                resualt.push({
                    id: item.groupID._id,
                    name: item.groupID.name, //群名
                    imgurl: item.groupID.imgurl,
                    markname: item.name, //用户群内名
                    lastTime: item.lastTime,
                    tip: item.tip,
                    type: 1 //0代表1对1聊天 1代表群聊
                })
            }
            res.send({ status: 200, resualt });

        }
    })
}

//按要求获取群最后一条消息
exports.getOneGroupLastMsg = function (data, res) {
    Message.findOne({ 'groupID': data.gid }).sort({ 'time': -1 }).populate('userID').exec(function (err, e) {
        if (err) {
            res.send({ status: 500 });
        } else {
            let resualt = {
                message: e.message,
                time: e.time,
                types: e.types,
                name: e.userID.name
            }
            res.send({ status: 200, resualt });

        }
    })
}

//群未读消息数清零
exports.updataStateGroupMsg = function (data, res) {
    let wherestr = { 'userID': data.uid, 'GroupID': data.gid };
    let updatastr = { 'tip': 0 };
    Message.updateOne(wherestr, updatastr, (err, resualt) => {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200 });
        }
    })
}
//添加群聊消息
exports.insertGroupMsg = function (gid, uid, msg, type, res) {
    let data = {
        groupID: gid,
        userID: uid,
        message: msg,
        types: type,
        time: new Date(),
    }

    let groupMsg = new GroupMsg(data);
    groupMsg.save(function (err, result) {
        if (err) {
            if (res) {
                res.send({ status: 500 })
            }
        }
        else {
            if (res) {
                res.send({ status: 200 })
            }
        }
    })
}




//消息操作
//分页获取数据
exports.msg = function (data, res) {
    var skipNum = data.nowPage * data.pageSize; //跳过的条数
    let wherestr = { $or: [{ 'userID': data.uid, 'friendID': data.fid }, { 'userID': data.fid, 'friendID': data.uid }] };
    Message.find(wherestr).sort({ 'time': -1 }).populate('userID').skip(skipNum).limit(data.pageSize).exec(function (err, e) {
        if (err) {
            res.send({ status: 500 });
        } else {

            if (e.length) {
                let resualt = []
                for (let i = 0; i < e.length; i++) {
                    let data = {
                        id: e[i]._id,
                        message: e[i].message,
                        time: e[i].time,
                        types: e[i].types,
                        from_id: e[i].userID._id,
                        imgurl: e[i].userID.imgurl,
                    }
                    resualt.push(data);
                }
                res.send({ status: 200, resualt });
            }
            else {
                let resualt = {}


                res.send({ status: 200, resualt });
            }



        }
    })
}
//分页获取群聊数据
exports.groupMsg = function (data, res) {
    var skipNum = data.nowPage * data.pageSize; //跳过的条数
    let wherestr = { 'groupID': data.fid };
    GroupMsg.find(wherestr).sort({ 'time': -1 }).populate('userID').skip(skipNum).limit(data.pageSize).exec(function (err, e) {
        if (err) {
            res.send({ status: 500 });
        } else {
            if (e.length) {
                let resualt = []
                for (let i = 0; i < e.length; i++) {
                    let data = {
                        id: e[i]._id,
                        message: e[i].message,
                        time: e[i].time,
                        types: e[i].types,
                        from_id: e[i].userID._id,
                        imgurl: e[i].userID.imgurl,
                    }
                    resualt.push(data);
                }
                res.send({ status: 200, resualt });
            }
            else {
                let resualt = {}

                res.send({ status: 200, resualt });
            }
        }
    })
}

/*******************企业************************/
//建立企业
exports.buildEnterprise = function (data, res) {
    let _this = this;
    return new Promise((resolve, reject) => {
        let datas = {
            name: data.name,
            userID: data.uid,
            registrationTime: new Date()
        }

        let enterprise = new Enterprise(datas);
        enterprise.save(function (err, resualt) {
            if (err) {
                reject(err);
                res.send({ status: 500 });
            }
            else {
                // res.send({ status: 200, "id": resualt._id });
                resolve(resualt);
                console.log('成功创办');
            }
        })
    }).then(function (resualt) {
        //添加创办人到企业员工表
        let data = {
            enterpriseID: resualt._id,   //企业id
            userID: resualt.userID,   //注册企业用户id
            joiningTime: new Date(), //加入企业时间
            role: 'builder',
        }

        _this.insertEnterpriseEmployee(data);
        //添加企业组织架构
        let datas = {
            enterpriseID: resualt._id,   //企业id
            departmentName: resualt.name,   //组织名称
            parentID: 0, //最高层
            level: 0
        }
        _this.addOrganizationalStructure(datas);
        res.send({ status: 200 });
    })

}
//匹配企业表元素个数,用于查询该企业名称是否已经被创建
exports.countEnterpriseValue = function (data, type, res) {

    let wherestr = {};
    if (type == '_id')
        wherestr[type] = mongoose.Types.ObjectId(data);
    else
        wherestr[type] = data;
    Enterprise.countDocuments(wherestr, function (err, result) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, result });
        }
    })
}
//用来查找用户是否加入企业
exports.countUserIntoEnterprise = function (data, res) {
    let wherestr = { 'userID': data.uid };
    EnterpriseEmployees.findOne(wherestr, function (err, result) {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            let backValue = {};
            if (result) {
                backValue = {
                    result: 1,
                    role: result.role,
                    enterpriseId: result.enterpriseID
                }
            }
            else {
                backValue = {
                    result: 0,
                }
            }
            res.send({ status: 200, backValue });
        }
    })
}
//添加企业人员
exports.insertEnterpriseEmployee = function (data) {
    let enterpriseEmployees = new EnterpriseEmployees(data);
    enterpriseEmployees.save(function (err, res) {
        if (err) {
            // res.send({ status: 500 });
            console.log(err);
            console.log("添加成员失败");
        }
        else {
            // res.send({status: 200});
            console.log("添加成员成功");
        }
    })
}
//添加企业组织架构部门
exports.addOrganizationalStructure = function (data) {
    let organizationalStructure = new OrganizationalStructure(data);
    organizationalStructure.save(function (err, res) {
        if (err) {
            // res.send({ status: 500 });
            console.log("添加成员失败");
        }
        else {
            // res.send({status: 200});
            console.log("添加成员成功");
        }
    })
}
//用户申请加入企业
exports.applyToJoin = function (data, res) {
    let datas = {
        enterpriseID: data.eid,   //企业id
        userID: data.uid,   //注册企业用户id
        applicationTime: new Date(), //申请加入企业时间
        applicationSate: 1 //0代表通过，1代表正在申请，2代表拒绝
    }
    let application = new Application(datas);
    application.save(function (err) {
        if (err) {
            res.send({ status: 500 });
            console.log("添加成员失败");
        }
        else {
            res.send({ status: 200 });
            console.log("添加成员成功");
        }
    })
}
//查询申请加入企业人员
exports.searchApply = function (data, res) {
    let wherestr = {
        enterpriseID: data.eid,   //企业id
        applicationSate: 1 //0代表通过，1代表正在申请，2代表拒绝
    }
    Application.find(wherestr).sort({ 'time': -1 }).populate('userID').exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
            console.log("查询失败");
        }
        else {
            let backValue = []
            resualt.forEach(item => {
                backValue.push({
                    uid: item.userID._id,
                    ApplyId: item._id,
                    name: item.userID.name,
                    imgurl: item.userID.imgurl,
                    applicationTime: item.applicationTime,
                })
            })
            res.send({ status: 200, backValue });
            console.log("查询成功");
        }
    })
}
//同意加入企业
exports.agreeJoinEnterprise = function (data, res) {
    let _this = this;
    return new Promise((resolve, reject) => {
        let updatastr = {
            applicationSate: 0
        }
        Application.findByIdAndUpdate(data.ApplyId, updatastr, function (err, resualt) {
            if (err) {
                reject(err);
                res.send({ status: 500 })
            }
            else {
                resolve(resualt);
            }
        })
    }).then(function (resualt) {
        return new Promise(resolve => {
            let wherestr = {
                enterpriseID: data.eid,   //企业id
            }
            EnterpriseEmployees.find(wherestr, function (err, result) {
                if (err) {
                    reject(err);
                    res.send({ status: 500 })
                }
                else {
                    let insertInfo = [];
                    result.forEach(item => {
                        insertInfo.push({
                            userID: resualt.userID,
                            friendID: item.userID,
                            state: 0,
                            time: new Date(),
                            lastTime: new Date()
                        });
                        insertInfo.push({
                            userID: item.userID,
                            friendID: resualt.userID,
                            state: 0,
                            time: new Date(),
                            lastTime: new Date()
                        });
                    })
                    Friend.insertMany(insertInfo, function (err, result) {
                        if (err) {
                            reject(err);
                            res.send({ status: 500 })
                        }
                        else {
                            resolve(resualt);
                        }
                    })
                }
            })
        })
    }).then(resualt => {
        let datas = {
            enterpriseID: data.eid,   //企业id
            userID: resualt.userID,   //注册企业用户id
            joiningTime: new Date(), //加入企业时间
            role: 'user',
        }
        _this.insertEnterpriseEmployee(datas);
        res.send({ status: 200 });
    })
}
//拒绝加入企业
exports.refuseJoinEnterprise = function (data, res) {
    let updatastr = {
        applicationSate: 2
    }
    Application.findByIdAndUpdate(data.ApplyId, updatastr, function (err, resualt) {
        if (err) {
            res.send({ status: 500 })
        }
        else {
            res.send({ status: 200 });
        }
    })
}
/*******************流程***************************************/
//获取表单模型和流程数据
exports.getFormModel = function (data, res) {
    let wherestr = {
        '_id': data.workflowId
    }
    WorkFlow.findOne(wherestr).sort({ 'time': -1 }).populate('associatedForm').exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
            console.log("查询失败");
        }
        else {
            res.send({ status: 200, configModel: resualt.associatedForm.configModel, workFlowModel: resualt.workFlowModel, name: resualt.name });
            console.log("查询成功");
        }
    })
}
//发起流程
exports.initiatin = function (data, res) {
    let datas = {
        userID: data.uid,
        enterpriseID: data.eid,
        workFlowID: data.workFlowId,
        nextApprover: data.nextApproverId,
        formValue: data.formValue,
        state: 'approve',
        approvalNode: data.approvalNode,
        creatTime: new Date(),
    }
    let processInformation = new ProcessInformation(datas);
    processInformation.save(function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, pfid: resualt._id });
        }
    })
}

//获取我的代办总条数
exports.doitForMe = function (data, res) {
    let wherestr = { 'nextApprover': data.uid, 'state': 'approve' };
    ProcessInformation.countDocuments(wherestr, (err, resualt) => {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, resualt });
        }
    })
}
//获取我的代办信息
exports.getDoitForMeData = function (data, res) {
    let backValue = []
    let wherestr = { 'nextApprover': data.uid, 'state': 'approve' };
    ProcessInformation.find(wherestr).sort({ 'creatTime': -1 }).populate('userID').populate('workFlowID').exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            resualt.forEach(item => {
                backValue.push({
                    pfId: item._id,
                    workFlowID: item.workFlowID._id,
                    sponsor: item.userID.name,
                    imgurl: item.userID.imgurl,
                    workFlowName: item.workFlowID.name,
                    launchTime: item.creatTime,
                    state: item.state,
                })
            })
            res.send({ status: 200, backValue });
        }
    })
}
//获取表单绑定值
exports.getFormValue = function (data, res) {
    let wherestr = {
        "_id": data.pfId
    };
    ProcessInformation.findOne(wherestr, (err, resualt) => {
        if (err) {
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, formValue: resualt.formValue, approvalNode: resualt.approvalNode });
        }
    })
}
//流程审批
exports.approve = function (data, res) {
    let updatastr = {};
    updatastr = {
        nextApprover: data.nextApproverId,
        approvalNode: data.approvalNode,
        state: data.state
    }
    ProcessInformation.findByIdAndUpdate(data.pfId, updatastr, function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 })
        }
        else
            res.send({ status: 200 })
    })
}
//拒绝流程通过
exports.refuse = function (data, res) {
    let updatastr = {};
    updatastr = {
        state: 'refuse'
    }
    ProcessInformation.findByIdAndUpdate(data.pfId, updatastr, function (err, resualt) {
        if (err) {
            res.send({ status: 500 })
        }
        else {
            res.send({ status: 200 })
        }
    })
}
//插入已办或者代办
exports.insertCompletedOrApplied = function (data, res) {
    let datas = {
        userID: data.uid,
        ProcessInformationID: data.pfid,
        type: data.type
    }
    let completedAndApplied = new CompletedAndApplied(datas);
    completedAndApplied.save(function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, });
        }
    })
}
//查询已办或者代办条数
exports.searchCompletedOrAppliedCount = function (data, res) {
    let wherestr = {
        userID: data.uid,
        type: data.type
    }
    CompletedAndApplied.countDocuments(wherestr, function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 })
        }
        else {
            res.send({ status: 200, resualt })
        }
    })
}
//查询已办或者代办信息
exports.searchCompletedOrApplied = function (data, res) {
    let _this = this;
    let backValue = [];
    return new Promise((resolve, reject) => {
        let wherestr = { 'userID': data.uid, 'type': data.type };
        CompletedAndApplied.find(wherestr, function (err, resualt) {
            if (err) {
                reject(err);
                res.send({ status: 500 })
            }
            else {
                let pfids = []
                resualt.forEach(item => {
                    pfids.push(item.ProcessInformationID)
                })
                resolve(pfids);
            }
        })
    }).then(function (resualtOne) {
        ProcessInformation.find({ _id: { $in: resualtOne } }).sort({ 'creatTime': -1 }).populate('userID').populate('workFlowID').exec(function (err, resualt) {
            if (err) {
                res.send({ status: 500 });
            }
            else {
                resualt.forEach(item => {
                    backValue.push({
                        pfId: item._id,
                        workFlowID: item.workFlowID._id,
                        sponsor: item.userID.name,
                        imgurl: item.userID.imgurl,
                        workFlowName: item.workFlowID.name,
                        launchTime: item.creatTime,
                        state: item.state,
                    })
                })
                res.send({ status: 200, backValue });
            }
        })
    })
}
//流程当为view状态时设置下一节点审批人
exports.viewNextApprover = function (data, res) {
    let wherestr = {
        _id: data.pfId
    }
    ProcessInformation.findOne(wherestr).sort({ 'time': -1 }).populate('userID').exec(function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 })
        }
        else {
            let backValue = {
                approverName: resualt.userID.name,
                imgurl: resualt.userID.imgurl,
                state: resualt.state,
            }
            res.send({ status: 200, backValue })
        }
    })
}
//考勤打卡
exports.punchTheClock = function (data, res) {
    let states = '';
    if (data.type == 'morning') {
        if (new Date(data.punchClockTime).getHours() < 9)
            states = 'normal'
        else
            states = 'late'
    }
    else {
        if (new Date(data.punchClockTime).getHours() < 18)
            states = 'leaveEarly'
        else
            states = 'normal'
    }
    let datas = {
        userID: data.uid,
        enterpriseID: data.eid,
        punchClockTime: data.punchClockTime,
        punchClockLocation: data.punchClockLocation,
        state: states,
        type: data.type,
    }
    let checkWorkAttendance = new CheckWorkAttendance(datas);
    checkWorkAttendance.save(function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, states });
            console.log('成功打卡');
        }
    })
}
//进入打卡页面获取打卡数据
exports.searchPunchClockInfo = function (data, res) {
    const start = data.nowYaer + '-' + data.nowMonth + '-' + data.nowDay + ' 00:00:00'
    const end = data.nowYaer + '-' + data.nowMonth + '-' + data.nowDay + ' 23:59:59'
    let wherestr = {
        userID: data.uid,
        punchClockTime: { '$gte': new Date(start), '$lte': new Date(end) }
    }
    CheckWorkAttendance.find(wherestr, function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, resualt });
        }
    })
}

//获取全部文章展示--前台用
exports.getArticleInformation = function (data, res) {
    let wherestr = {
        enterpriseID: data.eid,
    };
    AnnouncementArticle.find(wherestr).sort({ 'time': -1 }).populate("userID").exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            let backValue = [];
            resualt.forEach(item => {
                backValue.push({
                    "articalId": item._id,
                    "title": item.title,
                    "imgurl": item.imgurl,
                    "userName": item.userID.name,
                    "headImgurl": item.userID.imgurl,
                    "releaseTime": item.releaseTime,
                })
            })
            res.send({ status: 200, backValue });
        }
    })
}


//获取文章内容
exports.getArticle = function (data, res) {
    let wherestr = {
        _id: data.articalId
    };
    AnnouncementArticle.findOne(wherestr).sort({ 'time': -1 }).populate("userID").exec(function (err, resualt) {
        if (err) {
            res.send({ status: 500 });
        } else {
            let backValue = {
                userName: resualt.userID.name,
                userImgurl: resualt.userID.imgurl,
                title: resualt.title,
                imgurl: resualt.imgurl,
                releaseTime: resualt.releaseTime,
                content: resualt.content
            }
            res.send({ status: 200, backValue });
        }
    })
}

//获取部门一级架构与员工
exports.departmentLevelStructureEmployees = function (data, res) {
    var _this = this;
    return new Promise(function (resolve, reject) {
        let wherestr = {
            enterpriseID: data.eid,
            level: 1
        };
        console.log(wherestr);
        OrganizationalStructure.find(wherestr).exec(function (err, resualt) {
            if (err) {
                reject(err);
                res.send({ status: 500 });
            } else {

                let department = [];
                resualt.forEach(item => {
                    department.push({
                        departmentId: item._id,
                        departmentName: item.departmentName
                    })
                })
                resolve(department);
            }
        })
    }).then(function (result) {
        let wherestr = {
            enterpriseID: data.eid,
        }
        EnterpriseEmployees.find(wherestr).populate("userID").exec(function (err, resualtOne) {
            if (err) {
                res.send({ status: 500 });
            } else {

                let employeesInfo = [];
                resualtOne.forEach(item => {
                    if (!item.department) {
                        employeesInfo.push({
                            uid: item.userID._id,
                            name: item.userID.name,
                            imgurl: item.userID.imgurl,
                        })
                    }
                })
                let backValue = {
                    department: result,
                    employeesInfo
                }
                res.send({ status: 200, backValue });

            }
        })
    }, function (reason) {
        console.log(reason);
    }).catch(function onRejected(error) {
        res.send(error);
    })
}
//获取部门一级架构与员工
exports.departmentAndEmployeesChild = function (data, res) {
    var _this = this;
    return new Promise(function (resolve, reject) {
        let wherestr = {
            parentID: data.departmentId,
        };
        OrganizationalStructure.find(wherestr).exec(function (err, resualt) {
            if (err) {
                reject(err);
                res.send({ status: 500 });
            } else {

                let department = [];
                resualt.forEach(item => {
                    department.push({
                        departmentId: item._id,
                        departmentName: item.departmentName
                    })
                })
                resolve(department);
            }
        })
    }).then(function (result) {
        let wherestr = {
            department: data.departmentId,
        }
        EnterpriseEmployees.find(wherestr).populate("userID").exec(function (err, resualtOne) {
            if (err) {
                res.send({ status: 500 });
            } else {

                let employeesInfo = [];
                resualtOne.forEach(item => {

                    employeesInfo.push({
                        uid: item.userID._id,
                        name: item.userID.name,
                        imgurl: item.userID.imgurl,
                    })

                })
                let backValue = {
                    department: result,
                    employeesInfo
                }
                res.send({ status: 200, backValue });

            }
        })
    }, function (reason) {
        console.log(reason);
    }).catch(function onRejected(error) {
        res.send(error);
    })
}


//新建日程
exports.NewSchedule = function (data, res) {
    let datas = {
        userID: data.uid, //用户id
        name: data.name,//标题
        startTime: data.startTime, //开始时间
        endTime: data.endTime, //结束时间
        createTime: new Date(), //创建时间
        scheduleDate: data.scheduleDate
    }
    console.log(datas) 
    let schedule = new Schedule(datas);
    schedule.save(function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, scheduleID: resualt._id });

        }
    })
}
//删除日程
exports.delSchedule = function (data, res) {
    let wherestr = {
        _id: data.sid
    }
    Schedule.deleteMany(wherestr, function (err) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200 });
        }
    })
}
//获取日程
exports.getSchedule = function (data, res) {
    const start = data.nowYaer + '-' + data.nowMonth + '-' + data.nowDay + ' 00:00:00'
    const end = data.nowYaer + '-' + data.nowMonth + '-' + data.nowDay + ' 23:59:59'
    let wherestr = {
        userID: data.uid,
        scheduleDate: { '$gte': new Date(start), '$lte': new Date(end) }
    }
    console.log(data);
    console.log(wherestr);
    Schedule.find(wherestr, function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            let backValue = [];
            resualt.forEach(item => {
                backValue.push({
                    scheduleID: item._id,
                    name: item.name,
                    startTime: item.startTime,
                    endTime: item.endTime
                })
            })
            res.send({ status: 200, backValue });
        }
    })
}
//新建备忘录 
exports.NewMemorandum = function (data, res) {
    let datas = {
        userID: data.uid, //用户id
        memorandumName: data.name, //备忘录名称
        completeState: 'incomplete', //状态，complete完成，incomplete未完成
        createTime: new Date(), //创建时间
    }
    let memorandum = new Memorandum(datas);
    memorandum.save(function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {

            res.send({ status: 200, resualt });
        }
    })
}
//删除备忘录
exports.delMemorandum = function (data, res) {
    let wherestr = {
        _id: data.mid
    }
    Memorandum.deleteMany(wherestr, function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200 });
        }
    })
}
//获取我的备忘录 
exports.getMemorandum = function (data, res) {
    let wherestr = {
        userID: data.uid,
    }
    Memorandum.find(wherestr, function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            //备忘录界面发送请求会得到所有的备忘录数据，工作台发送请求得到的是未完成的数据
            if (data.from == 'workbench') {
                for (let i = 0; i < resualt.length; i++) {
                    if (resualt[i].completeState == 'complete')
                        resualt.splice(i, 1);
                }
            }
            res.send({ status: 200, resualt });
        }
    })
}
//修改我的备忘录状态
exports.updateMemorandumState = function (data, res) {
    let updatastr = {};
    updatastr[data.type] = data.value;
    Memorandum.findByIdAndUpdate(data.memorandumId, updatastr, function (err, resualt) {
        if (err) {
            console.log(err);
            res.send({ status: 500 });
        }
        else {
            res.send({ status: 200, resualt });
        }
    })
}