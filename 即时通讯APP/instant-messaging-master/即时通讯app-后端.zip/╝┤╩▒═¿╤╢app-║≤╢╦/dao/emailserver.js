//引用发送邮件
var nodemailer = require('nodemailer');

//引入证书文件
var creadentials = require('../config/credentials');

//创建传输方式
var transporter = nodemailer.createTransport({
    service: 'qq',
    auth: {
        user: creadentials.qq.user,
        pass: creadentials.qq.pass
    }
})

//注册发送邮件给用户
exports.emailSignUp = function(email) {
    console.log("开始发送邮件");
    let options = {
        from: '',
        to: email,
        subject: '欢迎注册',
        html: '<span>欢迎注册</span>'
    };
    transporter.sendMail(options, function(err, msg) {
        if(err)
            console.log(err);
        else 
        console.log('发送邮箱成功');
    })
}
//验证码发送邮件给用户
exports.emailLogin = function(email,code) {
    console.log("开始发送邮件");
    let str = '<span>【MYY科技】' + code + '（登录验证码），你正在登录企业协作APP，5分钟内有效，请勿泄露</span>'
    let options = {
        from: '',
        to: email,
        subject: '登录验证码',
        html: str,
    };
    transporter.sendMail(options, function(err, msg) {
        if(err)
            console.log(err);
        else 
        console.log('发送邮箱成功');
    })
}