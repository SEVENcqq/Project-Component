let dbserver = require('./dbserver')

module.exports = function(io) {
    var users = {}; //用户登录进行socket注册
    io.on('connection', (socket) => {
        //用户登录注册
        socket.on('login', (id) => {
            socket.name = id;
            users[id] = socket.id;
            console.log(users);
        })
        //一对一消息发送
        socket.on('msg', (msg, fromId, toId) => {
            console.log(users);
            //修改好友最后通讯时间
            // dbserver.upFriendLastTime({uid: fromId, fid: toId});
            //存储一对一消息
            dbserver.insertMsg(fromId, toId, msg.message, msg.types);
            console.log(msg);
            //发送给对方
            if(users[toId])
                socket.to(users[toId]).emit('msg', msg, fromId, 0);
            //发送给自己
            // socket.to(users[toId]).emit('msg', msg, toId, 1);
        }) 
        //群消息发送
        socket.on('groupMsg', (msg, fromId, gid, groupNumber, fromNmae, fromImgUrl) => {
            console.log(groupNumber);
            //修改好友最后通讯时间
            // dbserver.upFriendLastTime({uid: fromId, fid: toId});
            //存储群聊消息
            dbserver.insertGroupMsg(gid, fromId, msg.message, msg.types);

            msg['fromName'] = fromNmae;
            //发送给对方
            for(let i=0;i<groupNumber.length;i++) {
               
               if(users[groupNumber[i]])
                socket.to(users[groupNumber[i]]).emit('msg', msg, fromId, 1, fromImgUrl);
            }  
            //发送给自己
            // socket.to(groupNumber[i]).emit('msg', msg, toId, 1);
        })
        //用户离开消除
        socket.on('disconnecting', () => {
            if(users.hasOwnProperty(socket.name)) {
                delete users[socket.name];
            }
        })
    }) 
}   