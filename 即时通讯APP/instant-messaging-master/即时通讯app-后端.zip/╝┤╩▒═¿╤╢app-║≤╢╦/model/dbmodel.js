var mongoose = require('mongoose');
var db = require('../config/db');
var Schema = mongoose.Schema;


//企业表 
var Enterprise = new Schema({
    name: { type: String },   //用户名
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //注册企业用户id
    explain: { type: String }, //介绍
    imgurl: { type: String, default: 'enterpriseLogo.png' }, //企业logo
    registrationTime: { type: Date }, //注册时间
});
//企业员工表
var EnterpriseEmployees = new Schema({
    enterpriseID: { type: Schema.Types.ObjectId, ref: 'Enterprise' },   //企业id
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //注册企业用户id
    joiningTime: { type: Date }, //加入企业时间
    position: { type: String, default: 'none' }, //职位
    department: { type: Schema.Types.ObjectId, ref: 'OrganizationalStructure' },  //员工部门
    role: { type: String, default: 'user' }, //默认为普通用户--user，创办公司者为builder，管理员为admin
});
//申请加入企业表
var Application = new Schema({
    enterpriseID: { type: Schema.Types.ObjectId, ref: 'Enterprise' },   //企业id
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //注册企业用户id
    applicationTime: { type: Date }, //申请加入企业时间
    applicationSate: { type: Number } //0代表通过，1代表正在申请，2代表拒绝
});
//部门组织架构
var OrganizationalStructure = new Schema({
    enterpriseID: { type: Schema.Types.ObjectId, ref: 'Enterprise' },   //企业id
    departmentName: { type: String}, //部门名称
    parentID:  { type: String}, //父部门id
    level: { type: Number } , //组织等级第一层为1级，第二层为2级
});
//用户表
var User = new Schema({
    name: { type: String },   //用户名
    pwd: { type: String },    //密码
    email: { type: String },  //邮箱
    sex: { type: String, default: 'asexual' }, //性别 男 male 女  female
    birth: { type: Date }, //生日
    phone: { type: Number }, //电话
    explain: { type: String }, //介绍
    imgurl: { type: String, default: '/head_portrait/defaultAvatar.png' }, //用户头像
    time: { type: Date }, //注册时间
    checkCode: { type: String, default: 'none' }, //用户邮箱登录的校验码
});
//好友表
var Friend = new Schema({
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //用户id
    friendID: { type: Schema.Types.ObjectId, ref: 'User' },   //好友ID
    state: { type: String },  //好友状态,0代表好友，1代表申请中，2代表申请发送方
    markName: { type: String }, //好友昵称
    time: { type: Date }, //添加时间，
    lastTime: { type: Date },//最后通讯时间
});
//一对一消息表
var Message = new Schema({
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //用户id
    friendID: { type: Schema.Types.ObjectId, ref: 'User' },   //好友ID
    message: { type: String }, //消息内容
    types: { type: String }, //消息类型
    time: { type: Date }, //发送时间
    state: { type: Number },  //消息状态  0是已读，1是未读
});
//用户所在聊天室，判断用户是否在某个聊天界面，用来处理未读消息数
var UsersChatRoom = new Schema({
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //用户ID
    state: { type: String }, //存储所在聊天室对方id
});
//群表
var Group = new Schema({
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //建群用户id
    name: { type: String }, //群名称
    imgurl: { type: String, default: 'group.png' }, //群组头像
    time: { type: Date }, //创建时间
    notice: { type: String }, //公告
});
//群成员表
var GroupUser = new Schema({
    groupID: { type: Schema.Types.ObjectId, ref: 'Group' },   //群id
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //用户ID
    name: { type: String }, //群内名称
    tip: { type: Number, default: 0 }, //未读消息
    time: { type: Date }, //加入时间
    lastTime: { type: Date }, //最后消息时间
    shield: { type: Number },  //是否屏蔽群消息（0不屏蔽，1屏蔽）
});
//群消息表
var GroupMsg = new Schema({
    groupID: { type: Schema.Types.ObjectId, ref: 'Group' },   //群id
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //用户ID
    message: { type: String }, //消息内容
    types: { type: String }, //消息类型
    time: { type: Date }, //发送时间
    state: { type: Number },  //消息状态
});
//表单表
var CustomerForm = new Schema({
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //创建表单用户id
    enterpriseID: { type: Schema.Types.ObjectId, ref: 'Enterprise' },   //企业id
    name: { type: String }, //表单名称
    configModel: { type: String }, //表单模型
    creatTime: { type: Date }, //创建时间
    modificationTime: { type: Date }, //修改时间
});
//流程表
var WorkFlow = new Schema({
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //创建表单用户id
    enterpriseID: { type: Schema.Types.ObjectId, ref: 'Enterprise' },   //企业id
    name: { type: String }, //流程名称
    associatedForm: { type: Schema.Types.ObjectId, ref: 'CustomerForm' },//关联表单ID
    workFlowModel: { type: String }, //流程模型
    creatTime: { type: Date }, //创建时间
    modificationTime: { type: Date }, //修改时间
});
//发起流程表
var ProcessInformation = new Schema({
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //创建表单用户id
    enterpriseID: { type: Schema.Types.ObjectId, ref: 'Enterprise' },   //企业id
    workFlowID: { type: Schema.Types.ObjectId, ref: 'WorkFlow' },   //流程id
    nextApprover: { type: Schema.Types.ObjectId, ref: 'User' }, //审批人用户id
    formValue: { type: String }, //表单值
    approvalNode: { type: String }, //审批节点
    state: { type: String }, //状态 approve refuse end
    creatTime: { type: Date }, //发起时间
});
//已办和申请
var CompletedAndApplied = new Schema({
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //创建表单用户id
    ProcessInformationID: { type: Schema.Types.ObjectId, ref: 'ProcessInformation' },   //发起流程ID
    type: { type: String }, //已办或申请的类型，completed，applied
});
//考勤打卡
var CheckWorkAttendance = new Schema({
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //创建表单用户id
    enterpriseID: { type: Schema.Types.ObjectId, ref: 'Enterprise' },   //企业id 
    punchClockTime: { type: Date }, //打卡时间
    state:{ type: String }, //打卡状态， 正常 normal， 迟到 late ， 早退 leaveEarly
    type: { type: String }, //已办或申请的类型，moring,afternoon 来判断是上班还是下班
});
//公告文章
var AnnouncementArticle = new Schema({
    userID: { type: Schema.Types.ObjectId, ref: 'User' },   //发布文章用户id
    enterpriseID: { type: Schema.Types.ObjectId, ref: 'Enterprise' },   //企业id 
    title:{ type: String }, //文章标题
    imgurl: { type: String }, //封面链接
    content: { type: String }, //内容
    releaseTime:{ type: Date }, //发布时间
    modificationTime:{ type: Date }, //修改时间
});
//日程
var Schedule = new Schema({
    userID: { type: Schema.Types.ObjectId, ref: 'User' }, //用户id
    name:{ type: String }, //标题
    startTime: { type: String }, //开始时间
    endTime: { type: String }, //结束时间
    createTime:{ type: Date }, //创建时间
    scheduleDate: { type: Date }, //创建时间
});
//备忘录
var Memorandum = new Schema({
    userID: { type: Schema.Types.ObjectId, ref: 'User' }, //用户id
    memorandumName:{ type: String }, //备忘录名称
    completeState: { type: String }, //状态，complete完成，incomplete未完成
    createTime:{ type: Date }, //创建时间
});
module.exports = db.model('User', User);
module.exports = db.model('Friend', Friend);
module.exports = db.model('Message', Message);
module.exports = db.model('Group', Group);
module.exports = db.model('GroupUser', GroupUser);
module.exports = db.model('GroupMsg', GroupMsg);
module.exports = db.model('Enterprise', Enterprise);
module.exports = db.model('EnterpriseEmployees', EnterpriseEmployees);
module.exports = db.model('Application', Application);
module.exports = db.model('CustomerForm', CustomerForm);
module.exports = db.model('WorkFlow', WorkFlow);
module.exports = db.model('ProcessInformation', ProcessInformation);
module.exports = db.model('CompletedAndApplied', CompletedAndApplied);
module.exports = db.model('CheckWorkAttendance', CheckWorkAttendance);
module.exports = db.model('AnnouncementArticle', AnnouncementArticle);
module.exports = db.model('OrganizationalStructure', OrganizationalStructure);
module.exports = db.model('Schedule', Schedule);
module.exports = db.model('Memorandum', Memorandum);
module.exports = db.model('UsersChatRoom', UsersChatRoom);
