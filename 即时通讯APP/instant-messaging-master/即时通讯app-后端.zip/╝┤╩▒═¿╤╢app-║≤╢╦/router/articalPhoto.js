//引入附件上传插件
var multer = require('multer');
var mkdir = require('../dao/mkdir')
//控制文件存储
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        console.log(req.body.uid);
        mkdir.mkdirs('../data/' + req.body.url, err => {
            console.log(err);
        });
        cb(null, './data/' + req.body.url)
    },
    filename: function (req, file, cb) {
        console.log(req.body.uid);
        let type = file.originalname.replace(/.+\./, ".");
        cb(null,  new Date() + type);
    }
})
 
const upload = multer({ storage: storage })

module.exports = function(app) {
    //文件上传
    app.post('/articalPhotos/upload', upload.array('file', 10), function(req,res, next) {
        console.log('上传完成s');
        console.log(req);
        let fileName = req.files[0].filename;
        res.send({status: 200, 'fileName': fileName});
    })

} 