var backstage = require('../server/backstage')

module.exports = function (app) {
    //登录
    app.post('/backstage/signMatch', (req, res) => {
        backstage.login(req, res);
    });
    //创建表单
    app.post('/backstage/createForm', (req, res) => {
        backstage.createForm(req, res);
    });
    //分页查询表单信息
    app.post('/backstage/searchFormData', (req, res) => {
        backstage.searchFormData(req, res);
    });
    //单个查询表单信息
    app.post('/backstage/searchFormOneData', (req, res) => {
        backstage.searchFormOneData(req, res);
    });
    //删除表单信息
    app.post('/backstage/delateForm', (req, res) => {
        backstage.delateForm(req, res);
    });
    //更新表单信息
    app.post('/backstage/updataForm', (req, res) => {
        backstage.updataForm(req, res);
    });
    //创建流程
    app.post('/backstage/createWorkFlow', (req, res) => {
        backstage.createWorkFlow(req, res);
    });
    //分页查询流程
    app.post('/backstage/searchWorkFlow', (req, res) => {
        backstage.searchWorkFlow(req, res);
    });
    //查询一条流程
    app.post('/backstage/searchFlowOneData', (req, res) => {
        backstage.searchFlowOneData(req, res);
    });
    //查询流程数量
    app.post('/backstage/searchWorkFlowCount', (req, res) => {
        backstage.searchWorkFlowCount(req, res);
    });
    //删除流程
    app.post('/backstage/delateFlow', (req, res) => {
        backstage.delateFlow(req, res);
    });
    //更新流程
    app.post('/backstage/updataWorkFlow', (req, res) => {
        backstage.updataWorkFlow(req, res);
    });
    //获取企业员工信息
    app.post('/backstage/getEmployees', (req, res) => {
        backstage.getEmployees(req, res);
    });
    //发布公告文章
    app.post('/announcement/uploadArticle', (req, res) => {
        backstage.uploadArticle(req, res);
    });
    //分页获取文章展示--后台用
    app.post('/announcement/getArticleInformationBackstage', (req, res) => {
        backstage.getArticleInformationBackstage(req, res);
    });
    //删除文章 
    app.post('/announcement/deleteArticle', (req, res) => {
        backstage.deleteArticle(req, res);
    });
    //获取文章内容 
    app.post('/announcement/getArticalContent', (req, res) => {
        backstage.getArticalContent(req, res);
    });
    //更新文章内容 
    app.post('/announcement/updataArticalContent', (req, res) => {
        backstage.updataArticalContent(req, res);
    });
    //获取部门一级架构 
    app.post('/organizationalStructure/loadfirstnode', (req, res) => {
        backstage.loadfirstnode(req, res);
    });
    //添加部门架构 
    app.post('/organizationalStructure/addDepartment', (req, res) => {
        backstage.addDepartment(req, res);
    });
    //获取部门子级架构 
    app.post('/organizationalStructure/loadchildnode', (req, res) => {
        backstage.loadchildnode(req, res);
    });
    //删除部门 
    app.post('/organizationalStructure/delateDepartment', (req, res) => {
        backstage.delateDepartment(req, res);
    });
    //修改部门名称 
    app.post('/organizationalStructure/changeDepartmentName', (req, res) => {
        backstage.changeDepartmentName(req, res);
    });
    //获取部门成员 
    app.post('/organizationalStructure/getDepartmentMembers', (req, res) => {
        backstage.getDepartmentMembers(req, res);
    });
    //添加部门成员 
    app.post('/organizationalStructure/addDepartmentMembers', (req, res) => {
        backstage.addDepartmentMembers(req, res);
    });
    //获取公司员工 
    app.post('/organizationalStructure/getEnterpriseemployees', (req, res) => {
        backstage.getEnterpriseemployees(req, res);
    });
    //删除公司员工信息  
    app.post('/organizationalStructure/deleteEmployees', (req, res) => {
        backstage.deleteEmployees(req, res);
    });
    //首页信息获取 
    app.post('/index/getIndexInfo', (req, res) => {
        backstage.getIndexInfo(req, res);
    });
    //统计企业男女比例 
    app.post('/index/maleFemaleRatio', (req, res) => {
        backstage.maleFemaleRatio(req, res);
    });
    //获取新员工信息（最近加入的三个员工信息） 
    app.post('/index/getNewEmployee', (req, res) => {
        backstage.getNewEmployee(req, res);
    });
    //获取考勤信息 
    app.post('/checkAttendance/getCheckAttendance', (req, res) => {
        backstage.getCheckAttendance(req, res);
    });
    //搜索打卡数据 
    app.post('/checkAttendance/searchCheckAttendance', (req, res) => {
        backstage.searchCheckAttendance(req, res);
    });
    //查询导出打卡考勤信息 
    app.post('/checkAttendance/searchExportCA', (req, res) => {
        backstage.searchExportCA(req, res);
    });
    //导出打卡考勤信息为Excel 
    app.get('/checkAttendance/exportExcel', (req, res) => {
        console.log(req);
        backstage.exportExcel(req, res);
    });
    //查询用户id 
    app.post('/checkAttendance/searchUserId', (req, res) => {
        backstage.searchUserId(req, res);
    });
    //获取员工职位和员工权限角色 
    app.post('/organizationalStructure/getEmployeesInfo', (req, res) => {
        backstage.getEmployeesInfo(req, res);
    });
    //获取员工职位和员工权限角色 
    app.post('/organizationalStructure/updateEmployeesInfo', (req, res) => {
        backstage.updateEmployeesInfo(req, res);
    });

}