var dbserver = require('../dao/dbserver');
//注册
var signup = require('../server/signup')
//登录
var signin = require('../server/signin')
//搜索
var search = require('../server/search')
//用户详情
var userdetail = require('../server/userdetail')
//用户列表
var home = require('../server/home')
//好友申请
var friend = require('../server/friend')
//聊天消息
var chat = require('../server/chat')
//建群
var group = require('../server/group')
//公司
var enterprise = require('../server/enterprise')
//公司
var application = require('../server/application')
//流程
var initiatingProcess = require('../server/initiatingProcess')
//打卡
var punchclock = require('../server/punchclock')
//公告文章
var artical = require('../server/artical')
//通讯列表
var mailList = require('../server/mailList')
//日程
var schedule = require('../server/schedule')
//备忘录
var memorandum = require('../server/memorandum')

module.exports = function (app) {

    //注册
    app.post('/signUp/add', (req, res) => {
        signup.signUp(req, res);
    });
    //用户或邮箱是否占用
    app.post('/signUp/judge', (req, res) => {
        signup.judgeValue(req, res);
    });

    //登录
    app.post('/signIn/signMatch', (req, res) => {
        signin.signIn(req, res);
    });
    //生成验证码并发送验证码
    app.post('/signIn/generateVerificationCode', (req, res) => {
        signin.generateVerificationCode(req, res);
    });
    //匹配邮件发送的验证码是否正常
    app.post('/signIn/matchCode', (req, res) => {
        signin.matchCode(req, res);
    });
    //搜索用户
    app.post('/search/searchUser', (req, res) => {
        search.searchUser(req, res);
    });

    //搜索群组
    app.post('/search/searchGroup', (req, res) => {
        search.searchGroup(req, res);
    });

    //用户详情
    app.post('/user/userDetail', (req, res) => {
        userdetail.userDetail(req, res);
    });
    //修改用户详情
    app.post('/user/userDetailUpdata', (req, res) => {
        userdetail.userDetailUpdata(req, res);
    });

    //好友申请
    app.post('/friend/applyFriend', (req, res) => {
        friend.applyFriend(req, res);
    });
    //更新好友状态
    app.post('/friend/updataFriendState', (req, res) => {
        friend.updataFriendState(req, res);
    });
    //删除或拒绝好友
    app.post('/friend/deleteFriend', (req, res) => {
        friend.deleteFriend(req, res);
    });

    //获取用户列表
    app.post('/home/homeIndex', (req, res) => {
        home.getFriend(req, res);
    });
    //获取最后一条消息
    app.post('/home/getLastMsg', (req, res) => {
        home.getLastMsg(req, res);
    });
    //未读消息条数
    app.post('/home/unreadMsg', (req, res) => {
        home.unreadMsg(req, res);
    });
    //未读消息变为已读消息
    app.post('/home/updataStateMsg', (req, res) => {
        home.updataStateMsg(req, res);
    });
    //删除用户所在聊天室 
    app.post('/home/delateUsersChatRoom', (req, res) => {
        home.delateUsersChatRoom(req, res);
    });
    //搜索用户所在聊天室 
    app.post('/home/searchChatRoom', (req, res) => {
        home.searchChatRoom(req, res);
    });
    //添加用户所在聊天室 
    app.post('/home/addUsersChatRoom', (req, res) => {
        home.addUsersChatRoom(req, res);
    });

    /***********************群内容********************************* */
    //建群
    app.post('/group/createGroup', (req, res) => {
        group.createGroup(req, res);
    });
    //添加群成员
    app.post('/home/insertGroupUser', (req, res) => {
        group.insertGroupUser(req, res);
    });
    //获取群成员
    app.post('/chat/getGroupMembers', (req, res) => {
        chat.getGroupMembers(req, res);
    });
    //修改群信息
    app.post('/group/groupDetailUpdata', (req, res) => {
        group.groupDetailUpdata(req, res);
    });
    //解散群 
    app.post('/group/groupDissolution', (req, res) => {
        group.groupDissolution(req, res);
    });
    //退出群 
    app.post('/group/groupSignOut', (req, res) => {
        group.groupSignOut(req, res);
    });
    //查询群信息 
    app.post('/group/searchGroupUser', (req, res) => {
        group.searchGroupUser(req, res);
    });
    //获取群列表
    app.post('/home/getGroup', (req, res) => {
        home.getGroup(req, res);
    });
    //按要求获取群最后一条消息
    app.post('/home/getOneGroupLastMsg', (req, res) => {
        home.getOneGroupLastMsg(req, res);
    });
    //群未读消息数清零
    app.post('/home/updataStateGroupMsg', (req, res) => {
        home.updataStateGroupMsg(req, res);
    });



    //获取一对一聊天信息
    app.post('/chat/msg', (req, res) => {
        chat.msg(req, res);
    });

    //获取群聊信息
    app.post('/chat/groupMsg', (req, res) => {
        chat.groupMsg(req, res);
    });



    /**************公司******************/
    //创建公司
    app.post('/enterprise/buildEnterprise', (req, res) => {
        enterprise.buildEnterprise(req, res);
    });
    //查询公司名称是否被占用
    app.post('/enterprise/judgeValue', (req, res) => {

        enterprise.judgeValue(req, res);
    });
    //查询用户是否已经加入公司
    app.post('/enterprise/judgeUserIntoEnter', (req, res) => {
        enterprise.countUserIntoEnterprise(req, res);
    });
    //申请加入公司
    app.post('/enterprise/applyToJoin', (req, res) => {
        application.applyToJoin(req, res);
    });
    //查询加入公司申请
    app.post('/enterprise/searchApply', (req, res) => {
        application.searchApply(req, res);
    });
    //同意申请加入公司 
    app.post('/enterprise/agreeJoinEnterprise', (req, res) => {
        application.agreeJoinEnterprise(req, res);
    });
    //拒绝申请加入公司
    app.post('/enterprise/refuseJoinEnterprise', (req, res) => {
        application.refuseJoinEnterprise(req, res);
    });
    //获取表单模型
    app.post('/initiatingProcess/getFormModel', (req, res) => {
        initiatingProcess.getFormModel(req, res);
    });
    //发起流程
    app.post('/initiatingProcess/initiatin', (req, res) => {
        initiatingProcess.initiatin(req, res);
    });
    //获取我的代办数量
    app.post('/initiatingProcess/doitForMe', (req, res) => {
        initiatingProcess.doitForMe(req, res);
    });
    //获取我的代办信息
    app.post('/initiatingProcess/getDoitForMeData', (req, res) => {
        initiatingProcess.getDoitForMeData(req, res);
    });
    //获取表单绑定值
    app.post('/initiatingProcess/getFormValue', (req, res) => {
        initiatingProcess.getFormValue(req, res);
    });

    //流程审批
    app.post('/initiatingProcess/approve', (req, res) => {
        initiatingProcess.approve(req, res);
    });
    //拒绝流程申请
    app.post('/initiatingProcess/refuse', (req, res) => {
        initiatingProcess.refuse(req, res);
    });
    //插入已办或者代办
    app.post('/initiatingProcess/insertCompletedOrApplied', (req, res) => {
        initiatingProcess.insertCompletedOrApplied(req, res);
    });
    //查询已办或者代办条数
    app.post('/initiatingProcess/searchCompletedOrAppliedCount', (req, res) => {
        initiatingProcess.searchCompletedOrAppliedCount(req, res);
    });
    //查询已办或者代办
    app.post('/initiatingProcess/searchCompletedOrApplied', (req, res) => {
        initiatingProcess.searchCompletedOrApplied(req, res);
    });
    //流程当为view状态时设置下一节点审批人 
    app.post('/initiatingProcess/viewNextApprover', (req, res) => {
        initiatingProcess.viewNextApprover(req, res);
    });
    //打卡 
    app.post('/punchClock/punchTheClock', (req, res) => {
        punchclock.punchTheClock(req, res);
    });
    //进入打卡页面获取打卡数据
    app.post('/punchClock/searchPunchClockInfo', (req, res) => {
        punchclock.searchPunchClockInfo(req, res);
    });
    //获取全部文章展示
    app.post('/announcement/getArticleInformation', (req, res) => {
        artical.getArticleInformation(req, res);
    });
    //获取文章内容
    app.post('/announcement/getArticle', (req, res) => {
        artical.getArticle(req, res);
    });
    //获取部门一级架构与员工 
    app.post('/mailList/departmentLevelStructureEmployees', (req, res) => {
        mailList.departmentLevelStructureEmployees(req, res);
    });
    //获取部门一级架构与员工 
    app.post('/mailList/departmentAndEmployeesChild', (req, res) => {
        mailList.departmentAndEmployeesChild(req, res);
    });
    //新建日程 
    app.post('/schedule/NewSchedule', (req, res) => {
        schedule.NewSchedule(req, res);
    });
    //删除日程 
    app.post('/schedule/delSchedule', (req, res) => {
        schedule.delSchedule(req, res);
    });
    //获取流程 
    app.post('/schedule/getSchedule', (req, res) => {
        schedule.getSchedule(req, res);
    });
    //新建备忘录   
    app.post('/schedule/NewMemorandum', (req, res) => {
        memorandum.NewMemorandum(req, res);
    });
    //获取我的备忘录  
    app.post('/memorandum/getMemorandum', (req, res) => {
        memorandum.getMemorandum(req, res);
    });
    //修改我的备忘录状态 
    app.post('/memorandum/updateMemorandumState', (req, res) => {
        memorandum.updateMemorandumState(req, res);
    });
    //删除备忘录 
    app.post('/memorandum/delMemorandum', (req, res) => {
        memorandum.delMemorandum(req, res);
    });
}  