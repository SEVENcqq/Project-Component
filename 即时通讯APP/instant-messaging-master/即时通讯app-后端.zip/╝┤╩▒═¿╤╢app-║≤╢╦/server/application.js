
var dbserver = require('../dao/dbserver');
//
exports.applyToJoin = function(req, res) {
    let data = req.body;
    dbserver.applyToJoin(data, res);
}
//查询加入公司申请
exports.searchApply = function(req, res) {
    let data = req.body;
    dbserver.searchApply(data, res);
}
//同意申请加入公司 
exports.agreeJoinEnterprise = function(req, res) {
    let data = req.body;
    dbserver.agreeJoinEnterprise(data, res);
}
//拒绝申请加入公司 
exports.refuseJoinEnterprise = function(req, res) {
    let data = req.body;
    dbserver.refuseJoinEnterprise(data, res);
}