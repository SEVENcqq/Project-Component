var dbserver = require('../dao/dbserver');
//获取全部文章展示
exports.getArticleInformation = function(req, res) {
 let data = req.body;
    console.log(req);
    dbserver.getArticleInformation(data,res);
}

//分页获取文章展示--后台用
exports.getArticleInformationBackstage = function(req, res) {
    let data = req.body;
       console.log(req);
       dbserver.getArticleInformationBackstage(data,res);
   }
//获取文章内容
exports.getArticle = function(req, res) {
    let data = req.body;
    dbserver.getArticle(data,res);
}