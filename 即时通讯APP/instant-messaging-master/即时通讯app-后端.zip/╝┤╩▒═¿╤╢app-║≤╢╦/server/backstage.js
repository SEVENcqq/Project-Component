var backstageServer = require('../dao/backstageServer');

//登录
exports.login = function(req, res) {
    let data = req.query.data;
    let pwd = req.query.pwd;
    backstageServer.userMatch(data,pwd,res);
}
//创建表单
exports.createForm = function(req, res) {
    let data = req.query;
    // console.log(data);
    backstageServer.createForm(data,res);
}
//单个查询表单数据
exports.searchFormOneData = function(req, res) {
    let data = req.query;
    backstageServer.searchFormOneData(data,res);
}
//分页查询表单数据
exports.searchFormData = function(req, res) {
    let data = req.query;
    backstageServer.searchFormData(data,res);
}
//删除表单数据
exports.delateForm = function(req, res) {
    let data = req.query;
    backstageServer.delateForm(data,res);
}
//更新表单数据
exports.updataForm = function(req, res) {
    let data = req.query;
    backstageServer.updataForm(data,res);
}
//创建流程
exports.createWorkFlow = function(req, res) {
    let data = req.query;
    backstageServer.createWorkFlow(data,res);
}
//分页查询流程
exports.searchWorkFlow = function(req, res) {
    let data = req.query;
    backstageServer.SearchWorkFlow(data,res);
}
//查询一条流程
exports.searchFlowOneData = function(req, res) {
    let data = req.query;
    backstageServer.searchFlowOneData(data,res);
}
//获取流程数量
exports.searchWorkFlowCount = function(req, res) {
    let data = req.query;
    backstageServer.searchWorkFlowCount(data,res);
}
//删除流程
exports.delateFlow = function(req, res) {
    let data = req.query;
    backstageServer.delateFlow(data,res);
}
//更新流程
exports.updataWorkFlow = function(req, res) {
    let data = req.query;
    console.log("流程"+data);
    backstageServer.updataWorkFlow(data,res);
}
//获取企业人员
exports.getEmployees = function(req, res) {
    let data = req.query;
    backstageServer.getEmployees(data,res);
}
//发布公告文章
exports.uploadArticle = function(req, res) {
    let data = req.query;
    backstageServer.uploadArticle(data,res);
}

//分页获取文章展示--后台用
exports.getArticleInformationBackstage = function(req, res) {
    let data = req.query;
    backstageServer.getArticleInformationBackstage(data,res);
}
//删除文章 
exports.deleteArticle = function(req, res) {
    let data = req.query;
    backstageServer.deleteArticle(data,res);
}
//获取文章内容
exports.getArticalContent = function(req, res) {
    let data = req.query;
    backstageServer.getArticalContent(data,res);
}
//更新文章内容
exports.updataArticalContent = function(req, res) {
    let data = req.query;
    backstageServer.updataArticalContent(data,res);
}
//获取部门一级架构 
exports.loadfirstnode = function(req, res) {
    let data = req.query;
    backstageServer.loadfirstnode(data,res);
}
//添加部门架构
exports.addDepartment = function(req, res) {
    let data = req.query;
    backstageServer.addDepartment(data,res);
}
//获取部门子级架构
exports.loadchildnode = function(req, res) {
    let data = req.query;
    backstageServer.loadchildnode(data,res);
}
//删除部门
exports.delateDepartment = function(req, res) {
    let data = req.query;
    backstageServer.delateDepartment(data,res);
}
//修改部门名称 changeDepartmentName
exports.changeDepartmentName = function(req, res) {
    let data = req.query;
    backstageServer.changeDepartmentName(data,res);
}
//获取部门成员  
exports.getDepartmentMembers = function(req, res) {
    let data = req.query;
    backstageServer.getDepartmentMembers(data,res);
}
//添加部门成员
exports.addDepartmentMembers = function(req, res) {
    let data = req.query;
    backstageServer.addDepartmentMembers(data,res);
}
//获取公司员工 
exports.getEnterpriseemployees = function(req, res) {
    let data = req.query;
    backstageServer.getEnterpriseemployees(data,res);
}
//删除公司员工信息 
exports.deleteEmployees = function(req, res) {
    let data = req.query;
    backstageServer.deleteEmployees(data,res);
}

//首页信息获取
exports.getIndexInfo = function(req, res) {
    let data = req.query;
    backstageServer.getIndexInfo(data,res);
}
//统计企业男女比例
exports.maleFemaleRatio = function(req, res) {
    let data = req.query;
    backstageServer.maleFemaleRatio(data,res);
}
//获取新员工信息（最近加入的三个员工信息）
exports.getNewEmployee = function(req, res) {
    let data = req.query;
    backstageServer.getNewEmployee(data,res);
}
//获取考勤信息
exports.getCheckAttendance = function(req, res) {
    let data = req.query;
    backstageServer.getCheckAttendance(data,res);
}
//搜索打卡数据
exports.searchCheckAttendance = function(req, res) {
    let data = req.query;
    backstageServer.searchCheckAttendance(data,res);
}
//查询用户id 
exports.searchUserId = function(req, res) {
    let data = req.query;
    backstageServer.searchUserId(data,res);
}
//获取员工职位和员工权限角色 
exports.getEmployeesInfo = function(req, res) {
    let data = req.query;
    backstageServer.getEmployeesInfo(data,res);
}
//获取员工职位和员工权限角色 
exports.updateEmployeesInfo = function(req, res) {
    let data = req.query;
    backstageServer.updateEmployeesInfo(data,res);
}
//查询导出打卡考勤信息
exports.searchExportCA = function(req, res) {
    let data = req.query;
    backstageServer.searchExportCA(data,res);
}

//导出打卡考勤信息为Excel
exports.exportExcel = function(req, res) {
    let data = req.query;
    backstageServer.exportExcel(data,res);
}