var dbserver = require('../dao/dbserver');

//获取一对一聊天消息
exports.msg = function(req, res) {
    let data = req.body;
    dbserver.msg(data, res);
}
//获取群聊消息
exports.groupMsg = function(req, res) {
    let data = req.body;
    dbserver.groupMsg(data, res);
}

//获取群成员
exports.getGroupMembers = function(req, res) {
    let data = req.body;
    dbserver.groupMembers(data, res);
}