var dbserver = require('../dao/dbserver');
//公司注册
exports.buildEnterprise = function(req, res) {
    let data = req.body
    dbserver.buildEnterprise(data, res);
}
//判断公司名称是否重复
exports.judgeValue = function(req, res) {
    let data = req.body.data;
    let type = req.body.type;
    
    dbserver.countEnterpriseValue(data, type, res);
}
//判断用户是否加入企业
exports.countUserIntoEnterprise = function(req, res) {
    let data = req.body;
    dbserver.countUserIntoEnterprise(data, res);
}

