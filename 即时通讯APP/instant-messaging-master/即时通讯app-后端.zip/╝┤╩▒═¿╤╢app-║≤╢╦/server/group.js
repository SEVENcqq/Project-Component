
var dbserver = require('../dao/dbserver');
//新建群
exports.createGroup = function(req, res) {
    let data = req.body;
    dbserver.createGroup(data, res);
}
exports.insertGroupUser = function(req, res) {
    let data = req.body;
    dbserver.insertGroupUser(data, res);
}

exports.groupDetailUpdata = function(req, res) {
    let data = req.body;
    dbserver.groupDetailUpdata(data, res);
}
//查询群信息
exports.searchGroupUser = function(req, res) {
    let data = req.body;
    dbserver.searchGroupUser(data, res);
}
//解散群 
exports.groupDissolution = function(req, res) {
    let data = req.body;
    dbserver.groupDissolution(data, res);
}
 //退出群
exports.groupSignOut = function(req, res) {
    let data = req.body;
    dbserver.groupSignOut(data, res);
}