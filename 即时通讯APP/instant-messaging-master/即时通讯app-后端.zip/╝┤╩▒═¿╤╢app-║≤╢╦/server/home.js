var dbserver = require('../dao/dbserver');

exports.getFriend = function(req, res) {
    let data = req.body;
    dbserver.getUsers(data, res);
}
//获取最后一条消息
exports.getLastMsg = function(req, res) {
    let data = req.body;
    dbserver.getOneLastMsg(data, res);
}
//获取消息未读条数
exports.unreadMsg = function(req, res) {
    let data = req.body;
    dbserver.unreadMsg(data, res);
}
//未读消息更新
exports.updataStateMsg = function(req, res) {
    let data = req.body;
    dbserver.updataStateMsg(data, res);
}

//获取群列表
exports.getGroup = function(req, res) {
    let data = req.body;
    dbserver.getGroup(data, res);
}

//按要求获取群最后一条消息
exports.getOneGroupLastMsg = function(req, res) {
    let data = req.body;
    dbserver.getOneGroupLastMsg(data, res);
}
//群未读消息数清零
exports.updataStateGroupMsg = function(req, res) {
    let data = req.body;
    dbserver.updataStateGroupMsg(data, res);
}
//删除用户所在聊天室 
exports.delateUsersChatRoom = function(req, res) {
    let data = req.body;
    dbserver.delateUsersChatRoom(data, res);
} 
//搜索用户所在聊天室 
exports.searchChatRoom = function(req, res) {
    let data = req.body;
    dbserver.searchChatRoom(data, res);
} 
//添加用户所在聊天室 
exports.addUsersChatRoom = function(req, res) {
    let data = req.body;
    dbserver.addUsersChatRoom(data, res);
} 