var dbserver = require('../dao/dbserver');

//获取流程和表单模型
exports.getFormModel = function(req, res) {
    let data = req.body;
    dbserver.getFormModel(data, res);
}
//发起流程
exports.initiatin = function(req, res) {
    let data = req.body;
    dbserver.initiatin(data, res);
}
//我的代办条数
exports.doitForMe = function(req, res) {
    let data = req.body;
    dbserver.doitForMe(data, res);
}
//获取我的代办信息
exports.getDoitForMeData = function(req, res) {
    let data = req.body;
    dbserver.getDoitForMeData(data, res);
}
//获取表单绑定值
exports.getFormValue = function(req, res) {
    let data = req.body;
    dbserver.getFormValue(data, res);
}
//流程审批
exports.approve = function(req, res) {
    let data = req.body;
    dbserver.approve(data, res);
}
//流程审批
exports.refuse = function(req, res) {
    let data = req.body;
    dbserver.refuse(data, res);
}
//插入已办或者代办
exports.insertCompletedOrApplied = function(req, res) {
    let data = req.body;
    dbserver.insertCompletedOrApplied(data, res);
}
//查询已办或者代办条数
exports.searchCompletedOrAppliedCount = function(req, res) {
    let data = req.body;
    dbserver.searchCompletedOrAppliedCount(data, res);
}
//查询已办或者代办
exports.searchCompletedOrApplied = function(req, res) {
    let data = req.body;
    dbserver.searchCompletedOrApplied(data, res);
}
//流程当为view状态时设置下一节点审批人
exports.viewNextApprover = function(req, res) {
    let data = req.body;
    dbserver.viewNextApprover(data, res);
}