var dbserver = require('../dao/dbserver');

//获取部门一级架构与员工 departmentLevelStructureEmployees
exports.departmentLevelStructureEmployees = function(req, res) {
    let data = req.body;
    dbserver.departmentLevelStructureEmployees(data, res);
}
//获取部门一级架构与员工
exports.departmentAndEmployeesChild = function(req, res) {
    let data = req.body;
    dbserver.departmentAndEmployeesChild(data, res);
}