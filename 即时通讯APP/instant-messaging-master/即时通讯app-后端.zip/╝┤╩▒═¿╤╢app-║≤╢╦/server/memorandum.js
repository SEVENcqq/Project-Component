var dbserver = require('../dao/dbserver');


exports.NewMemorandum = function(req, res) {
    let data = req.body;
    dbserver.NewMemorandum(data, res);
}
exports.getMemorandum = function(req, res) {
    let data = req.body;
    dbserver.getMemorandum(data, res);
}
//修改我的备忘录状态 
exports.updateMemorandumState = function(req, res) {
    let data = req.body;
    dbserver.updateMemorandumState(data, res);
}
//删除备忘录
exports.delMemorandum = function(req, res) {
    let data = req.body;
    dbserver.delMemorandum(data, res);
}