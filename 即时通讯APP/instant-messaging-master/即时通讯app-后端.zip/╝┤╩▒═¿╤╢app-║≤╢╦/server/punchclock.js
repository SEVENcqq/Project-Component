var dbserver = require('../dao/dbserver');
//打卡
exports.punchTheClock = function(req, res) {
    let data = req.body;
    dbserver.punchTheClock(data, res);
}
//进入打卡页面获取打卡数据
exports.searchPunchClockInfo = function(req, res) {
    let data = req.body;
    dbserver.searchPunchClockInfo(data, res);
}
