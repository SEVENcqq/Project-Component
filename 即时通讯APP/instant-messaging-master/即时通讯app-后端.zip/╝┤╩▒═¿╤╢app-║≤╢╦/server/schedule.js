var dbserver = require('../dao/dbserver');
//新建日程 NewSchedule
exports.NewSchedule = function(req, res) {
    let data = req.body;
    dbserver.NewSchedule(data, res);
}
//获取流程
exports.getSchedule = function(req, res) {
    let data = req.body;
    dbserver.getSchedule(data, res);
}

//删除日程
exports.delSchedule = function(req, res) {
    let data = req.body;
    dbserver.delSchedule(data, res);
}
