//搜索好友和群
var dbserver = require('../dao/dbserver');

//用户搜索
exports.searchUser = function(req, res) {
    let data = req.body.data;
    dbserver.searchUser(data, res);
} 

//用户群组
exports.searchGroup = function(req, res) {
    let data = req.body.data;
    dbserver.searchGroup(data, res);
} 