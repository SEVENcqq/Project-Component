var dbserver = require('../dao/dbserver')

exports.signIn = function(req, res) {
    let data = req.body.data;
    let pwd = req.body.pwd;
    console.log(req);
    dbserver.userMatch(data,pwd,res);
}
//生成验证码并发送验证码
exports.generateVerificationCode = function(req, res) {
    let data = req.body;
    dbserver.generateVerificationCode(data,res);
}

//匹配邮件发送的验证码是否正常
exports.matchCode = function(req, res) {
    let data = req.body;
    dbserver.matchCode(data,res);
}
