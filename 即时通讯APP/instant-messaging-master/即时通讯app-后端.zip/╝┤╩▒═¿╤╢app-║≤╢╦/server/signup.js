var dbserver = require('../dao/dbserver');
var emailServer = require('../dao/emailserver')
//用户注册
exports.signUp = function(req, res) {
    let name = req.body.name;
    let pwd = req.body.pwd;
    let email = req.body.email;
    //发送邮件
    emailServer.emailSignUp(email);
    dbserver.buildUser(name, email, pwd, res);
}
//用户或邮箱是否占用
exports.judgeValue = function(req, res) {
    let data = req.body.data;
    let type = req.body.type;
    console.log(req.body);
    dbserver.countUserValue(data, type, res);
}
