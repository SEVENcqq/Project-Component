var mongoose = require('mongoose');

var Schema = mongoose.Schema;

mongoose.connect('mongodb://admin:199906@118.31.247.240/test');

var userSchema = new Schema({
    id: String,
    psw: String,
    email: String,
});

var User = mongoose.model('User', userSchema);

//插入数据
// var admin = new User({
//     id: 'one',
//     psw: '123',
//     email: '123456@163.com',
// });
// admin.save(function(err, ret) {
//     if(err) {
//         console.log('失败');
//     }
//     else {
//         console.log('成功');
//     }
// });

//查询
User.find({
    id : "admin"
}, function(err, val) {
    if(err)
        console.log('用户数据查找失败', err);
    else {
        console.log(val);
    }
})