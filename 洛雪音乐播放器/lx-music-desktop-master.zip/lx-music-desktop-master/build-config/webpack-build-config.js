module.exports = {
  minimize: false,
}
