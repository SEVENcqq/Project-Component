module.exports = {
  secretId: '',
  secretKey: '',

  bucket: '', // 存储桶
  region: '', // 区域
  prefix: '', // 路径
}
