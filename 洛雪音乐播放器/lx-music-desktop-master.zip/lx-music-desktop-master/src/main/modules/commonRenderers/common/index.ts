export { registerRendererEvents } from './winRendererEvent'

export { default } from './rendererEvent'
