import common from './common'
import list from './list'

export default () => {
  common()
  list()
}
