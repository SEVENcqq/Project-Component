// const { getAvailableFontFamilies } = require('electron-font-manager')


// exports.getAvailableFontFamilies = getAvailableFontFamilies


import { getFonts } from 'font-list'

export {
  getFonts,
}
