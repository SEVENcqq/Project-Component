<template>
  <div :class="$style.container" />
</template>

<script>

</script>


<style lang="less" module>
@import '@renderer/assets/styles/layout.less';

.container {

}


</style>
